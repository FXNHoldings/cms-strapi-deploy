--
-- PostgreSQL database dump
--

\restrict HGWtHHHvOBj4Td6wpTtU8bsesPx3aj1eSoloZ3KxVBbUblBuBTv1Sj6F4lZnfpQ

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    action_parameters jsonb,
    subject character varying(255),
    properties jsonb,
    conditions jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_permissions OWNER TO strapi;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_id_seq OWNER TO strapi;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- Name: admin_permissions_role_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.admin_permissions_role_lnk OWNER TO strapi;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNER TO strapi;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNED BY public.admin_permissions_role_lnk.id;


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    description character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_roles OWNER TO strapi;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_roles_id_seq OWNER TO strapi;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    username character varying(255),
    email character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    registration_token character varying(255),
    is_active boolean,
    blocked boolean,
    prefered_language character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_users OWNER TO strapi;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_id_seq OWNER TO strapi;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: admin_users_roles_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_users_roles_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    role_ord double precision,
    user_ord double precision
);


ALTER TABLE public.admin_users_roles_lnk OWNER TO strapi;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_users_roles_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNER TO strapi;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNED BY public.admin_users_roles_lnk.id;


--
-- Name: articles; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    slug character varying(255),
    excerpt text,
    content text,
    reading_time_minutes integer,
    seo_title character varying(255),
    seo_description text,
    seo_keywords character varying(255),
    scheduled_for timestamp(6) without time zone,
    autopost_status character varying(255),
    autopost_log jsonb,
    source character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    ai_image_status character varying(255),
    ai_image_status_message text
);


ALTER TABLE public.articles OWNER TO strapi;

--
-- Name: articles_author_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.articles_author_lnk (
    id integer NOT NULL,
    article_id integer,
    author_id integer,
    article_ord double precision
);


ALTER TABLE public.articles_author_lnk OWNER TO strapi;

--
-- Name: articles_author_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.articles_author_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_author_lnk_id_seq OWNER TO strapi;

--
-- Name: articles_author_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.articles_author_lnk_id_seq OWNED BY public.articles_author_lnk.id;


--
-- Name: articles_blog_destinations_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.articles_blog_destinations_lnk (
    id integer NOT NULL,
    article_id integer,
    blog_destination_id integer,
    blog_destination_ord double precision,
    article_ord double precision
);


ALTER TABLE public.articles_blog_destinations_lnk OWNER TO strapi;

--
-- Name: articles_blog_destinations_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.articles_blog_destinations_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_blog_destinations_lnk_id_seq OWNER TO strapi;

--
-- Name: articles_blog_destinations_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.articles_blog_destinations_lnk_id_seq OWNED BY public.articles_blog_destinations_lnk.id;


--
-- Name: articles_category_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.articles_category_lnk (
    id integer NOT NULL,
    article_id integer,
    category_id integer,
    article_ord double precision
);


ALTER TABLE public.articles_category_lnk OWNER TO strapi;

--
-- Name: articles_category_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.articles_category_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_category_lnk_id_seq OWNER TO strapi;

--
-- Name: articles_category_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.articles_category_lnk_id_seq OWNED BY public.articles_category_lnk.id;


--
-- Name: articles_destinations_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.articles_destinations_lnk (
    id integer NOT NULL,
    article_id integer,
    destination_id integer,
    destination_ord double precision,
    article_ord double precision
);


ALTER TABLE public.articles_destinations_lnk OWNER TO strapi;

--
-- Name: articles_destinations_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.articles_destinations_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_destinations_lnk_id_seq OWNER TO strapi;

--
-- Name: articles_destinations_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.articles_destinations_lnk_id_seq OWNED BY public.articles_destinations_lnk.id;


--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO strapi;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: articles_tags_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.articles_tags_lnk (
    id integer NOT NULL,
    article_id integer,
    tag_id integer,
    tag_ord double precision,
    article_ord double precision
);


ALTER TABLE public.articles_tags_lnk OWNER TO strapi;

--
-- Name: articles_tags_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.articles_tags_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_tags_lnk_id_seq OWNER TO strapi;

--
-- Name: articles_tags_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.articles_tags_lnk_id_seq OWNED BY public.articles_tags_lnk.id;


--
-- Name: authors; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.authors (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    slug character varying(255),
    email character varying(255),
    bio text,
    twitter character varying(255),
    website character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.authors OWNER TO strapi;

--
-- Name: authors_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.authors_id_seq OWNER TO strapi;

--
-- Name: authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.authors_id_seq OWNED BY public.authors.id;


--
-- Name: blog_destinations; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.blog_destinations (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    slug character varying(255),
    base_url character varying(255),
    webhook_url character varying(255),
    webhook_secret character varying(255),
    auth_header character varying(255),
    active boolean,
    auto_post_on_publish boolean,
    schedule character varying(255),
    topic_filter jsonb,
    last_post_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.blog_destinations OWNER TO strapi;

--
-- Name: blog_destinations_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.blog_destinations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_destinations_id_seq OWNER TO strapi;

--
-- Name: blog_destinations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.blog_destinations_id_seq OWNED BY public.blog_destinations.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    slug character varying(255),
    description text,
    icon character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    "order" integer,
    site character varying(255)
);


ALTER TABLE public.categories OWNER TO strapi;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO strapi;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: categories_parent_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.categories_parent_lnk (
    id integer NOT NULL,
    category_id integer,
    inv_category_id integer,
    category_ord double precision
);


ALTER TABLE public.categories_parent_lnk OWNER TO strapi;

--
-- Name: categories_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.categories_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_parent_lnk_id_seq OWNER TO strapi;

--
-- Name: categories_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.categories_parent_lnk_id_seq OWNED BY public.categories_parent_lnk.id;


--
-- Name: destinations; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.destinations (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    slug character varying(255),
    type character varying(255),
    country_code character varying(255),
    description text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.destinations OWNER TO strapi;

--
-- Name: destinations_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.destinations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.destinations_id_seq OWNER TO strapi;

--
-- Name: destinations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.destinations_id_seq OWNED BY public.destinations.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.files (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    alternative_text text,
    caption text,
    focal_point jsonb,
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255),
    ext character varying(255),
    mime character varying(255),
    size numeric(10,2),
    url text,
    preview_url text,
    provider character varying(255),
    provider_metadata jsonb,
    folder_path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.files OWNER TO strapi;

--
-- Name: files_folder_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.files_folder_lnk (
    id integer NOT NULL,
    file_id integer,
    folder_id integer,
    file_ord double precision
);


ALTER TABLE public.files_folder_lnk OWNER TO strapi;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.files_folder_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_folder_lnk_id_seq OWNER TO strapi;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.files_folder_lnk_id_seq OWNED BY public.files_folder_lnk.id;


--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_id_seq OWNER TO strapi;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: files_related_mph; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.files_related_mph (
    id integer NOT NULL,
    file_id integer,
    related_id integer,
    related_type character varying(255),
    field character varying(255),
    "order" double precision
);


ALTER TABLE public.files_related_mph OWNER TO strapi;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.files_related_mph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_related_mph_id_seq OWNER TO strapi;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.files_related_mph_id_seq OWNED BY public.files_related_mph.id;


--
-- Name: i18n_locale; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.i18n_locale (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.i18n_locale OWNER TO strapi;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.i18n_locale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.i18n_locale_id_seq OWNER TO strapi;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.i18n_locale_id_seq OWNED BY public.i18n_locale.id;


--
-- Name: strapi_ai_localization_jobs; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_ai_localization_jobs (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255) NOT NULL,
    source_locale character varying(255) NOT NULL,
    target_locales jsonb NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


ALTER TABLE public.strapi_ai_localization_jobs OWNER TO strapi;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_ai_localization_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNER TO strapi;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNED BY public.strapi_ai_localization_jobs.id;


--
-- Name: strapi_ai_metadata_jobs; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_ai_metadata_jobs (
    id integer NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone
);


ALTER TABLE public.strapi_ai_metadata_jobs OWNER TO strapi;

--
-- Name: strapi_ai_metadata_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_ai_metadata_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_ai_metadata_jobs_id_seq OWNER TO strapi;

--
-- Name: strapi_ai_metadata_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_ai_metadata_jobs_id_seq OWNED BY public.strapi_ai_metadata_jobs.id;


--
-- Name: strapi_api_token_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_api_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_token_permissions OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_api_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNED BY public.strapi_api_token_permissions.id;


--
-- Name: strapi_api_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_api_token_permissions_token_lnk (
    id integer NOT NULL,
    api_token_permission_id integer,
    api_token_id integer,
    api_token_permission_ord double precision
);


ALTER TABLE public.strapi_api_token_permissions_token_lnk OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNED BY public.strapi_api_token_permissions_token_lnk.id;


--
-- Name: strapi_api_tokens; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_api_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    access_key character varying(255),
    encrypted_key text,
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_tokens OWNER TO strapi;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNER TO strapi;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNED BY public.strapi_api_tokens.id;


--
-- Name: strapi_core_store_settings; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_core_store_settings (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


ALTER TABLE public.strapi_core_store_settings OWNER TO strapi;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_core_store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNER TO strapi;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNED BY public.strapi_core_store_settings.id;


--
-- Name: strapi_database_schema; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_database_schema (
    id integer NOT NULL,
    schema json,
    "time" timestamp without time zone,
    hash character varying(255)
);


ALTER TABLE public.strapi_database_schema OWNER TO strapi;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_database_schema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_database_schema_id_seq OWNER TO strapi;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_database_schema_id_seq OWNED BY public.strapi_database_schema.id;


--
-- Name: strapi_history_versions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_history_versions (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255),
    locale character varying(255),
    status character varying(255),
    data jsonb,
    schema jsonb,
    created_at timestamp(6) without time zone,
    created_by_id integer
);


ALTER TABLE public.strapi_history_versions OWNER TO strapi;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_history_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_history_versions_id_seq OWNER TO strapi;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_history_versions_id_seq OWNED BY public.strapi_history_versions.id;


--
-- Name: strapi_migrations; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_migrations (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations OWNER TO strapi;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_migrations_id_seq OWNER TO strapi;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_migrations_id_seq OWNED BY public.strapi_migrations.id;


--
-- Name: strapi_migrations_internal; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_migrations_internal (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations_internal OWNER TO strapi;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_migrations_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNER TO strapi;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNED BY public.strapi_migrations_internal.id;


--
-- Name: strapi_release_actions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_release_actions (
    id integer NOT NULL,
    document_id character varying(255),
    type character varying(255),
    content_type character varying(255),
    entry_document_id character varying(255),
    locale character varying(255),
    is_entry_valid boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer
);


ALTER TABLE public.strapi_release_actions OWNER TO strapi;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_release_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_release_actions_id_seq OWNER TO strapi;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_release_actions_id_seq OWNED BY public.strapi_release_actions.id;


--
-- Name: strapi_release_actions_release_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_release_actions_release_lnk (
    id integer NOT NULL,
    release_action_id integer,
    release_id integer,
    release_action_ord double precision
);


ALTER TABLE public.strapi_release_actions_release_lnk OWNER TO strapi;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_release_actions_release_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNED BY public.strapi_release_actions_release_lnk.id;


--
-- Name: strapi_releases; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_releases (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    released_at timestamp(6) without time zone,
    scheduled_at timestamp(6) without time zone,
    timezone character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_releases OWNER TO strapi;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_releases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_releases_id_seq OWNER TO strapi;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_releases_id_seq OWNED BY public.strapi_releases.id;


--
-- Name: strapi_sessions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_sessions (
    id integer NOT NULL,
    document_id character varying(255),
    user_id character varying(255),
    session_id character varying(255),
    child_id character varying(255),
    device_id character varying(255),
    origin character varying(255),
    expires_at timestamp(6) without time zone,
    absolute_expires_at timestamp(6) without time zone,
    status character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_sessions OWNER TO strapi;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_sessions_id_seq OWNER TO strapi;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_sessions_id_seq OWNED BY public.strapi_sessions.id;


--
-- Name: strapi_transfer_token_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_transfer_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_token_permissions OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNED BY public.strapi_transfer_token_permissions.id;


--
-- Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_transfer_token_permissions_token_lnk (
    id integer NOT NULL,
    transfer_token_permission_id integer,
    transfer_token_id integer,
    transfer_token_permission_ord double precision
);


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNED BY public.strapi_transfer_token_permissions_token_lnk.id;


--
-- Name: strapi_transfer_tokens; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_transfer_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    access_key character varying(255),
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_tokens OWNER TO strapi;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_transfer_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNER TO strapi;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNED BY public.strapi_transfer_tokens.id;


--
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


ALTER TABLE public.strapi_webhooks OWNER TO strapi;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_webhooks_id_seq OWNER TO strapi;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- Name: strapi_workflows; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    content_types jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows OWNER TO strapi;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_id_seq OWNED BY public.strapi_workflows.id;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stage_required_to_publish_lnk (
    id integer NOT NULL,
    workflow_id integer,
    workflow_stage_id integer
);


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk OWNER TO strapi;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNED BY public.strapi_workflows_stage_required_to_publish_lnk.id;


--
-- Name: strapi_workflows_stages; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stages (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows_stages OWNER TO strapi;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNED BY public.strapi_workflows_stages.id;


--
-- Name: strapi_workflows_stages_permissions_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stages_permissions_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    permission_id integer,
    permission_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_permissions_lnk OWNER TO strapi;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNED BY public.strapi_workflows_stages_permissions_lnk.id;


--
-- Name: strapi_workflows_stages_workflow_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stages_workflow_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    workflow_id integer,
    workflow_stage_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_workflow_lnk OWNER TO strapi;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNED BY public.strapi_workflows_stages_workflow_lnk.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    slug character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.tags OWNER TO strapi;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tags_id_seq OWNER TO strapi;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: up_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_permissions OWNER TO strapi;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_permissions_id_seq OWNER TO strapi;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_permissions_id_seq OWNED BY public.up_permissions.id;


--
-- Name: up_permissions_role_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.up_permissions_role_lnk OWNER TO strapi;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNER TO strapi;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNED BY public.up_permissions_role_lnk.id;


--
-- Name: up_roles; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_roles OWNER TO strapi;

--
-- Name: up_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_roles_id_seq OWNER TO strapi;

--
-- Name: up_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_roles_id_seq OWNED BY public.up_roles.id;


--
-- Name: up_users; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_users (
    id integer NOT NULL,
    document_id character varying(255),
    username character varying(255),
    email character varying(255),
    provider character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    confirmation_token character varying(255),
    confirmed boolean,
    blocked boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_users OWNER TO strapi;

--
-- Name: up_users_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_users_id_seq OWNER TO strapi;

--
-- Name: up_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_users_id_seq OWNED BY public.up_users.id;


--
-- Name: up_users_role_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_users_role_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    user_ord double precision
);


ALTER TABLE public.up_users_role_lnk OWNER TO strapi;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_users_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNER TO strapi;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNED BY public.up_users_role_lnk.id;


--
-- Name: upload_folders; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.upload_folders (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    path_id integer,
    path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.upload_folders OWNER TO strapi;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.upload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_folders_id_seq OWNER TO strapi;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.upload_folders_id_seq OWNED BY public.upload_folders.id;


--
-- Name: upload_folders_parent_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.upload_folders_parent_lnk (
    id integer NOT NULL,
    folder_id integer,
    inv_folder_id integer,
    folder_ord double precision
);


ALTER TABLE public.upload_folders_parent_lnk OWNER TO strapi;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.upload_folders_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNER TO strapi;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNED BY public.upload_folders_parent_lnk.id;


--
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- Name: admin_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_role_lnk_id_seq'::regclass);


--
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: admin_users_roles_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_users_roles_lnk_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: articles_author_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_author_lnk ALTER COLUMN id SET DEFAULT nextval('public.articles_author_lnk_id_seq'::regclass);


--
-- Name: articles_blog_destinations_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_blog_destinations_lnk ALTER COLUMN id SET DEFAULT nextval('public.articles_blog_destinations_lnk_id_seq'::regclass);


--
-- Name: articles_category_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_category_lnk ALTER COLUMN id SET DEFAULT nextval('public.articles_category_lnk_id_seq'::regclass);


--
-- Name: articles_destinations_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_destinations_lnk ALTER COLUMN id SET DEFAULT nextval('public.articles_destinations_lnk_id_seq'::regclass);


--
-- Name: articles_tags_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_tags_lnk ALTER COLUMN id SET DEFAULT nextval('public.articles_tags_lnk_id_seq'::regclass);


--
-- Name: authors id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.authors ALTER COLUMN id SET DEFAULT nextval('public.authors_id_seq'::regclass);


--
-- Name: blog_destinations id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.blog_destinations ALTER COLUMN id SET DEFAULT nextval('public.blog_destinations_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: categories_parent_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.categories_parent_lnk_id_seq'::regclass);


--
-- Name: destinations id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.destinations ALTER COLUMN id SET DEFAULT nextval('public.destinations_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: files_folder_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk ALTER COLUMN id SET DEFAULT nextval('public.files_folder_lnk_id_seq'::regclass);


--
-- Name: files_related_mph id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_related_mph ALTER COLUMN id SET DEFAULT nextval('public.files_related_mph_id_seq'::regclass);


--
-- Name: i18n_locale id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale ALTER COLUMN id SET DEFAULT nextval('public.i18n_locale_id_seq'::regclass);


--
-- Name: strapi_ai_localization_jobs id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_localization_jobs_id_seq'::regclass);


--
-- Name: strapi_ai_metadata_jobs id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_ai_metadata_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_metadata_jobs_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_api_tokens id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_id_seq'::regclass);


--
-- Name: strapi_core_store_settings id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_core_store_settings ALTER COLUMN id SET DEFAULT nextval('public.strapi_core_store_settings_id_seq'::regclass);


--
-- Name: strapi_database_schema id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_database_schema ALTER COLUMN id SET DEFAULT nextval('public.strapi_database_schema_id_seq'::regclass);


--
-- Name: strapi_history_versions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_history_versions ALTER COLUMN id SET DEFAULT nextval('public.strapi_history_versions_id_seq'::regclass);


--
-- Name: strapi_migrations id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_id_seq'::regclass);


--
-- Name: strapi_migrations_internal id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations_internal ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_internal_id_seq'::regclass);


--
-- Name: strapi_release_actions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_id_seq'::regclass);


--
-- Name: strapi_release_actions_release_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_release_lnk_id_seq'::regclass);


--
-- Name: strapi_releases id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases ALTER COLUMN id SET DEFAULT nextval('public.strapi_releases_id_seq'::regclass);


--
-- Name: strapi_sessions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions ALTER COLUMN id SET DEFAULT nextval('public.strapi_sessions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_transfer_tokens id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_tokens_id_seq'::regclass);


--
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- Name: strapi_workflows id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_id_seq'::regclass);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_permissions_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_permissions_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_workflow_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_workflow_lnk_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: up_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_id_seq'::regclass);


--
-- Name: up_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_role_lnk_id_seq'::regclass);


--
-- Name: up_roles id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles ALTER COLUMN id SET DEFAULT nextval('public.up_roles_id_seq'::regclass);


--
-- Name: up_users id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users ALTER COLUMN id SET DEFAULT nextval('public.up_users_id_seq'::regclass);


--
-- Name: up_users_role_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_role_lnk_id_seq'::regclass);


--
-- Name: upload_folders id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_id_seq'::regclass);


--
-- Name: upload_folders_parent_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_parent_lnk_id_seq'::regclass);


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_permissions (id, document_id, action, action_parameters, subject, properties, conditions, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	xnacfnkk23tg9kewzje77cud	plugin::content-manager.explorer.create	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "category", "tags", "author", "destinations", "blogDestinations"]}	[]	2026-04-20 01:52:40.16	2026-04-20 01:52:40.16	2026-04-20 01:52:40.16	\N	\N	\N
2	do8o93il90esx07n3lxo2wd7	plugin::content-manager.explorer.create	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	[]	2026-04-20 01:52:40.17	2026-04-20 01:52:40.17	2026-04-20 01:52:40.17	\N	\N	\N
3	nqsvaju5z5d0et8x33i0gvao	plugin::content-manager.explorer.create	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	[]	2026-04-20 01:52:40.177	2026-04-20 01:52:40.177	2026-04-20 01:52:40.177	\N	\N	\N
4	zlqjpod0rblt0266ciali8hq	plugin::content-manager.explorer.create	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "articles"]}	[]	2026-04-20 01:52:40.188	2026-04-20 01:52:40.188	2026-04-20 01:52:40.189	\N	\N	\N
5	r2jtz0ojzm4z5n5e96micgdm	plugin::content-manager.explorer.create	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	[]	2026-04-20 01:52:40.197	2026-04-20 01:52:40.197	2026-04-20 01:52:40.197	\N	\N	\N
6	ikhji5oldytl9gw91qbj60on	plugin::content-manager.explorer.create	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	[]	2026-04-20 01:52:40.207	2026-04-20 01:52:40.207	2026-04-20 01:52:40.207	\N	\N	\N
7	ndv2w0x2as5o95fxv705o6lt	plugin::content-manager.explorer.read	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "category", "tags", "author", "destinations", "blogDestinations"]}	[]	2026-04-20 01:52:40.212	2026-04-20 01:52:40.212	2026-04-20 01:52:40.212	\N	\N	\N
8	l11n7om7g77maos1x412kgg3	plugin::content-manager.explorer.read	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	[]	2026-04-20 01:52:40.218	2026-04-20 01:52:40.218	2026-04-20 01:52:40.218	\N	\N	\N
9	cv4uc3410fd1i42ny9muuwts	plugin::content-manager.explorer.read	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	[]	2026-04-20 01:52:40.226	2026-04-20 01:52:40.226	2026-04-20 01:52:40.227	\N	\N	\N
10	bewrk5f1fwtq24qha89gs6ij	plugin::content-manager.explorer.read	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "articles"]}	[]	2026-04-20 01:52:40.238	2026-04-20 01:52:40.238	2026-04-20 01:52:40.238	\N	\N	\N
11	bkzn5zgu7vnhrkzocvitgl4h	plugin::content-manager.explorer.read	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	[]	2026-04-20 01:52:40.248	2026-04-20 01:52:40.248	2026-04-20 01:52:40.249	\N	\N	\N
12	wyu38e2hl3g46i4wtaem9l8f	plugin::content-manager.explorer.read	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	[]	2026-04-20 01:52:40.255	2026-04-20 01:52:40.255	2026-04-20 01:52:40.255	\N	\N	\N
13	y6eiwwvh788nmp42bjh5srwf	plugin::content-manager.explorer.update	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "category", "tags", "author", "destinations", "blogDestinations"]}	[]	2026-04-20 01:52:40.265	2026-04-20 01:52:40.265	2026-04-20 01:52:40.266	\N	\N	\N
14	etncwqd4dx7tirup3f6scpmb	plugin::content-manager.explorer.update	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	[]	2026-04-20 01:52:40.274	2026-04-20 01:52:40.274	2026-04-20 01:52:40.274	\N	\N	\N
15	dnh42b136qdbsj9798xcy8j4	plugin::content-manager.explorer.update	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	[]	2026-04-20 01:52:40.281	2026-04-20 01:52:40.281	2026-04-20 01:52:40.282	\N	\N	\N
16	u4yyl5aouc8mq9u4ri1yh2fv	plugin::content-manager.explorer.update	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "articles"]}	[]	2026-04-20 01:52:40.288	2026-04-20 01:52:40.288	2026-04-20 01:52:40.288	\N	\N	\N
17	xx466ru565ewqirmx5j4qzmd	plugin::content-manager.explorer.update	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	[]	2026-04-20 01:52:40.295	2026-04-20 01:52:40.295	2026-04-20 01:52:40.295	\N	\N	\N
18	p0myi7lsilct62gvovpqtm0v	plugin::content-manager.explorer.update	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	[]	2026-04-20 01:52:40.3	2026-04-20 01:52:40.3	2026-04-20 01:52:40.301	\N	\N	\N
19	fe8hlrh3z3vlk9u123fkxywc	plugin::content-manager.explorer.delete	{}	api::article.article	{}	[]	2026-04-20 01:52:40.306	2026-04-20 01:52:40.306	2026-04-20 01:52:40.306	\N	\N	\N
20	ft2cka9p95eee1dqtu8uku6f	plugin::content-manager.explorer.delete	{}	api::author.author	{}	[]	2026-04-20 01:52:40.312	2026-04-20 01:52:40.312	2026-04-20 01:52:40.313	\N	\N	\N
21	e0xtgej5ab89sw2xric10ine	plugin::content-manager.explorer.delete	{}	api::blog-destination.blog-destination	{}	[]	2026-04-20 01:52:40.327	2026-04-20 01:52:40.327	2026-04-20 01:52:40.327	\N	\N	\N
22	aw5jv73gpqsqpylgsm3225vw	plugin::content-manager.explorer.delete	{}	api::category.category	{}	[]	2026-04-20 01:52:40.335	2026-04-20 01:52:40.335	2026-04-20 01:52:40.336	\N	\N	\N
23	afv49ocyzt4xdks90v0dtb8c	plugin::content-manager.explorer.delete	{}	api::destination.destination	{}	[]	2026-04-20 01:52:40.343	2026-04-20 01:52:40.343	2026-04-20 01:52:40.343	\N	\N	\N
24	koy4srsyvc1im6ihhqqb67lx	plugin::content-manager.explorer.delete	{}	api::tag.tag	{}	[]	2026-04-20 01:52:40.35	2026-04-20 01:52:40.35	2026-04-20 01:52:40.35	\N	\N	\N
25	lszrmu3ajihtsgo5a9irlwry	plugin::content-manager.explorer.publish	{}	api::article.article	{}	[]	2026-04-20 01:52:40.357	2026-04-20 01:52:40.357	2026-04-20 01:52:40.358	\N	\N	\N
26	de1ci9jn749lbdxqki76y9je	plugin::content-manager.explorer.publish	{}	api::author.author	{}	[]	2026-04-20 01:52:40.368	2026-04-20 01:52:40.368	2026-04-20 01:52:40.368	\N	\N	\N
27	z719hdrmt1uryahpahqv0rw7	plugin::content-manager.explorer.publish	{}	api::blog-destination.blog-destination	{}	[]	2026-04-20 01:52:40.376	2026-04-20 01:52:40.376	2026-04-20 01:52:40.376	\N	\N	\N
28	esuhd0dtjwfcedkovlf88c08	plugin::content-manager.explorer.publish	{}	api::category.category	{}	[]	2026-04-20 01:52:40.385	2026-04-20 01:52:40.385	2026-04-20 01:52:40.385	\N	\N	\N
29	rzxvxj8t0pb7klverzhqpdp8	plugin::content-manager.explorer.publish	{}	api::destination.destination	{}	[]	2026-04-20 01:52:40.393	2026-04-20 01:52:40.393	2026-04-20 01:52:40.393	\N	\N	\N
30	m4vmxfrpucnfshmn8v2in9dl	plugin::content-manager.explorer.publish	{}	api::tag.tag	{}	[]	2026-04-20 01:52:40.4	2026-04-20 01:52:40.4	2026-04-20 01:52:40.4	\N	\N	\N
31	k3n2usmf70mz6iyvvgnjreko	plugin::upload.read	{}	\N	{}	[]	2026-04-20 01:52:40.407	2026-04-20 01:52:40.407	2026-04-20 01:52:40.408	\N	\N	\N
32	rgy0hvdf1oi36ym2p9puvjkm	plugin::upload.configure-view	{}	\N	{}	[]	2026-04-20 01:52:40.416	2026-04-20 01:52:40.416	2026-04-20 01:52:40.417	\N	\N	\N
33	fg18wfxzy08swte8gfmr4vsc	plugin::upload.assets.create	{}	\N	{}	[]	2026-04-20 01:52:40.424	2026-04-20 01:52:40.424	2026-04-20 01:52:40.424	\N	\N	\N
34	la0yzmsfob9mo53s7md4hl75	plugin::upload.assets.update	{}	\N	{}	[]	2026-04-20 01:52:40.431	2026-04-20 01:52:40.431	2026-04-20 01:52:40.432	\N	\N	\N
35	sxagec9o27c7jsjoceflu6k5	plugin::upload.assets.download	{}	\N	{}	[]	2026-04-20 01:52:40.44	2026-04-20 01:52:40.44	2026-04-20 01:52:40.44	\N	\N	\N
36	f0tayiz2eyl0i65ohti63pz6	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-04-20 01:52:40.449	2026-04-20 01:52:40.449	2026-04-20 01:52:40.449	\N	\N	\N
37	vkdh0cc9jj257c9ht2vk8dgr	plugin::content-manager.explorer.create	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "category", "tags", "author", "destinations", "blogDestinations"]}	["admin::is-creator"]	2026-04-20 01:52:40.473	2026-04-20 01:52:40.473	2026-04-20 01:52:40.473	\N	\N	\N
38	yelm75mvpdmbuzf36gx78tuz	plugin::content-manager.explorer.create	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.481	2026-04-20 01:52:40.481	2026-04-20 01:52:40.482	\N	\N	\N
39	ecc1u94t0sb7mq64pox7xgk9	plugin::content-manager.explorer.create	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.49	2026-04-20 01:52:40.49	2026-04-20 01:52:40.49	\N	\N	\N
40	ng4crbq219g5c10d57kpjfol	plugin::content-manager.explorer.create	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.497	2026-04-20 01:52:40.497	2026-04-20 01:52:40.497	\N	\N	\N
41	yrk5lmqy712p4ter2kxbsjta	plugin::content-manager.explorer.create	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.504	2026-04-20 01:52:40.504	2026-04-20 01:52:40.504	\N	\N	\N
42	wh8o5akq82ao32h9x3hf8tgf	plugin::content-manager.explorer.create	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.511	2026-04-20 01:52:40.511	2026-04-20 01:52:40.511	\N	\N	\N
43	wspss3s89fx9vrr6d5caom3u	plugin::content-manager.explorer.read	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "category", "tags", "author", "destinations", "blogDestinations"]}	["admin::is-creator"]	2026-04-20 01:52:40.517	2026-04-20 01:52:40.517	2026-04-20 01:52:40.517	\N	\N	\N
44	e61qwdockal98fzrtsw1za7k	plugin::content-manager.explorer.read	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.525	2026-04-20 01:52:40.525	2026-04-20 01:52:40.525	\N	\N	\N
45	spe0o5jkusxt5dzignsn8nc2	plugin::content-manager.explorer.read	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.534	2026-04-20 01:52:40.534	2026-04-20 01:52:40.534	\N	\N	\N
46	lq8ohie3oj12qtutjqdx2sbn	plugin::content-manager.explorer.read	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.541	2026-04-20 01:52:40.541	2026-04-20 01:52:40.542	\N	\N	\N
47	oyjc3qqhrxoe21rahjrtyhla	plugin::content-manager.explorer.read	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.547	2026-04-20 01:52:40.547	2026-04-20 01:52:40.548	\N	\N	\N
48	sqox4xcw5058lmlfplgvl042	plugin::content-manager.explorer.read	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.555	2026-04-20 01:52:40.555	2026-04-20 01:52:40.555	\N	\N	\N
49	u5x1sd91ypdwt686pn14wo3c	plugin::content-manager.explorer.update	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "category", "tags", "author", "destinations", "blogDestinations"]}	["admin::is-creator"]	2026-04-20 01:52:40.566	2026-04-20 01:52:40.566	2026-04-20 01:52:40.566	\N	\N	\N
50	g1srp1d185yjdocd2s6m4sky	plugin::content-manager.explorer.update	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.573	2026-04-20 01:52:40.573	2026-04-20 01:52:40.573	\N	\N	\N
51	zta1jgw9bwctu5ys1feejdu4	plugin::content-manager.explorer.update	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.581	2026-04-20 01:52:40.581	2026-04-20 01:52:40.581	\N	\N	\N
52	zejifjjj2s9rn6mza75g6caq	plugin::content-manager.explorer.update	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.588	2026-04-20 01:52:40.588	2026-04-20 01:52:40.589	\N	\N	\N
53	osxgyuvctubsag7l5bbh4y8h	plugin::content-manager.explorer.update	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.595	2026-04-20 01:52:40.595	2026-04-20 01:52:40.596	\N	\N	\N
54	cm0ntg423l2h4ddv2ckp8uby	plugin::content-manager.explorer.update	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	["admin::is-creator"]	2026-04-20 01:52:40.608	2026-04-20 01:52:40.608	2026-04-20 01:52:40.608	\N	\N	\N
55	h0exoawt3rxn0zocupfmt8hc	plugin::content-manager.explorer.delete	{}	api::article.article	{}	["admin::is-creator"]	2026-04-20 01:52:40.616	2026-04-20 01:52:40.616	2026-04-20 01:52:40.617	\N	\N	\N
56	go84pw727lfgv9xz6yqfmauh	plugin::content-manager.explorer.delete	{}	api::author.author	{}	["admin::is-creator"]	2026-04-20 01:52:40.627	2026-04-20 01:52:40.627	2026-04-20 01:52:40.627	\N	\N	\N
57	ni8rqoewzzf0bzmoekg5eo5a	plugin::content-manager.explorer.delete	{}	api::blog-destination.blog-destination	{}	["admin::is-creator"]	2026-04-20 01:52:40.639	2026-04-20 01:52:40.639	2026-04-20 01:52:40.639	\N	\N	\N
58	ydophaz4nk6yqhd88tu59vd7	plugin::content-manager.explorer.delete	{}	api::category.category	{}	["admin::is-creator"]	2026-04-20 01:52:40.648	2026-04-20 01:52:40.648	2026-04-20 01:52:40.649	\N	\N	\N
59	y6xqrnpwhhdp569qtqmh8g3b	plugin::content-manager.explorer.delete	{}	api::destination.destination	{}	["admin::is-creator"]	2026-04-20 01:52:40.658	2026-04-20 01:52:40.658	2026-04-20 01:52:40.658	\N	\N	\N
60	m2gex1oatyw9vi0h3wsc5zx4	plugin::content-manager.explorer.delete	{}	api::tag.tag	{}	["admin::is-creator"]	2026-04-20 01:52:40.668	2026-04-20 01:52:40.668	2026-04-20 01:52:40.668	\N	\N	\N
61	psqwv7k3agou446kno909lww	plugin::upload.read	{}	\N	{}	["admin::is-creator"]	2026-04-20 01:52:40.688	2026-04-20 01:52:40.688	2026-04-20 01:52:40.689	\N	\N	\N
62	x36ebokrsza3rq37h6gqd0sc	plugin::upload.configure-view	{}	\N	{}	[]	2026-04-20 01:52:40.697	2026-04-20 01:52:40.697	2026-04-20 01:52:40.697	\N	\N	\N
63	hfapvl8wippjtt1ncqt8pzpg	plugin::upload.assets.create	{}	\N	{}	[]	2026-04-20 01:52:40.705	2026-04-20 01:52:40.705	2026-04-20 01:52:40.705	\N	\N	\N
64	qq6ya84s5wp0o0decko49lz4	plugin::upload.assets.update	{}	\N	{}	["admin::is-creator"]	2026-04-20 01:52:40.711	2026-04-20 01:52:40.711	2026-04-20 01:52:40.712	\N	\N	\N
65	tlzhac8ab4n65lbxmmh6e3vd	plugin::upload.assets.download	{}	\N	{}	[]	2026-04-20 01:52:40.718	2026-04-20 01:52:40.718	2026-04-20 01:52:40.718	\N	\N	\N
66	hika1quodkzx7vf69s8fn9l3	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-04-20 01:52:40.725	2026-04-20 01:52:40.725	2026-04-20 01:52:40.725	\N	\N	\N
67	v43mr6ffn42bavzpz1bqoh6r	plugin::content-manager.explorer.create	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}	[]	2026-04-20 01:52:40.797	2026-04-20 01:52:40.797	2026-04-20 01:52:40.797	\N	\N	\N
69	nvqqydkggk2sx8j9ki10pcc9	plugin::content-manager.explorer.create	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	[]	2026-04-20 01:52:40.814	2026-04-20 01:52:40.814	2026-04-20 01:52:40.814	\N	\N	\N
70	x1piv9ir1fzz34ged63lkhjs	plugin::content-manager.explorer.create	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	[]	2026-04-20 01:52:40.82	2026-04-20 01:52:40.82	2026-04-20 01:52:40.82	\N	\N	\N
72	iysct66nsh7d70jbmyztoi51	plugin::content-manager.explorer.create	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	[]	2026-04-20 01:52:40.832	2026-04-20 01:52:40.832	2026-04-20 01:52:40.833	\N	\N	\N
73	twvxcygz8iyr3wf3mgtd7ufw	plugin::content-manager.explorer.create	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	[]	2026-04-20 01:52:40.839	2026-04-20 01:52:40.839	2026-04-20 01:52:40.839	\N	\N	\N
74	yivg75ihk4bdw0vic3xgeh8g	plugin::content-manager.explorer.read	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}	[]	2026-04-20 01:52:40.845	2026-04-20 01:52:40.845	2026-04-20 01:52:40.845	\N	\N	\N
76	i20cjm391tue1fz56itxjytd	plugin::content-manager.explorer.read	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	[]	2026-04-20 01:52:40.856	2026-04-20 01:52:40.856	2026-04-20 01:52:40.856	\N	\N	\N
77	po5emfsct5zdt4olz5isx2tb	plugin::content-manager.explorer.read	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	[]	2026-04-20 01:52:40.861	2026-04-20 01:52:40.861	2026-04-20 01:52:40.861	\N	\N	\N
79	a46wo5bp4erq3drw627gkof0	plugin::content-manager.explorer.read	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	[]	2026-04-20 01:52:40.874	2026-04-20 01:52:40.874	2026-04-20 01:52:40.874	\N	\N	\N
80	aysfakj0xeh1qkt2zf27fblb	plugin::content-manager.explorer.read	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	[]	2026-04-20 01:52:40.882	2026-04-20 01:52:40.882	2026-04-20 01:52:40.882	\N	\N	\N
81	b2bijaz2f5q5y6e65hqid0hw	plugin::content-manager.explorer.update	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}	[]	2026-04-20 01:52:40.892	2026-04-20 01:52:40.892	2026-04-20 01:52:40.893	\N	\N	\N
83	i15gbj8cl48yhl4mlh549fq3	plugin::content-manager.explorer.update	{}	api::author.author	{"fields": ["name", "slug", "email", "bio", "avatar", "twitter", "website", "articles"]}	[]	2026-04-20 01:52:40.906	2026-04-20 01:52:40.906	2026-04-20 01:52:40.906	\N	\N	\N
84	kbqvdwswrqorbm70dy4gi97w	plugin::content-manager.explorer.update	{}	api::blog-destination.blog-destination	{"fields": ["name", "slug", "baseUrl", "webhookUrl", "webhookSecret", "authHeader", "active", "autoPostOnPublish", "schedule", "topicFilter", "lastPostAt", "articles"]}	[]	2026-04-20 01:52:40.912	2026-04-20 01:52:40.912	2026-04-20 01:52:40.912	\N	\N	\N
86	b5g3doca6z9ewicius3y12rp	plugin::content-manager.explorer.update	{}	api::destination.destination	{"fields": ["name", "slug", "type", "countryCode", "description", "heroImage", "articles"]}	[]	2026-04-20 01:52:40.937	2026-04-20 01:52:40.937	2026-04-20 01:52:40.937	\N	\N	\N
87	kwobe8orlzjkgi3en7jvjs0d	plugin::content-manager.explorer.update	{}	api::tag.tag	{"fields": ["name", "slug", "articles"]}	[]	2026-04-20 01:52:40.946	2026-04-20 01:52:40.946	2026-04-20 01:52:40.946	\N	\N	\N
88	xmpy67m8xlfab5qm3mnp0n56	plugin::content-manager.explorer.delete	{}	plugin::users-permissions.user	{}	[]	2026-04-20 01:52:40.954	2026-04-20 01:52:40.954	2026-04-20 01:52:40.955	\N	\N	\N
89	pe94lx4863jpmo0leych20sz	plugin::content-manager.explorer.delete	{}	api::article.article	{}	[]	2026-04-20 01:52:40.963	2026-04-20 01:52:40.963	2026-04-20 01:52:40.963	\N	\N	\N
90	lco76mlr3ymy2gi8w3vfmhuk	plugin::content-manager.explorer.delete	{}	api::author.author	{}	[]	2026-04-20 01:52:40.97	2026-04-20 01:52:40.97	2026-04-20 01:52:40.97	\N	\N	\N
91	y7gls68t74f36u6kmed5t9rz	plugin::content-manager.explorer.delete	{}	api::blog-destination.blog-destination	{}	[]	2026-04-20 01:52:40.98	2026-04-20 01:52:40.98	2026-04-20 01:52:40.981	\N	\N	\N
92	oy71jr7vzxssxwv7ekxm2jpk	plugin::content-manager.explorer.delete	{}	api::category.category	{}	[]	2026-04-20 01:52:40.988	2026-04-20 01:52:40.988	2026-04-20 01:52:40.988	\N	\N	\N
93	e8tso2cr3vwz7q7f4ecayq2w	plugin::content-manager.explorer.delete	{}	api::destination.destination	{}	[]	2026-04-20 01:52:40.995	2026-04-20 01:52:40.995	2026-04-20 01:52:40.995	\N	\N	\N
94	xjtw8dnhwhv8opknx98vn505	plugin::content-manager.explorer.delete	{}	api::tag.tag	{}	[]	2026-04-20 01:52:41.005	2026-04-20 01:52:41.005	2026-04-20 01:52:41.005	\N	\N	\N
95	a6d5r8gawqa9f91mpi45ozoc	plugin::content-manager.explorer.publish	{}	plugin::users-permissions.user	{}	[]	2026-04-20 01:52:41.014	2026-04-20 01:52:41.014	2026-04-20 01:52:41.014	\N	\N	\N
96	d5yxgzepbn86k4acseayvsbm	plugin::content-manager.explorer.publish	{}	api::article.article	{}	[]	2026-04-20 01:52:41.024	2026-04-20 01:52:41.024	2026-04-20 01:52:41.024	\N	\N	\N
97	on9vajeyxrhgy5tm8mm5ydag	plugin::content-manager.explorer.publish	{}	api::author.author	{}	[]	2026-04-20 01:52:41.032	2026-04-20 01:52:41.032	2026-04-20 01:52:41.032	\N	\N	\N
98	hcwneldvubelgroax9b7azdq	plugin::content-manager.explorer.publish	{}	api::blog-destination.blog-destination	{}	[]	2026-04-20 01:52:41.039	2026-04-20 01:52:41.039	2026-04-20 01:52:41.04	\N	\N	\N
99	e14eykl4tcs2h8iig2aaswac	plugin::content-manager.explorer.publish	{}	api::category.category	{}	[]	2026-04-20 01:52:41.047	2026-04-20 01:52:41.047	2026-04-20 01:52:41.047	\N	\N	\N
100	r21uuokm129zsrl4fs1ymiht	plugin::content-manager.explorer.publish	{}	api::destination.destination	{}	[]	2026-04-20 01:52:41.053	2026-04-20 01:52:41.053	2026-04-20 01:52:41.054	\N	\N	\N
101	zm62o7yr4o0oldzlj6x95895	plugin::content-manager.explorer.publish	{}	api::tag.tag	{}	[]	2026-04-20 01:52:41.059	2026-04-20 01:52:41.059	2026-04-20 01:52:41.06	\N	\N	\N
102	mb4doeflh7cldmt437d8z9is	plugin::content-manager.single-types.configure-view	{}	\N	{}	[]	2026-04-20 01:52:41.066	2026-04-20 01:52:41.066	2026-04-20 01:52:41.066	\N	\N	\N
103	r05eqa2h7q4i9j9xhwwn54ke	plugin::content-manager.collection-types.configure-view	{}	\N	{}	[]	2026-04-20 01:52:41.072	2026-04-20 01:52:41.072	2026-04-20 01:52:41.072	\N	\N	\N
104	slebmifzltf0p3g1jovlfxow	plugin::content-manager.components.configure-layout	{}	\N	{}	[]	2026-04-20 01:52:41.08	2026-04-20 01:52:41.08	2026-04-20 01:52:41.08	\N	\N	\N
105	tqo4prbi1vrm32f69f7y32w1	plugin::content-type-builder.read	{}	\N	{}	[]	2026-04-20 01:52:41.086	2026-04-20 01:52:41.086	2026-04-20 01:52:41.086	\N	\N	\N
106	gggq3e406shopje5mtjvyp9f	plugin::email.settings.read	{}	\N	{}	[]	2026-04-20 01:52:41.092	2026-04-20 01:52:41.092	2026-04-20 01:52:41.092	\N	\N	\N
107	pkiq8xu7z7yj6ro9is2gvmbp	plugin::upload.read	{}	\N	{}	[]	2026-04-20 01:52:41.098	2026-04-20 01:52:41.098	2026-04-20 01:52:41.098	\N	\N	\N
108	ynddfwmbhywd9tntyq5cirhu	plugin::upload.assets.create	{}	\N	{}	[]	2026-04-20 01:52:41.103	2026-04-20 01:52:41.103	2026-04-20 01:52:41.103	\N	\N	\N
109	nlfx2oj4nvusxds579kxq7m0	plugin::upload.assets.update	{}	\N	{}	[]	2026-04-20 01:52:41.108	2026-04-20 01:52:41.108	2026-04-20 01:52:41.108	\N	\N	\N
110	mmhwf6ezl6lss086orm2kcgz	plugin::upload.assets.download	{}	\N	{}	[]	2026-04-20 01:52:41.114	2026-04-20 01:52:41.114	2026-04-20 01:52:41.114	\N	\N	\N
111	qhgl5ilhsl55ha8ez3bs5h7l	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-04-20 01:52:41.119	2026-04-20 01:52:41.119	2026-04-20 01:52:41.12	\N	\N	\N
112	rxspjjfis5agaqqfwjnhk886	plugin::upload.configure-view	{}	\N	{}	[]	2026-04-20 01:52:41.126	2026-04-20 01:52:41.126	2026-04-20 01:52:41.126	\N	\N	\N
113	lm42z4d9j5bbq1tq8fzegfff	plugin::upload.settings.read	{}	\N	{}	[]	2026-04-20 01:52:41.132	2026-04-20 01:52:41.132	2026-04-20 01:52:41.132	\N	\N	\N
114	gk4tw3ac4a7qm8chaan4cckn	plugin::i18n.locale.create	{}	\N	{}	[]	2026-04-20 01:52:41.139	2026-04-20 01:52:41.139	2026-04-20 01:52:41.139	\N	\N	\N
115	by5o773j673iwa5eoaegq1qh	plugin::i18n.locale.read	{}	\N	{}	[]	2026-04-20 01:52:41.147	2026-04-20 01:52:41.147	2026-04-20 01:52:41.148	\N	\N	\N
116	gwihyqg0dltoudu7dfoba7lz	plugin::i18n.locale.update	{}	\N	{}	[]	2026-04-20 01:52:41.155	2026-04-20 01:52:41.155	2026-04-20 01:52:41.155	\N	\N	\N
117	k77vxlfn61d8gk5rfbzpd6i0	plugin::i18n.locale.delete	{}	\N	{}	[]	2026-04-20 01:52:41.16	2026-04-20 01:52:41.16	2026-04-20 01:52:41.16	\N	\N	\N
118	p3m281fwzxi3esuoxa3nqdzn	plugin::users-permissions.roles.create	{}	\N	{}	[]	2026-04-20 01:52:41.165	2026-04-20 01:52:41.165	2026-04-20 01:52:41.165	\N	\N	\N
119	f7wt321o5i2bkq5aydn84jk9	plugin::users-permissions.roles.read	{}	\N	{}	[]	2026-04-20 01:52:41.17	2026-04-20 01:52:41.17	2026-04-20 01:52:41.17	\N	\N	\N
120	b3d8dscikojly0d1c6ckp5me	plugin::users-permissions.roles.update	{}	\N	{}	[]	2026-04-20 01:52:41.175	2026-04-20 01:52:41.175	2026-04-20 01:52:41.175	\N	\N	\N
121	w5cpxpd8spik996nsxn3eyzo	plugin::users-permissions.roles.delete	{}	\N	{}	[]	2026-04-20 01:52:41.184	2026-04-20 01:52:41.184	2026-04-20 01:52:41.184	\N	\N	\N
122	dxm0t3nkb6g70c1k2n5lh8uk	plugin::users-permissions.providers.read	{}	\N	{}	[]	2026-04-20 01:52:41.191	2026-04-20 01:52:41.191	2026-04-20 01:52:41.192	\N	\N	\N
123	wszza8v4htpfndnyl48c3x6p	plugin::users-permissions.providers.update	{}	\N	{}	[]	2026-04-20 01:52:41.199	2026-04-20 01:52:41.199	2026-04-20 01:52:41.199	\N	\N	\N
124	ycgizaxa0xqszlhxwaic8qud	plugin::users-permissions.email-templates.read	{}	\N	{}	[]	2026-04-20 01:52:41.205	2026-04-20 01:52:41.205	2026-04-20 01:52:41.206	\N	\N	\N
125	i5mndgxxw5li59fwr4iccia0	plugin::users-permissions.email-templates.update	{}	\N	{}	[]	2026-04-20 01:52:41.212	2026-04-20 01:52:41.212	2026-04-20 01:52:41.212	\N	\N	\N
126	b1qpi7pfj3jm5tqkhe6oz0o5	plugin::users-permissions.advanced-settings.read	{}	\N	{}	[]	2026-04-20 01:52:41.219	2026-04-20 01:52:41.219	2026-04-20 01:52:41.219	\N	\N	\N
127	i4fbyfjy4x31y5dbbepnzknn	plugin::users-permissions.advanced-settings.update	{}	\N	{}	[]	2026-04-20 01:52:41.225	2026-04-20 01:52:41.225	2026-04-20 01:52:41.226	\N	\N	\N
128	lvdf7didahg4foywffandu3l	admin::marketplace.read	{}	\N	{}	[]	2026-04-20 01:52:41.233	2026-04-20 01:52:41.233	2026-04-20 01:52:41.233	\N	\N	\N
129	y0htdbypov5lro6v04yzx9bv	admin::webhooks.create	{}	\N	{}	[]	2026-04-20 01:52:41.24	2026-04-20 01:52:41.24	2026-04-20 01:52:41.24	\N	\N	\N
130	prfve0jxl1c4okzhcfo0ku7m	admin::webhooks.read	{}	\N	{}	[]	2026-04-20 01:52:41.247	2026-04-20 01:52:41.247	2026-04-20 01:52:41.247	\N	\N	\N
131	dpguoy4kr3ewk4awy2v4bpz9	admin::webhooks.update	{}	\N	{}	[]	2026-04-20 01:52:41.253	2026-04-20 01:52:41.253	2026-04-20 01:52:41.253	\N	\N	\N
132	vdelpj32a4vb4702tvucjumq	admin::webhooks.delete	{}	\N	{}	[]	2026-04-20 01:52:41.258	2026-04-20 01:52:41.258	2026-04-20 01:52:41.259	\N	\N	\N
133	hv3l8rb951gugtqji0x56yvp	admin::users.create	{}	\N	{}	[]	2026-04-20 01:52:41.267	2026-04-20 01:52:41.267	2026-04-20 01:52:41.267	\N	\N	\N
134	vcblqy4oxi4xgabkfmejrkjs	admin::users.read	{}	\N	{}	[]	2026-04-20 01:52:41.274	2026-04-20 01:52:41.274	2026-04-20 01:52:41.275	\N	\N	\N
135	p4g7auabgce945uxqhuvcqlt	admin::users.update	{}	\N	{}	[]	2026-04-20 01:52:41.282	2026-04-20 01:52:41.282	2026-04-20 01:52:41.282	\N	\N	\N
136	t6rjnvpma1otypzno938i2g0	admin::users.delete	{}	\N	{}	[]	2026-04-20 01:52:41.287	2026-04-20 01:52:41.287	2026-04-20 01:52:41.287	\N	\N	\N
137	carxj1ap368fa8yd3gwiv5c1	admin::roles.create	{}	\N	{}	[]	2026-04-20 01:52:41.293	2026-04-20 01:52:41.293	2026-04-20 01:52:41.294	\N	\N	\N
138	u040lmxjon3lagqmvx2deyxf	admin::roles.read	{}	\N	{}	[]	2026-04-20 01:52:41.3	2026-04-20 01:52:41.3	2026-04-20 01:52:41.3	\N	\N	\N
139	muystzhm4opuygm1oi0jqrpy	admin::roles.update	{}	\N	{}	[]	2026-04-20 01:52:41.309	2026-04-20 01:52:41.309	2026-04-20 01:52:41.309	\N	\N	\N
140	jc6grensojyioq1i4h3n87m7	admin::roles.delete	{}	\N	{}	[]	2026-04-20 01:52:41.315	2026-04-20 01:52:41.315	2026-04-20 01:52:41.315	\N	\N	\N
141	h1uwbq18ipjtizikpu2u0j9v	admin::api-tokens.access	{}	\N	{}	[]	2026-04-20 01:52:41.32	2026-04-20 01:52:41.32	2026-04-20 01:52:41.32	\N	\N	\N
142	lk6ktm3qafllorlkrw6pduac	admin::api-tokens.create	{}	\N	{}	[]	2026-04-20 01:52:41.326	2026-04-20 01:52:41.326	2026-04-20 01:52:41.326	\N	\N	\N
143	irrowv0n7qhj5vro3g85s926	admin::api-tokens.read	{}	\N	{}	[]	2026-04-20 01:52:41.331	2026-04-20 01:52:41.331	2026-04-20 01:52:41.332	\N	\N	\N
144	uuh9x7obx4qu6o3cj3ugg5el	admin::api-tokens.update	{}	\N	{}	[]	2026-04-20 01:52:41.337	2026-04-20 01:52:41.337	2026-04-20 01:52:41.337	\N	\N	\N
145	afgv5qdtj8n603exion01db9	admin::api-tokens.regenerate	{}	\N	{}	[]	2026-04-20 01:52:41.342	2026-04-20 01:52:41.342	2026-04-20 01:52:41.342	\N	\N	\N
146	obidia7j0unwhxz7882x0gda	admin::api-tokens.delete	{}	\N	{}	[]	2026-04-20 01:52:41.348	2026-04-20 01:52:41.348	2026-04-20 01:52:41.348	\N	\N	\N
147	fgucbcangadolgrdi9nxz17l	admin::project-settings.update	{}	\N	{}	[]	2026-04-20 01:52:41.353	2026-04-20 01:52:41.353	2026-04-20 01:52:41.353	\N	\N	\N
148	ztife1bdq1lbmnku0y568grs	admin::project-settings.read	{}	\N	{}	[]	2026-04-20 01:52:41.359	2026-04-20 01:52:41.359	2026-04-20 01:52:41.359	\N	\N	\N
149	kmidn5mbggjl0srx7nrya6w7	admin::transfer.tokens.access	{}	\N	{}	[]	2026-04-20 01:52:41.364	2026-04-20 01:52:41.364	2026-04-20 01:52:41.364	\N	\N	\N
150	twmhjg3pb060m1ryy3gwl801	admin::transfer.tokens.create	{}	\N	{}	[]	2026-04-20 01:52:41.369	2026-04-20 01:52:41.369	2026-04-20 01:52:41.369	\N	\N	\N
151	huwctk0l9gtwmmkxaf4hbic8	admin::transfer.tokens.read	{}	\N	{}	[]	2026-04-20 01:52:41.376	2026-04-20 01:52:41.376	2026-04-20 01:52:41.377	\N	\N	\N
152	ezr6i1aehxo449joum74dsnh	admin::transfer.tokens.update	{}	\N	{}	[]	2026-04-20 01:52:41.384	2026-04-20 01:52:41.384	2026-04-20 01:52:41.385	\N	\N	\N
153	gt8we851rddq3ahk41docz1n	admin::transfer.tokens.regenerate	{}	\N	{}	[]	2026-04-20 01:52:41.391	2026-04-20 01:52:41.391	2026-04-20 01:52:41.391	\N	\N	\N
154	vnro67lzg682l6qt4qxhw1e0	admin::transfer.tokens.delete	{}	\N	{}	[]	2026-04-20 01:52:41.396	2026-04-20 01:52:41.396	2026-04-20 01:52:41.396	\N	\N	\N
155	cvhbmp7j44yebzw1yg0i6wvg	plugin::content-manager.explorer.create	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "order", "site", "parent", "children", "articles"]}	[]	2026-04-20 08:59:08.158	2026-04-20 08:59:08.158	2026-04-20 08:59:08.16	\N	\N	\N
156	qz2q8mnymttrrhvsodvphcxf	plugin::content-manager.explorer.read	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "order", "site", "parent", "children", "articles"]}	[]	2026-04-20 08:59:08.175	2026-04-20 08:59:08.175	2026-04-20 08:59:08.176	\N	\N	\N
157	bg6ln49i66e3lsmlei0v71lo	plugin::content-manager.explorer.update	{}	api::category.category	{"fields": ["name", "slug", "description", "icon", "color", "order", "site", "parent", "children", "articles"]}	[]	2026-04-20 08:59:08.184	2026-04-20 08:59:08.184	2026-04-20 08:59:08.184	\N	\N	\N
158	iixjmkridqrbtuh224c9uyax	plugin::content-manager.explorer.create	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "aiImageStatus", "aiImageStatusMessage", "category", "tags", "author", "destinations", "blogDestinations"]}	[]	2026-04-20 11:39:28.796	2026-04-20 11:39:28.796	2026-04-20 11:39:28.798	\N	\N	\N
159	ahkzo6v043gmm5ewgs5qawfv	plugin::content-manager.explorer.read	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "aiImageStatus", "aiImageStatusMessage", "category", "tags", "author", "destinations", "blogDestinations"]}	[]	2026-04-20 11:39:28.817	2026-04-20 11:39:28.817	2026-04-20 11:39:28.817	\N	\N	\N
160	gt7h7zrw4yvagcv7pc6kxuj1	plugin::content-manager.explorer.update	{}	api::article.article	{"fields": ["title", "slug", "excerpt", "content", "coverImage", "gallery", "readingTimeMinutes", "seoTitle", "seoDescription", "seoKeywords", "ogImage", "scheduledFor", "autopostStatus", "autopostLog", "source", "aiImageStatus", "aiImageStatusMessage", "category", "tags", "author", "destinations", "blogDestinations"]}	[]	2026-04-20 11:39:28.827	2026-04-20 11:39:28.827	2026-04-20 11:39:28.827	\N	\N	\N
\.


--
-- Data for Name: admin_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	2	1
2	2	2	2
3	3	2	3
4	4	2	4
5	5	2	5
6	6	2	6
7	7	2	7
8	8	2	8
9	9	2	9
10	10	2	10
11	11	2	11
12	12	2	12
13	13	2	13
14	14	2	14
15	15	2	15
16	16	2	16
17	17	2	17
18	18	2	18
19	19	2	19
20	20	2	20
21	21	2	21
22	22	2	22
23	23	2	23
24	24	2	24
25	25	2	25
26	26	2	26
27	27	2	27
28	28	2	28
29	29	2	29
30	30	2	30
31	31	2	31
32	32	2	32
33	33	2	33
34	34	2	34
35	35	2	35
36	36	2	36
37	37	3	1
38	38	3	2
39	39	3	3
40	40	3	4
41	41	3	5
42	42	3	6
43	43	3	7
44	44	3	8
45	45	3	9
46	46	3	10
47	47	3	11
48	48	3	12
49	49	3	13
50	50	3	14
51	51	3	15
52	52	3	16
53	53	3	17
54	54	3	18
55	55	3	19
56	56	3	20
57	57	3	21
58	58	3	22
59	59	3	23
60	60	3	24
61	61	3	25
62	62	3	26
63	63	3	27
64	64	3	28
65	65	3	29
66	66	3	30
67	67	1	1
69	69	1	3
70	70	1	4
72	72	1	6
73	73	1	7
74	74	1	8
76	76	1	10
77	77	1	11
79	79	1	13
80	80	1	14
81	81	1	15
83	83	1	17
84	84	1	18
86	86	1	20
87	87	1	21
88	88	1	22
89	89	1	23
90	90	1	24
91	91	1	25
92	92	1	26
93	93	1	27
94	94	1	28
95	95	1	29
96	96	1	30
97	97	1	31
98	98	1	32
99	99	1	33
100	100	1	34
101	101	1	35
102	102	1	36
103	103	1	37
104	104	1	38
105	105	1	39
106	106	1	40
107	107	1	41
108	108	1	42
109	109	1	43
110	110	1	44
111	111	1	45
112	112	1	46
113	113	1	47
114	114	1	48
115	115	1	49
116	116	1	50
117	117	1	51
118	118	1	52
119	119	1	53
120	120	1	54
121	121	1	55
122	122	1	56
123	123	1	57
124	124	1	58
125	125	1	59
126	126	1	60
127	127	1	61
128	128	1	62
129	129	1	63
130	130	1	64
131	131	1	65
132	132	1	66
133	133	1	67
134	134	1	68
135	135	1	69
136	136	1	70
137	137	1	71
138	138	1	72
139	139	1	73
140	140	1	74
141	141	1	75
142	142	1	76
143	143	1	77
144	144	1	78
145	145	1	79
146	146	1	80
147	147	1	81
148	148	1	82
149	149	1	83
150	150	1	84
151	151	1	85
152	152	1	86
153	153	1	87
154	154	1	88
155	155	1	89
156	156	1	90
157	157	1	91
158	158	1	92
159	159	1	93
160	160	1	94
\.


--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_roles (id, document_id, name, code, description, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	txmm1gahgkugqp099juz9kay	Super Admin	strapi-super-admin	Super Admins can access and manage all features and settings.	2026-04-20 01:52:40.11	2026-04-20 01:52:40.11	2026-04-20 01:52:40.11	\N	\N	\N
2	cg00n5nshg5rxhrnfrz2m0zh	Editor	strapi-editor	Editors can manage and publish contents including those of other users.	2026-04-20 01:52:40.128	2026-04-20 01:52:40.128	2026-04-20 01:52:40.128	\N	\N	\N
3	kddkefcxx9lm3vr5exw0x66o	Author	strapi-author	Authors can manage the content they have created.	2026-04-20 01:52:40.135	2026-04-20 01:52:40.135	2026-04-20 01:52:40.135	\N	\N	\N
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_users (id, document_id, firstname, lastname, username, email, password, reset_password_token, registration_token, is_active, blocked, prefered_language, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	gc9bua5c09hpwvd0j76n7l1m	Kritin	Curtis	\N	kryptok630@gmail.com	$2a$10$3mq/RUcZ5w.A.zrFQIVR9enBeBum/KqdbFwegLBAc4nh12hQy1ndq	\N	\N	t	f	\N	2026-04-20 01:53:12.914	2026-04-20 01:53:12.914	2026-04-20 01:53:12.915	\N	\N	\N
\.


--
-- Data for Name: admin_users_roles_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_users_roles_lnk (id, user_id, role_id, role_ord, user_ord) FROM stdin;
1	1	1	1	1
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.articles (id, document_id, title, slug, excerpt, content, reading_time_minutes, seo_title, seo_description, seo_keywords, scheduled_for, autopost_status, autopost_log, source, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, ai_image_status, ai_image_status_message) FROM stdin;
3	n5glkt36iy0hdw8axipxumb3	How to Find the Cheapest Flights: 12 Proven Strategies That Work	how-to-find-cheapest-flights-proven-strategies	Stop overpaying for airfare. Learn the exact techniques travel experts use to score rock-bottom flight prices, from booking windows to browser tricks you've never heard of.	# How to Find the Cheapest Flights: 12 Proven Strategies That Work\n\nLet's cut through the noise: finding cheap flights isn't about luck or spending hours clicking through sketchy websites. It's about knowing the system and using a handful of proven tactics that actually work.\n\nI've booked hundreds of flights over the past decade, and I've watched airfare patterns closely enough to know what moves the needle. Here's exactly how to find the cheapest flights without losing your mind in the process.\n\n## Start With Flexible Dates (This Changes Everything)\n\nThe single biggest factor in flight prices? When you fly. Being flexible with your dates can save you 40-60% on the same route.\n\n**Here's what to do:**\n- Use Google Flights' calendar view to see prices across an entire month\n- Tuesdays and Wednesdays are typically 15-20% cheaper than weekend flights\n- Avoid peak travel periods: Christmas, Thanksgiving, school holidays, and major festivals\n- Red-eye flights and early morning departures often cost significantly less\n\nIf you have wiggle room of even 2-3 days, you'll almost always find better deals.\n\n## The 54-Day Booking Window Sweet Spot\n\nForget the myth about Tuesday at 3pm being magic. The real pattern is simpler.\n\n**Domestic flights:** Book 1-3 months ahead (54 days is the statistical sweet spot)\n**International flights:** Book 2-8 months in advance\n**Peak season travel:** Book as early as possible, ideally 3-6 months out\n\nBooking too early or too late both cost you money. Airlines release seats at higher prices initially, drop them to attract buyers, then raise them as the flight fills up.\n\n## Use the Right Search Tools (Not All Are Equal)\n\nDifferent search engines access different fare databases and have different deals.\n\n**My go-to combination:**\n- **Google Flights** for initial research and flexible date searching\n- **Skyscanner** for budget airlines and multi-city routes\n- **Momondo** often finds quirky routing that saves money\n- **ITA Matrix** for complex itineraries (though you can't book directly)\n\nAlways check the airline's website directly before booking. Sometimes they have exclusive deals or lower fees.\n\n## Clear Your Cookies (Yes, Really)\n\nAirline websites and booking platforms track your searches. If you keep searching the same route, prices can mysteriously increase to create urgency.\n\n**Try this:**\n- Search in incognito/private browsing mode\n- Clear cookies between sessions\n- Use a VPN to search from different locations (sometimes regional pricing varies)\n\nIs this effect overblown? Maybe. But I've seen it work enough times to keep doing it.\n\n## Consider Nearby Airports\n\nExpanding your search by 50-100 miles can unlock completely different price brackets.\n\n**Examples that work:**\n- NYC: Check JFK, Newark, and LaGuardia\n- London: Stansted, Gatwick, Luton, and Heathrow all have different carriers\n- LA: Burbank and Long Beach often beat LAX prices\n- Paris: Beauvais can be half the price of Charles de Gaulle\n\nFactor in ground transportation costs, but don't dismiss this strategy—I've saved $200+ on a single ticket this way.\n\n## Book One-Way Flights Separately\n\nRound-trip tickets aren't always the best deal, especially internationally.\n\nMix and match airlines on your outbound and return legs. You might fly Budget Airline A going out and Major Carrier B coming back if that combination is cheaper.\n\nThis is especially true with budget carriers that don't offer round-trip discounts anyway.\n\n## Set Price Alerts (Then Be Ready to Move)\n\nDon't manually check prices daily. Automate it.\n\n**Google Flights and Hopper** both offer excellent price tracking:\n- Get email alerts when prices drop\n- See predictions on whether to book now or wait\n- Track multiple routes simultaneously\n\nWhen you get an alert for a great price, book quickly. The cheapest seats go fast.\n\n## Don't Ignore Budget Airlines\n\nYes, you'll pay for carry-ons and seat selection. But even with fees, budget carriers like Spirit, Frontier, Ryanair, and AirAsia often come out cheaper.\n\n**Pro tip:** If you're traveling light (personal item only) and don't need to choose your seat, budget airlines can be 50-70% cheaper than legacy carriers on the same route.\n\nJust read the fine print and calculate total costs before booking.\n\n## Consider Positioning Flights\n\nSometimes flying to a major hub first, then catching your international flight, costs less than flying direct from your home airport.\n\nThis sounds counterintuitive, but I've done NYC to Miami to Barcelona for $200 less than NYC to Barcelona direct.\n\nUse Google Flights' multi-city search to test different routing options.\n\n## Book Directly After Finding the Fare\n\nOnce you've found your flight on a search engine, go directly to the airline's website to book. Third-party booking sites often:\n- Charge booking fees\n- Make changes and cancellations harder\n- Offer less customer service protection\n\nThe airline's site usually matches the price, and you'll have direct access if anything goes wrong.\n\n## Use Points and Miles Strategically\n\nIf you have a travel credit card, your points might be worth more than you think.\n\n**Quick wins:**\n- Transfer points to airline partners during bonus promotions\n- Book during off-peak award calendars\n- Combine points with cash to stretch your balance\n\nEven if you're not a points expert, a good travel card's sign-up bonus can cover 1-2 free flights per year.\n\n## Know When to Pull the Trigger\n\nThe biggest mistake people make? Waiting for an imaginary "perfect" price that never comes.\n\nIf you find a fare that's 20-30% below average for your route and dates, book it. Trying to save another $20 by waiting often backfires when prices jump $100 overnight.\n\nUse Google Flights' price history to see if you're getting a genuinely good deal.\n\n## Your Next Steps\n\nFinding cheap flights isn't about one magic trick—it's about stacking several small advantages.\n\nStart with flexible dates, use multiple search engines, set price alerts, and be ready to book when you spot a good deal. Skip the superstitions about specific booking days and focus on these proven strategies instead.\n\nThe difference between randomly booking and using these tactics? Easily $200-500 per ticket. On a family trip, that's a free hotel night or two.\n\nNow stop reading and go set up those price alerts for your next trip. Your wallet will thank you.	5	How to Find Cheapest Flights: 12 Proven Money-Saving Strategies	Learn expert strategies to find the cheapest flights every time. From booking windows to search tools, these proven tactics save hundreds on airfare.	cheap flights, find cheap flights, how to book cheap flights, flight deals, save money on flights, best time to book flights, flight search engines, budget travel, airfare tips	\N	none	\N	ai	2026-04-20 07:34:26.166	2026-04-20 09:23:19.35	\N	\N	1	\N	\N	\N
5	n5glkt36iy0hdw8axipxumb3	How to Find the Cheapest Flights: 12 Proven Strategies That Work	how-to-find-cheapest-flights-proven-strategies	Stop overpaying for airfare. Learn the exact techniques travel experts use to score rock-bottom flight prices, from booking windows to browser tricks you've never heard of.	# How to Find the Cheapest Flights: 12 Proven Strategies That Work\n\nLet's cut through the noise: finding cheap flights isn't about luck or spending hours clicking through sketchy websites. It's about knowing the system and using a handful of proven tactics that actually work.\n\nI've booked hundreds of flights over the past decade, and I've watched airfare patterns closely enough to know what moves the needle. Here's exactly how to find the cheapest flights without losing your mind in the process.\n\n## Start With Flexible Dates (This Changes Everything)\n\nThe single biggest factor in flight prices? When you fly. Being flexible with your dates can save you 40-60% on the same route.\n\n**Here's what to do:**\n- Use Google Flights' calendar view to see prices across an entire month\n- Tuesdays and Wednesdays are typically 15-20% cheaper than weekend flights\n- Avoid peak travel periods: Christmas, Thanksgiving, school holidays, and major festivals\n- Red-eye flights and early morning departures often cost significantly less\n\nIf you have wiggle room of even 2-3 days, you'll almost always find better deals.\n\n## The 54-Day Booking Window Sweet Spot\n\nForget the myth about Tuesday at 3pm being magic. The real pattern is simpler.\n\n**Domestic flights:** Book 1-3 months ahead (54 days is the statistical sweet spot)\n**International flights:** Book 2-8 months in advance\n**Peak season travel:** Book as early as possible, ideally 3-6 months out\n\nBooking too early or too late both cost you money. Airlines release seats at higher prices initially, drop them to attract buyers, then raise them as the flight fills up.\n\n## Use the Right Search Tools (Not All Are Equal)\n\nDifferent search engines access different fare databases and have different deals.\n\n**My go-to combination:**\n- **Google Flights** for initial research and flexible date searching\n- **Skyscanner** for budget airlines and multi-city routes\n- **Momondo** often finds quirky routing that saves money\n- **ITA Matrix** for complex itineraries (though you can't book directly)\n\nAlways check the airline's website directly before booking. Sometimes they have exclusive deals or lower fees.\n\n## Clear Your Cookies (Yes, Really)\n\nAirline websites and booking platforms track your searches. If you keep searching the same route, prices can mysteriously increase to create urgency.\n\n**Try this:**\n- Search in incognito/private browsing mode\n- Clear cookies between sessions\n- Use a VPN to search from different locations (sometimes regional pricing varies)\n\nIs this effect overblown? Maybe. But I've seen it work enough times to keep doing it.\n\n## Consider Nearby Airports\n\nExpanding your search by 50-100 miles can unlock completely different price brackets.\n\n**Examples that work:**\n- NYC: Check JFK, Newark, and LaGuardia\n- London: Stansted, Gatwick, Luton, and Heathrow all have different carriers\n- LA: Burbank and Long Beach often beat LAX prices\n- Paris: Beauvais can be half the price of Charles de Gaulle\n\nFactor in ground transportation costs, but don't dismiss this strategy—I've saved $200+ on a single ticket this way.\n\n## Book One-Way Flights Separately\n\nRound-trip tickets aren't always the best deal, especially internationally.\n\nMix and match airlines on your outbound and return legs. You might fly Budget Airline A going out and Major Carrier B coming back if that combination is cheaper.\n\nThis is especially true with budget carriers that don't offer round-trip discounts anyway.\n\n## Set Price Alerts (Then Be Ready to Move)\n\nDon't manually check prices daily. Automate it.\n\n**Google Flights and Hopper** both offer excellent price tracking:\n- Get email alerts when prices drop\n- See predictions on whether to book now or wait\n- Track multiple routes simultaneously\n\nWhen you get an alert for a great price, book quickly. The cheapest seats go fast.\n\n## Don't Ignore Budget Airlines\n\nYes, you'll pay for carry-ons and seat selection. But even with fees, budget carriers like Spirit, Frontier, Ryanair, and AirAsia often come out cheaper.\n\n**Pro tip:** If you're traveling light (personal item only) and don't need to choose your seat, budget airlines can be 50-70% cheaper than legacy carriers on the same route.\n\nJust read the fine print and calculate total costs before booking.\n\n## Consider Positioning Flights\n\nSometimes flying to a major hub first, then catching your international flight, costs less than flying direct from your home airport.\n\nThis sounds counterintuitive, but I've done NYC to Miami to Barcelona for $200 less than NYC to Barcelona direct.\n\nUse Google Flights' multi-city search to test different routing options.\n\n## Book Directly After Finding the Fare\n\nOnce you've found your flight on a search engine, go directly to the airline's website to book. Third-party booking sites often:\n- Charge booking fees\n- Make changes and cancellations harder\n- Offer less customer service protection\n\nThe airline's site usually matches the price, and you'll have direct access if anything goes wrong.\n\n## Use Points and Miles Strategically\n\nIf you have a travel credit card, your points might be worth more than you think.\n\n**Quick wins:**\n- Transfer points to airline partners during bonus promotions\n- Book during off-peak award calendars\n- Combine points with cash to stretch your balance\n\nEven if you're not a points expert, a good travel card's sign-up bonus can cover 1-2 free flights per year.\n\n## Know When to Pull the Trigger\n\nThe biggest mistake people make? Waiting for an imaginary "perfect" price that never comes.\n\nIf you find a fare that's 20-30% below average for your route and dates, book it. Trying to save another $20 by waiting often backfires when prices jump $100 overnight.\n\nUse Google Flights' price history to see if you're getting a genuinely good deal.\n\n## Your Next Steps\n\nFinding cheap flights isn't about one magic trick—it's about stacking several small advantages.\n\nStart with flexible dates, use multiple search engines, set price alerts, and be ready to book when you spot a good deal. Skip the superstitions about specific booking days and focus on these proven strategies instead.\n\nThe difference between randomly booking and using these tactics? Easily $200-500 per ticket. On a family trip, that's a free hotel night or two.\n\nNow stop reading and go set up those price alerts for your next trip. Your wallet will thank you.	5	How to Find Cheapest Flights: 12 Proven Money-Saving Strategies	Learn expert strategies to find the cheapest flights every time. From booking windows to search tools, these proven tactics save hundreds on airfare.	cheap flights, find cheap flights, how to book cheap flights, flight deals, save money on flights, best time to book flights, flight search engines, budget travel, airfare tips	\N	none	\N	ai	2026-04-20 07:34:26.166	2026-04-20 09:23:19.35	2026-04-20 09:23:19.419	\N	1	\N	\N	\N
12	vnfu97g74nbile6h2z99du40	5 Ultra-Cool Boutique Hotels Opening in Tokyo This Spring 2024	coolest-boutique-hotels-tokyo-spring-2024	Tokyo's boutique hotel scene is exploding this spring with five design-forward properties that blend Japanese minimalism with cutting-edge hospitality. Here's your insider guide.	## Tokyo's Boutique Hotel Renaissance\n\nTokyo is having a serious moment in the boutique hotel world this spring, and if you're planning a trip between March and May 2024, you're in for a treat. Forget cookie-cutter chains—these five new properties are redefining what it means to stay stylish in Japan's capital.\n\n## The Standouts Opening This Season\n\n### Azabu Harmony House (Roppongi, Opens March)\n\nThis 18-room gem in Azabu-Juban marries traditional ryokan elements with Scandinavian design. Each room features custom tatami platforms, rain showers with Mount Fuji views, and a curated selection of Japanese craft gin. The rooftop onsen is the real showstopper—book the sunset slot if you can.\n\n**What makes it special:** In-room sake sommelier service and partnerships with local artisans for exclusive shopping experiences.\n\n### Shibuya Canvas Loft (Shibuya, Opens April)\n\nThink industrial-chic meets Tokyo street culture. This 24-room property occupies a renovated 1970s office building with exposed concrete, floor-to-ceiling windows, and an Instagram-worthy cafe serving third-wave coffee and Japanese-French pastries.\n\n**Insider tip:** Request a room on floors 5-7 for unobstructed Shibuya Crossing views.\n\n### The Kagurazaka Edit (Kagurazaka, Opens April)\n\nNestled in Tokyo's most charming neighbourhood, this 12-suite boutique hotel feels like staying at a sophisticated friend's minimalist apartment. Each suite includes a compact kitchen stocked with locally-sourced ingredients, perfect for travellers who want to shop at nearby markets.\n\n**Don't miss:** The hotel's curated walking tours of hidden Kagurazaka temples and izakayas.\n\n### Ginza Velvet Minimal (Ginza, Opens May)\n\nLuxury without the stuffiness—that's Ginza Velvet's promise. With only 15 rooms, this property focuses on texture and craftsmanship: hand-plastered walls, vintage Japanese ceramics, and beds dressed in Imabari cotton that feels like sleeping on clouds.\n\n**Pro move:** The concierge has access to impossible-to-book sushi restaurants. Use this power wisely.\n\n### Yanaka Heritage Stays (Yanaka, Opens May)\n\nThe most authentic of the bunch, Yanaka Heritage transforms four traditional machiya townhouses into boutique accommodations. You'll sleep on futons, use cypress wood baths, and wake to birdsong in old Tokyo's most preserved neighbourhood.\n\n**Perfect for:** Travellers craving cultural immersion over trendy amenities.\n\n## Booking Tips for Spring 2024\n\n- **Book now:** These properties are already generating buzz, and Tokyo's spring cherry blossom season fills up fast\n- **Check package deals:** Several hotels offer opening specials with perks like airport transfers or kaiseki dinners\n- **Consider weekdays:** You'll save 30-40% and have a quieter experience\n\n## Why Spring Timing Matters\n\nBeyond avoiding the summer humidity and securing opening rates, spring in Tokyo means cherry blossoms, perfect walking weather, and these hotels will still have that fresh, eager-to-impress energy.\n\n**Ready to experience Tokyo's boutique hotel revolution?** These five properties prove that the city's accommodation scene is finally catching up to its reputation for design excellence. Book early, pack light, and prepare for a stay that's as memorable as the city itself.	4	5 Best New Boutique Hotels in Tokyo Opening Spring 2024	Discover Tokyo's coolest new boutique hotels opening spring 2024. From Shibuya lofts to traditional Yanaka machiya stays—insider booking tips included.	Tokyo boutique hotels 2024, new hotels Tokyo spring, best boutique hotels Tokyo, Tokyo accommodation, Shibuya hotels, Ginza hotels, where to stay Tokyo	\N	none	\N	ai	2026-04-20 09:51:32.85	2026-04-20 10:25:03.45	\N	\N	1	\N	\N	\N
8	pdqekos06oqnffn39vrltrza	10 Luxury Eco-Hotels Worth the Splurge This Year	luxury-eco-hotels-worth-the-splurge	Sustainability meets indulgence at these stunning eco-hotels where you can enjoy five-star amenities while minimizing your carbon footprint. Discover properties redefining luxury travel.	# 10 Luxury Eco-Hotels Worth the Splurge This Year\n\nGone are the days when eco-friendly travel meant sacrificing comfort. Today's luxury eco-hotels prove you can pamper yourself while protecting the planet. Here are ten exceptional properties where sustainability and sophistication go hand in hand.\n\n## Europe's Green Gems\n\n### Whitepod, Switzerland\nNestled in the Swiss Alps, these geodesic domes run on renewable energy and feature pellet stoves for heating. Despite the minimalist footprint, expect plush beds, gourmet dining, and breathtaking mountain views.\n\n### Soneva Fushi, Maldives\nThis barefoot luxury resort pioneered the "no news, no shoes" philosophy. With solar power, waste-to-wealth programs, and an on-site glass-blowing studio creating art from recycled bottles, it's sustainability perfection.\n\n### Fogo Island Inn, Canada\nThis architectural marvel in Newfoundland sources 90% of its food locally, employs community members, and reinvests profits into the island's preservation. Floor-to-ceiling windows frame the dramatic North Atlantic coastline.\n\n## Tropical Escapes With Purpose\n\n### Lapa Rios Lodge, Costa Rica\nOwning a private rainforest reserve, this lodge protects 1,000 acres of biodiversity. Seventeen bungalows blend into the canopy, offering wildlife viewing and ocean panoramas without compromising the ecosystem.\n\n### Pikaia Lodge, Galápagos\nBuilt with endemic materials and powered by renewable energy, this LEED-certified property offers yacht excursions to explore Darwin's living laboratory while maintaining strict conservation protocols.\n\n### Misool, Indonesia\nThis private island resort created a 300,000-acre marine reserve, transforming former shark-finning grounds into a thriving reef ecosystem. Over-water villas provide direct access to world-class diving.\n\n## Desert and Mountain Sanctuaries\n\n### Longitude 131°, Australia\nFacing Uluru, these luxury tents operate on solar power and practice strict waste management while offering champagne at sunset and indigenous cultural experiences.\n\n### Explora Patagonia, Chile\nCarbon-neutral operations, hydroelectric power, and organic gardens supply this contemporary lodge. Daily excursions into Torres del Paine National Park include expert naturalist guides.\n\n### Campi ya Kanzi, Kenya\nThis Maasai-owned wilderness camp protects 400 square miles of wildlife habitat. Profits fund education, healthcare, and conservation initiatives for six local communities.\n\n### Lefay Resort, Italy\nOverlooking Lake Garda, this wellness retreat achieved LEED Gold certification through geothermal heating, rainwater harvesting, and organic spa treatments using local herbs.\n\n## Why These Hotels Matter\n\nThese properties demonstrate that luxury travel can drive positive change. They create local employment, protect endangered ecosystems, and prove sustainable practices enhance rather than diminish guest experiences.\n\n**Ready to book your guilt-free escape?** Each hotel offers unique seasonal packages. Research their sustainability certifications, compare carbon offset programs, and remember: your tourism dollars vote for the kind of world you want to see. Which eco-luxury destination will you choose?\n\n*Travel tip: Many of these properties offer multi-night packages with better rates and deeper immersion into their conservation programs.*	3	10 Best Luxury Eco-Hotels for Sustainable Travel in 2024	Discover 10 exceptional luxury eco-hotels combining five-star comfort with sustainability. From Swiss Alps to Maldives, splurge responsibly this year.	luxury eco hotels, sustainable travel, green hotels, eco resorts, sustainable luxury travel, eco-friendly hotels, carbon neutral resorts, responsible tourism, luxury sustainable hotels	\N	none	\N	ai	2026-04-20 09:50:39.058	2026-04-20 11:40:21.02	\N	\N	1	\N	generating	\N
6	i56fsh5dk25vbx13p9ocpvoi	Best Pet-Friendly Hotels in Europe: Your 2026 Travel Guide	best-pet-friendly-hotels-europe-2026-travel-guide	Discover Europe's top pet-friendly hotels where your furry companion gets the VIP treatment. From luxury retreats to budget-friendly stays, we've found the perfect spots for 2026.	## Why Leave Your Best Friend Behind?\n\nTravelling across Europe with your pet has never been easier—or more luxurious. Gone are the days when finding quality pet-friendly accommodation meant settling for basic options. In 2026, Europe's hospitality scene has fully embraced four-legged guests, offering everything from dedicated pet concierge services to gourmet pet menus.\n\n## Top Pet-Friendly Hotels Across Europe\n\n### Luxury Options That Pamper Your Pet\n\n**The Egerton House Hotel, London**\nThis boutique gem in Knightsbridge treats pets like royalty. Your dog receives a personalised welcome pack with treats, toys, and a comfortable bed. The hotel's proximity to Hyde Park means excellent walking routes are just minutes away.\n\n**Hotel Sacher, Vienna**\nFamous for its chocolate cake, Hotel Sacher extends its five-star service to pets with custom bedding, food bowls, and even a pet-sitting service. The concierge team can arrange veterinary visits if needed.\n\n**Château de la Resle, Burgundy**\nThis French countryside château welcomes pets into its elegantly restored rooms. Dogs can roam the extensive gardens, and the staff happily provides recommendations for pet-friendly vineyards in the region.\n\n### Budget-Friendly Favourites\n\n**Motel One, Multiple Locations**\nWith properties across Germany, Austria, and beyond, Motel One offers consistent quality without pet fees. Their central locations make city exploration with your companion straightforward.\n\n**Citizenm Hotels, Various Cities**\nModern, affordable, and genuinely welcoming to pets, Citizenm properties feature compact rooms perfect for travellers who prioritise location over space.\n\n## Essential Tips for Hotel Stays with Pets\n\n### Before You Book\n\n- **Confirm pet policies directly**: Weight limits, breed restrictions, and additional fees vary significantly\n- **Request ground-floor rooms**: Easier access for bathroom breaks and emergencies\n- **Ask about nearby amenities**: Parks, veterinary clinics, and pet supply shops\n\n### During Your Stay\n\n- Bring familiar items from home (blankets, favourite toys) to help your pet settle\n- Maintain your pet's regular feeding and walking schedule\n- Use "do not disturb" signs when leaving your pet alone briefly\n- Always clean up after your pet, both indoors and outdoors\n\n### Etiquette Matters\n\n- Keep pets leashed in common areas\n- Notify housekeeping if your pet sheds significantly\n- Report any accidents immediately\n- Tip staff who go above and beyond for your pet\n\n## Planning Your 2026 European Pet Adventure\n\nThe key to stress-free travel with pets lies in preparation. Book accommodations well in advance, especially during peak summer months when pet-friendly rooms fill quickly. Consider travel insurance that covers pet-related incidents, and ensure your pet's vaccinations and microchip details meet EU requirements.\n\n**Ready to explore Europe with your furry friend?** Start researching pet policies at your dream destinations today. The memories you'll create travelling together far outweigh the extra planning required. Whether you're strolling Parisian boulevards or hiking Alpine trails, these pet-friendly hotels ensure both you and your companion enjoy every moment of your European adventure.	4	Best Pet-Friendly Hotels in Europe 2026 | Complete Travel Guide	Planning a European trip with your pet? Discover the best pet-friendly hotels in Europe for 2026, from luxury stays to budget options. Expert tips included.	pet-friendly hotels Europe, travel with pets Europe 2026, dog-friendly hotels, cat-friendly accommodation, pet travel guide Europe, best hotels for pets	\N	none	\N	ai	2026-04-20 09:50:14.779	2026-04-20 11:48:34.914	\N	\N	1	\N	generating	\N
14	tzxlw9wiylcehttx4xah9362	7 Adults-Only All-Inclusive Resorts in Mexico Under $200 Per Night	adults-only-all-inclusive-resorts-mexico-under-200	Discover luxury without the luxury price tag. These seven adults-only all-inclusive resorts in Mexico offer romance, relaxation, and exceptional value at under $200 per night.	## Finding Paradise Without Breaking the Bank\n\nThink adults-only all-inclusive resorts in Mexico are out of reach on a budget? Think again. While many properties command premium prices, savvy travelers can find exceptional value at under $200 per night—especially during shoulder seasons and with strategic booking.\n\nI've scoured Mexico's coastlines to find resorts that deliver the romance, amenities, and tranquility you're craving without the four-figure price tags.\n\n## Top Value Picks Along Mexico's Coasts\n\n### Riviera Maya & Cancún\n\n**Desire Riviera Maya Pearl Resort** frequently dips below $200 during May-June and September-October. This clothing-optional property offers unlimited premium drinks, gourmet dining, and a genuinely relaxed vibe that's perfect for adventurous couples.\n\n**Temptation Cancún Resort** combines party atmosphere with all-inclusive value. Expect themed nights, multiple pools, and surprisingly good food quality. Best rates appear mid-week during summer months.\n\n### Puerto Vallarta\n\n**Secrets Vallarta Bay** sometimes sneaks under the $200 mark with advance booking. You'll get gorgeous Pacific sunsets, multiple dining venues, and the brand's signature "Unlimited Luxury" experience.\n\n**Villa Premiere Boutique Hotel & Romantic Getaway** offers an intimate adults-only experience right on the Malecón. The smaller size means personalized service, and packages often include spa credits.\n\n## Insider Tips for Maximum Value\n\n**Book During Shoulder Season**: Late April through mid-June and September through early November offer the sweet spot—lower rates with decent weather. Yes, you might see afternoon showers, but you'll save 30-50% compared to peak winter months.\n\n**Consider Smaller Properties**: Boutique resorts with 100-200 rooms often provide better value and service than mega-resorts. You'll get more personalized attention and authentic experiences.\n\n**Watch for Flash Sales**: Sign up for email alerts from resort chains like Secrets, Breathless, and Desire. Flash sales can drop rates 40% overnight, especially for travel 60+ days out.\n\n**Use Points Strategically**: Some resorts participate in loyalty programs. Transferring credit card points to hotel programs can stretch your budget significantly.\n\n## What to Expect at This Price Point\n\nAt under $200 per night, you'll typically find:\n\n- **3-5 restaurants** with à la carte and buffet options\n- **Premium open bar** (top-shelf spirits included)\n- **Basic water sports** like kayaking and snorkeling\n- **Nightly entertainment** ranging from live music to shows\n- **Fitness facilities** and pool access\n- **Daily housekeeping** and room service\n\nWhat you might sacrifice compared to ultra-luxury properties: butler service, Michelin-level dining, and brand-new facilities. But honestly? The value is outstanding.\n\n## Ready to Book Your Escape?\n\nAdults-only all-inclusive resorts in Mexico offer incredible value when you know where to look. Start your search 6-8 months out for the best selection, stay flexible with dates, and don't hesitate to call resorts directly—they often match or beat online rates.\n\nYour romantic, stress-free Mexican getaway is more affordable than you think. Start browsing those shoulder season dates now, and prepare for paradise without the premium price tag.\n\n*Pro tip: Always confirm what's included before booking. Some "all-inclusive" properties charge extra for premium dining or activities.*	4	Adults-Only All-Inclusive Mexico Resorts Under $200/Night (2024)	Find the best adults-only all-inclusive resorts in Mexico for under $200 per night. Expert tips on booking, timing, and maximizing value along Mexico's coast.	adults-only resorts Mexico, all-inclusive Mexico under 200, budget all-inclusive Mexico, Riviera Maya adults-only, Puerto Vallarta resorts, affordable Mexico resorts, couples resorts Mexico budget	\N	none	\N	ai	2026-04-20 09:52:22.192	2026-04-20 09:52:22.192	\N	\N	\N	\N	\N	\N
15	tzxlw9wiylcehttx4xah9362	7 Adults-Only All-Inclusive Resorts in Mexico Under $200 Per Night	adults-only-all-inclusive-resorts-mexico-under-200	Discover luxury without the luxury price tag. These seven adults-only all-inclusive resorts in Mexico offer romance, relaxation, and exceptional value at under $200 per night.	## Finding Paradise Without Breaking the Bank\n\nThink adults-only all-inclusive resorts in Mexico are out of reach on a budget? Think again. While many properties command premium prices, savvy travelers can find exceptional value at under $200 per night—especially during shoulder seasons and with strategic booking.\n\nI've scoured Mexico's coastlines to find resorts that deliver the romance, amenities, and tranquility you're craving without the four-figure price tags.\n\n## Top Value Picks Along Mexico's Coasts\n\n### Riviera Maya & Cancún\n\n**Desire Riviera Maya Pearl Resort** frequently dips below $200 during May-June and September-October. This clothing-optional property offers unlimited premium drinks, gourmet dining, and a genuinely relaxed vibe that's perfect for adventurous couples.\n\n**Temptation Cancún Resort** combines party atmosphere with all-inclusive value. Expect themed nights, multiple pools, and surprisingly good food quality. Best rates appear mid-week during summer months.\n\n### Puerto Vallarta\n\n**Secrets Vallarta Bay** sometimes sneaks under the $200 mark with advance booking. You'll get gorgeous Pacific sunsets, multiple dining venues, and the brand's signature "Unlimited Luxury" experience.\n\n**Villa Premiere Boutique Hotel & Romantic Getaway** offers an intimate adults-only experience right on the Malecón. The smaller size means personalized service, and packages often include spa credits.\n\n## Insider Tips for Maximum Value\n\n**Book During Shoulder Season**: Late April through mid-June and September through early November offer the sweet spot—lower rates with decent weather. Yes, you might see afternoon showers, but you'll save 30-50% compared to peak winter months.\n\n**Consider Smaller Properties**: Boutique resorts with 100-200 rooms often provide better value and service than mega-resorts. You'll get more personalized attention and authentic experiences.\n\n**Watch for Flash Sales**: Sign up for email alerts from resort chains like Secrets, Breathless, and Desire. Flash sales can drop rates 40% overnight, especially for travel 60+ days out.\n\n**Use Points Strategically**: Some resorts participate in loyalty programs. Transferring credit card points to hotel programs can stretch your budget significantly.\n\n## What to Expect at This Price Point\n\nAt under $200 per night, you'll typically find:\n\n- **3-5 restaurants** with à la carte and buffet options\n- **Premium open bar** (top-shelf spirits included)\n- **Basic water sports** like kayaking and snorkeling\n- **Nightly entertainment** ranging from live music to shows\n- **Fitness facilities** and pool access\n- **Daily housekeeping** and room service\n\nWhat you might sacrifice compared to ultra-luxury properties: butler service, Michelin-level dining, and brand-new facilities. But honestly? The value is outstanding.\n\n## Ready to Book Your Escape?\n\nAdults-only all-inclusive resorts in Mexico offer incredible value when you know where to look. Start your search 6-8 months out for the best selection, stay flexible with dates, and don't hesitate to call resorts directly—they often match or beat online rates.\n\nYour romantic, stress-free Mexican getaway is more affordable than you think. Start browsing those shoulder season dates now, and prepare for paradise without the premium price tag.\n\n*Pro tip: Always confirm what's included before booking. Some "all-inclusive" properties charge extra for premium dining or activities.*	4	Adults-Only All-Inclusive Mexico Resorts Under $200/Night (2024)	Find the best adults-only all-inclusive resorts in Mexico for under $200 per night. Expert tips on booking, timing, and maximizing value along Mexico's coast.	adults-only resorts Mexico, all-inclusive Mexico under 200, budget all-inclusive Mexico, Riviera Maya adults-only, Puerto Vallarta resorts, affordable Mexico resorts, couples resorts Mexico budget	\N	none	\N	ai	2026-04-20 09:52:22.192	2026-04-20 09:52:22.192	2026-04-20 09:52:22.225	\N	\N	\N	\N	\N
10	avdcdprn4q9wjglubafxrxz7	How to Score Free Hotel Upgrades: Insider Tips for 2026	how-to-score-free-hotel-upgrades-insider-tips-2026	Want to enjoy a suite without paying suite prices? Learn the proven strategies savvy travelers use to land complimentary hotel upgrades in 2026, from timing tricks to loyalty hacks.	# How to Score Free Hotel Upgrades: Insider Tips for 2026\n\nWho doesn't love walking into a hotel expecting a standard room and getting upgraded to a suite with a view? Free hotel upgrades aren't just lucky accidents—they're often the result of smart planning and knowing exactly what to do. Here's how to dramatically increase your chances of snagging that complimentary upgrade in 2026.\n\n## Join (and Actually Use) Hotel Loyalty Programs\n\nThis is the single most effective strategy. Hotel chains prioritize their loyal members when distributing upgrades, and membership is almost always free.\n\n- **Concentrate your stays**: Pick 1-2 hotel brands and stick with them rather than spreading bookings across many chains\n- **Elite status matters**: Even mid-tier status can put you ahead of non-members in the upgrade queue\n- **Link your profile**: Always ensure your loyalty number is attached to every reservation\n\nIn 2026, major chains like Marriott, Hilton, and IHG continue offering generous elite benefits, including complimentary room upgrades based on availability.\n\n## Master the Art of Timing\n\nWhen you book and when you arrive can make all the difference.\n\n**Book directly** through the hotel's website or app—never through third-party sites. Hotels have zero incentive to upgrade OTA bookings, and they often flag these reservations as lower priority.\n\n**Check in late afternoon** (around 3-5 PM) when the front desk has a clear picture of available inventory. Too early, and they won't know what's free. Too late, and upgrades may already be assigned.\n\n**Travel midweek** when hotels have lower occupancy. Your Tuesday night stay has better upgrade odds than Friday or Saturday.\n\n## Communicate Smartly at Check-In\n\nYour interaction with front desk staff matters more than you think.\n\n- **Be genuinely kind**: A warm smile and pleasant conversation go surprisingly far\n- **Mention special occasions**: Celebrating an anniversary or birthday? Politely mention it—hotels often note these in their system\n- **Ask politely, don't demand**: "Are there any complimentary upgrades available?" works better than expecting one\n- **Skip the bribery**: The "$20 sandwich trick" is outdated and can be awkward; loyalty status works better\n\n## Leverage Your Booking Strategy\n\nBook the cheapest flexible rate in the lowest room category. Hotels upgrade from the bottom up, and you can't be upgraded if you've already booked the second-best room. Starting at the entry level gives you maximum upgrade runway.\n\nConsider booking refundable rates during low-demand periods. You can always cancel if plans change, and hotels are more generous with upgrades when they're not fully booked.\n\n## The Bottom Line\n\nFree hotel upgrades in 2026 aren't about luck—they're about strategy. Build loyalty with specific brands, book smart, time your check-ins right, and treat hotel staff with genuine respect. These simple tactics can transform your standard room into a suite without spending an extra dollar.\n\nReady to level up your next hotel stay? Start building that loyalty status today, and watch the upgrades roll in throughout the year.	3	Free Hotel Upgrades 2026: Insider Tips That Actually Work	Discover proven strategies to score free hotel room upgrades in 2026. Learn loyalty program hacks, booking tactics, and check-in tips that get results.	free hotel upgrades, hotel upgrade tips 2026, complimentary room upgrades, hotel loyalty programs, how to get upgraded hotel room, hotel booking strategies, travel hacks hotels	\N	none	\N	ai	2026-04-20 09:51:06.53	2026-04-20 10:24:47.645	\N	\N	1	\N	\N	\N
18	avdcdprn4q9wjglubafxrxz7	How to Score Free Hotel Upgrades: Insider Tips for 2026	how-to-score-free-hotel-upgrades-insider-tips-2026	Want to enjoy a suite without paying suite prices? Learn the proven strategies savvy travelers use to land complimentary hotel upgrades in 2026, from timing tricks to loyalty hacks.	# How to Score Free Hotel Upgrades: Insider Tips for 2026\n\nWho doesn't love walking into a hotel expecting a standard room and getting upgraded to a suite with a view? Free hotel upgrades aren't just lucky accidents—they're often the result of smart planning and knowing exactly what to do. Here's how to dramatically increase your chances of snagging that complimentary upgrade in 2026.\n\n## Join (and Actually Use) Hotel Loyalty Programs\n\nThis is the single most effective strategy. Hotel chains prioritize their loyal members when distributing upgrades, and membership is almost always free.\n\n- **Concentrate your stays**: Pick 1-2 hotel brands and stick with them rather than spreading bookings across many chains\n- **Elite status matters**: Even mid-tier status can put you ahead of non-members in the upgrade queue\n- **Link your profile**: Always ensure your loyalty number is attached to every reservation\n\nIn 2026, major chains like Marriott, Hilton, and IHG continue offering generous elite benefits, including complimentary room upgrades based on availability.\n\n## Master the Art of Timing\n\nWhen you book and when you arrive can make all the difference.\n\n**Book directly** through the hotel's website or app—never through third-party sites. Hotels have zero incentive to upgrade OTA bookings, and they often flag these reservations as lower priority.\n\n**Check in late afternoon** (around 3-5 PM) when the front desk has a clear picture of available inventory. Too early, and they won't know what's free. Too late, and upgrades may already be assigned.\n\n**Travel midweek** when hotels have lower occupancy. Your Tuesday night stay has better upgrade odds than Friday or Saturday.\n\n## Communicate Smartly at Check-In\n\nYour interaction with front desk staff matters more than you think.\n\n- **Be genuinely kind**: A warm smile and pleasant conversation go surprisingly far\n- **Mention special occasions**: Celebrating an anniversary or birthday? Politely mention it—hotels often note these in their system\n- **Ask politely, don't demand**: "Are there any complimentary upgrades available?" works better than expecting one\n- **Skip the bribery**: The "$20 sandwich trick" is outdated and can be awkward; loyalty status works better\n\n## Leverage Your Booking Strategy\n\nBook the cheapest flexible rate in the lowest room category. Hotels upgrade from the bottom up, and you can't be upgraded if you've already booked the second-best room. Starting at the entry level gives you maximum upgrade runway.\n\nConsider booking refundable rates during low-demand periods. You can always cancel if plans change, and hotels are more generous with upgrades when they're not fully booked.\n\n## The Bottom Line\n\nFree hotel upgrades in 2026 aren't about luck—they're about strategy. Build loyalty with specific brands, book smart, time your check-ins right, and treat hotel staff with genuine respect. These simple tactics can transform your standard room into a suite without spending an extra dollar.\n\nReady to level up your next hotel stay? Start building that loyalty status today, and watch the upgrades roll in throughout the year.	3	Free Hotel Upgrades 2026: Insider Tips That Actually Work	Discover proven strategies to score free hotel room upgrades in 2026. Learn loyalty program hacks, booking tactics, and check-in tips that get results.	free hotel upgrades, hotel upgrade tips 2026, complimentary room upgrades, hotel loyalty programs, how to get upgraded hotel room, hotel booking strategies, travel hacks hotels	\N	none	\N	ai	2026-04-20 09:51:06.53	2026-04-20 10:24:47.645	2026-04-20 10:24:47.726	\N	1	\N	\N	\N
19	vnfu97g74nbile6h2z99du40	5 Ultra-Cool Boutique Hotels Opening in Tokyo This Spring 2024	coolest-boutique-hotels-tokyo-spring-2024	Tokyo's boutique hotel scene is exploding this spring with five design-forward properties that blend Japanese minimalism with cutting-edge hospitality. Here's your insider guide.	## Tokyo's Boutique Hotel Renaissance\n\nTokyo is having a serious moment in the boutique hotel world this spring, and if you're planning a trip between March and May 2024, you're in for a treat. Forget cookie-cutter chains—these five new properties are redefining what it means to stay stylish in Japan's capital.\n\n## The Standouts Opening This Season\n\n### Azabu Harmony House (Roppongi, Opens March)\n\nThis 18-room gem in Azabu-Juban marries traditional ryokan elements with Scandinavian design. Each room features custom tatami platforms, rain showers with Mount Fuji views, and a curated selection of Japanese craft gin. The rooftop onsen is the real showstopper—book the sunset slot if you can.\n\n**What makes it special:** In-room sake sommelier service and partnerships with local artisans for exclusive shopping experiences.\n\n### Shibuya Canvas Loft (Shibuya, Opens April)\n\nThink industrial-chic meets Tokyo street culture. This 24-room property occupies a renovated 1970s office building with exposed concrete, floor-to-ceiling windows, and an Instagram-worthy cafe serving third-wave coffee and Japanese-French pastries.\n\n**Insider tip:** Request a room on floors 5-7 for unobstructed Shibuya Crossing views.\n\n### The Kagurazaka Edit (Kagurazaka, Opens April)\n\nNestled in Tokyo's most charming neighbourhood, this 12-suite boutique hotel feels like staying at a sophisticated friend's minimalist apartment. Each suite includes a compact kitchen stocked with locally-sourced ingredients, perfect for travellers who want to shop at nearby markets.\n\n**Don't miss:** The hotel's curated walking tours of hidden Kagurazaka temples and izakayas.\n\n### Ginza Velvet Minimal (Ginza, Opens May)\n\nLuxury without the stuffiness—that's Ginza Velvet's promise. With only 15 rooms, this property focuses on texture and craftsmanship: hand-plastered walls, vintage Japanese ceramics, and beds dressed in Imabari cotton that feels like sleeping on clouds.\n\n**Pro move:** The concierge has access to impossible-to-book sushi restaurants. Use this power wisely.\n\n### Yanaka Heritage Stays (Yanaka, Opens May)\n\nThe most authentic of the bunch, Yanaka Heritage transforms four traditional machiya townhouses into boutique accommodations. You'll sleep on futons, use cypress wood baths, and wake to birdsong in old Tokyo's most preserved neighbourhood.\n\n**Perfect for:** Travellers craving cultural immersion over trendy amenities.\n\n## Booking Tips for Spring 2024\n\n- **Book now:** These properties are already generating buzz, and Tokyo's spring cherry blossom season fills up fast\n- **Check package deals:** Several hotels offer opening specials with perks like airport transfers or kaiseki dinners\n- **Consider weekdays:** You'll save 30-40% and have a quieter experience\n\n## Why Spring Timing Matters\n\nBeyond avoiding the summer humidity and securing opening rates, spring in Tokyo means cherry blossoms, perfect walking weather, and these hotels will still have that fresh, eager-to-impress energy.\n\n**Ready to experience Tokyo's boutique hotel revolution?** These five properties prove that the city's accommodation scene is finally catching up to its reputation for design excellence. Book early, pack light, and prepare for a stay that's as memorable as the city itself.	4	5 Best New Boutique Hotels in Tokyo Opening Spring 2024	Discover Tokyo's coolest new boutique hotels opening spring 2024. From Shibuya lofts to traditional Yanaka machiya stays—insider booking tips included.	Tokyo boutique hotels 2024, new hotels Tokyo spring, best boutique hotels Tokyo, Tokyo accommodation, Shibuya hotels, Ginza hotels, where to stay Tokyo	\N	none	\N	ai	2026-04-20 09:51:32.85	2026-04-20 10:25:03.45	2026-04-20 10:25:03.523	\N	1	\N	\N	\N
20	mnm7vz1drfajwx3u5tw7z1j6	10 Underrated European Cities to Visit in 2026	underrated-european-cities-2026	Skip the tourist crowds in Paris and Rome. Discover 10 hidden European gems offering authentic culture, incredible food, and half the cost—perfect for your 2026 travel bucket list.	## Why 2026 Is the Year to Explore Europe's Hidden Gems\n\nTired of battling crowds at the Eiffel Tower or paying €8 for coffee in Venice? You're not alone. Smart travelers are ditching Europe's overtouristed hotspots for lesser-known cities that deliver authentic experiences without the chaos—or the inflated prices.\n\nHere are 10 underrated European cities that deserve a spot on your 2026 itinerary.\n\n## 1. Porto, Portugal\n\nLisbon's cooler older sibling offers stunning riverside views, world-class port wine cellars, and azulejo-tiled streets you'll have mostly to yourself. The food scene is exceptional, and accommodation costs about 40% less than Lisbon.\n\n## 2. Ljubljana, Slovenia\n\nThis charming capital feels like a fairytale village that accidentally became a city. With a car-free old town, a hilltop castle, and some of Central Europe's best farm-to-table restaurants, Ljubljana punches way above its weight.\n\n## 3. Ghent, Belgium\n\nBruges gets all the attention, but Ghent has medieval architecture, better beer bars, and actual Belgian locals living their lives. Plus, it's a perfect base for exploring Flanders by train.\n\n## 4. Lecce, Italy\n\nThe "Florence of the South" serves up Baroque splendor, outstanding Puglian cuisine, and beaches just 20 minutes away. You'll experience authentic Italian life without the tour bus crowds.\n\n## 5. Gdańsk, Poland\n\nThis Baltic port city combines colorful merchant houses, WWII history, and a thriving craft beer scene. It's also incredibly affordable—your budget will stretch twice as far here as in Western Europe.\n\n## 6. San Sebastián, Spain\n\nYes, foodies know about this Basque culinary capital, but it remains refreshingly uncrowded compared to Barcelona. The pintxos (Basque tapas) scene is legendary, and the urban beaches are stunning.\n\n## 7. Tallinn, Estonia\n\nMedieval walls meet digital innovation in this Baltic gem. The old town feels like stepping into a storybook, while the new city buzzes with creative energy. Weekend breaks here offer incredible value.\n\n## 8. Mostar, Bosnia and Herzegovina\n\nThe iconic Stari Most bridge, Ottoman architecture, and genuine warmth of the locals make Mostar unforgettable. It's one of Europe's most affordable destinations, with rich coffee culture and fascinating history.\n\n## 9. Timișoara, Romania\n\nRomania's 2023 European Capital of Culture is still flying under most travelers' radars. Art Nouveau buildings, lively squares, and vibrant nightlife await—all at prices that'll make you double-check the bill.\n\n## 10. Bergen, Norway\n\nYes, Norway is expensive, but Bergen's colorful Bryggen wharf, surrounding fjords, and gateway to epic nature make it worth every krone. Visit in shoulder season (May or September) for better deals and fewer crowds.\n\n## Start Planning Your 2026 European Adventure\n\nThese cities offer something precious: the chance to experience Europe as it used to be—personal, authentic, and surprising. Book flights early for 2026, especially to Eastern European destinations where airline capacity is still limited. Your future self will thank you for choosing the path less traveled.\n\nWhich underrated city will you visit first?	3	10 Underrated European Cities to Visit in 2026 | Hidden Gems	Discover 10 incredible European cities without the tourist crowds. From Porto to Tallinn, these hidden gems offer authentic culture and great value for 2026.	underrated European cities, Europe travel 2026, hidden gems Europe, alternative European destinations, budget Europe travel, off-beaten-path Europe, best European cities, Europe itinerary 2026	\N	none	\N	ai	2026-04-20 10:28:17.328	2026-04-20 10:28:17.328	\N	\N	\N	\N	\N	\N
21	mnm7vz1drfajwx3u5tw7z1j6	10 Underrated European Cities to Visit in 2026	underrated-european-cities-2026	Skip the tourist crowds in Paris and Rome. Discover 10 hidden European gems offering authentic culture, incredible food, and half the cost—perfect for your 2026 travel bucket list.	## Why 2026 Is the Year to Explore Europe's Hidden Gems\n\nTired of battling crowds at the Eiffel Tower or paying €8 for coffee in Venice? You're not alone. Smart travelers are ditching Europe's overtouristed hotspots for lesser-known cities that deliver authentic experiences without the chaos—or the inflated prices.\n\nHere are 10 underrated European cities that deserve a spot on your 2026 itinerary.\n\n## 1. Porto, Portugal\n\nLisbon's cooler older sibling offers stunning riverside views, world-class port wine cellars, and azulejo-tiled streets you'll have mostly to yourself. The food scene is exceptional, and accommodation costs about 40% less than Lisbon.\n\n## 2. Ljubljana, Slovenia\n\nThis charming capital feels like a fairytale village that accidentally became a city. With a car-free old town, a hilltop castle, and some of Central Europe's best farm-to-table restaurants, Ljubljana punches way above its weight.\n\n## 3. Ghent, Belgium\n\nBruges gets all the attention, but Ghent has medieval architecture, better beer bars, and actual Belgian locals living their lives. Plus, it's a perfect base for exploring Flanders by train.\n\n## 4. Lecce, Italy\n\nThe "Florence of the South" serves up Baroque splendor, outstanding Puglian cuisine, and beaches just 20 minutes away. You'll experience authentic Italian life without the tour bus crowds.\n\n## 5. Gdańsk, Poland\n\nThis Baltic port city combines colorful merchant houses, WWII history, and a thriving craft beer scene. It's also incredibly affordable—your budget will stretch twice as far here as in Western Europe.\n\n## 6. San Sebastián, Spain\n\nYes, foodies know about this Basque culinary capital, but it remains refreshingly uncrowded compared to Barcelona. The pintxos (Basque tapas) scene is legendary, and the urban beaches are stunning.\n\n## 7. Tallinn, Estonia\n\nMedieval walls meet digital innovation in this Baltic gem. The old town feels like stepping into a storybook, while the new city buzzes with creative energy. Weekend breaks here offer incredible value.\n\n## 8. Mostar, Bosnia and Herzegovina\n\nThe iconic Stari Most bridge, Ottoman architecture, and genuine warmth of the locals make Mostar unforgettable. It's one of Europe's most affordable destinations, with rich coffee culture and fascinating history.\n\n## 9. Timișoara, Romania\n\nRomania's 2023 European Capital of Culture is still flying under most travelers' radars. Art Nouveau buildings, lively squares, and vibrant nightlife await—all at prices that'll make you double-check the bill.\n\n## 10. Bergen, Norway\n\nYes, Norway is expensive, but Bergen's colorful Bryggen wharf, surrounding fjords, and gateway to epic nature make it worth every krone. Visit in shoulder season (May or September) for better deals and fewer crowds.\n\n## Start Planning Your 2026 European Adventure\n\nThese cities offer something precious: the chance to experience Europe as it used to be—personal, authentic, and surprising. Book flights early for 2026, especially to Eastern European destinations where airline capacity is still limited. Your future self will thank you for choosing the path less traveled.\n\nWhich underrated city will you visit first?	3	10 Underrated European Cities to Visit in 2026 | Hidden Gems	Discover 10 incredible European cities without the tourist crowds. From Porto to Tallinn, these hidden gems offer authentic culture and great value for 2026.	underrated European cities, Europe travel 2026, hidden gems Europe, alternative European destinations, budget Europe travel, off-beaten-path Europe, best European cities, Europe itinerary 2026	\N	none	\N	ai	2026-04-20 10:28:17.328	2026-04-20 10:28:17.328	2026-04-20 10:28:17.364	\N	\N	\N	\N	\N
23	neuvd0ztvjogxl0yvl04jd6c	12 Free Travel Apps That'll Save You $500+ on Your 2026 Trips	12-free-travel-apps-save-money-2026-trips	Discover the dozen free mobile apps savvy travelers are using to slash flight costs, score hotel deals, and avoid hidden fees—potentially saving you hundreds on every trip you take this year.	# 12 Free Travel Apps That'll Save You $500+ on Your 2026 Trips\n\nLet's be honest: travel apps have become absolute game-changers for budget-conscious globetrotters. After testing dozens of platforms over the past year, I've narrowed down the twelve free apps that consistently deliver real savings—not just empty promises.\n\n## Flight & Accommodation Money-Savers\n\n### Hopper\nThis predictive pricing app analyzes billions of flight prices daily and tells you exactly when to book. Its "freeze price" feature alone saved me $180 on a London flight by locking in rates while I finalized my plans.\n\n### Google Flights\nThe flexible date grid is unmatched for finding the cheapest days to fly. Set up price alerts, and you'll get notifications the moment fares drop on your desired routes.\n\n### Skyscanner\nPerfect for exploring "everywhere" destinations when you're flexible. The "whole month" view helped me discover a $320 round-trip to Barcelona I'd never have found otherwise.\n\n### Hotel Tonight\nDespite the name, it works for advance bookings too. Last-minute deals regularly beat Booking.com and Expedia by 30-40%.\n\n## Navigation & Local Experience Apps\n\n### Maps.me\nDownload offline maps before you travel and avoid international data charges. I've saved countless roaming fees across Europe and Asia with this essential tool.\n\n### Rome2rio\nCompares every possible transportation option between two points—flights, trains, buses, ferries. It showed me a €15 bus route when everyone else was booking €89 flights.\n\n### XE Currency\nSeems basic, but offline currency conversion prevents you from getting ripped off at exchange counters. Knowledge is savings.\n\n## Food & Activities on a Budget\n\n### Too Good To Go\nRescue surplus food from restaurants and bakeries at 50-70% off. I've enjoyed €15 meals for €4 across multiple European cities.\n\n### Eatwith\nFind authentic home-cooked meals with locals for less than typical tourist restaurants—plus you'll get insider travel tips.\n\n### Free Walking Tour\nAggregates tip-based walking tours worldwide. Pay what you feel the experience was worth instead of €25+ fixed-price tours.\n\n## Money Management Tools\n\n### Revolut\nZero foreign transaction fees and excellent exchange rates. Over a two-week international trip, this saved me approximately $75 compared to using my regular credit card.\n\n### Trail Wallet\nTrack daily spending in multiple currencies to avoid budget blowouts. Simple awareness helped me reduce overspending by 20% on my last three trips.\n\n## The Bottom Line\n\nUsing even five of these apps strategically can easily save $500+ per trip. The key is downloading them before you travel, setting up alerts, and actually comparing prices rather than booking the first option you see.\n\n**Ready to maximize your travel budget?** Download three of these apps today and run a test search for your next trip. You'll likely find immediate savings that'll have you wondering why you didn't start sooner. Your future well-traveled self will thank you.	3	12 Free Travel Apps to Save $500+ in 2026 | Money-Saving Guide	Download these 12 free travel apps to save $500+ on flights, hotels, and activities in 2026. Expert-tested tools for budget travelers who refuse to overpay.	free travel apps, save money traveling, budget travel apps 2026, cheap flights apps, hotel deals apps, travel budget tools, money-saving travel	\N	none	\N	ai	2026-04-20 10:36:11.65	2026-04-20 10:36:11.65	\N	\N	\N	\N	\N	\N
24	neuvd0ztvjogxl0yvl04jd6c	12 Free Travel Apps That'll Save You $500+ on Your 2026 Trips	12-free-travel-apps-save-money-2026-trips	Discover the dozen free mobile apps savvy travelers are using to slash flight costs, score hotel deals, and avoid hidden fees—potentially saving you hundreds on every trip you take this year.	# 12 Free Travel Apps That'll Save You $500+ on Your 2026 Trips\n\nLet's be honest: travel apps have become absolute game-changers for budget-conscious globetrotters. After testing dozens of platforms over the past year, I've narrowed down the twelve free apps that consistently deliver real savings—not just empty promises.\n\n## Flight & Accommodation Money-Savers\n\n### Hopper\nThis predictive pricing app analyzes billions of flight prices daily and tells you exactly when to book. Its "freeze price" feature alone saved me $180 on a London flight by locking in rates while I finalized my plans.\n\n### Google Flights\nThe flexible date grid is unmatched for finding the cheapest days to fly. Set up price alerts, and you'll get notifications the moment fares drop on your desired routes.\n\n### Skyscanner\nPerfect for exploring "everywhere" destinations when you're flexible. The "whole month" view helped me discover a $320 round-trip to Barcelona I'd never have found otherwise.\n\n### Hotel Tonight\nDespite the name, it works for advance bookings too. Last-minute deals regularly beat Booking.com and Expedia by 30-40%.\n\n## Navigation & Local Experience Apps\n\n### Maps.me\nDownload offline maps before you travel and avoid international data charges. I've saved countless roaming fees across Europe and Asia with this essential tool.\n\n### Rome2rio\nCompares every possible transportation option between two points—flights, trains, buses, ferries. It showed me a €15 bus route when everyone else was booking €89 flights.\n\n### XE Currency\nSeems basic, but offline currency conversion prevents you from getting ripped off at exchange counters. Knowledge is savings.\n\n## Food & Activities on a Budget\n\n### Too Good To Go\nRescue surplus food from restaurants and bakeries at 50-70% off. I've enjoyed €15 meals for €4 across multiple European cities.\n\n### Eatwith\nFind authentic home-cooked meals with locals for less than typical tourist restaurants—plus you'll get insider travel tips.\n\n### Free Walking Tour\nAggregates tip-based walking tours worldwide. Pay what you feel the experience was worth instead of €25+ fixed-price tours.\n\n## Money Management Tools\n\n### Revolut\nZero foreign transaction fees and excellent exchange rates. Over a two-week international trip, this saved me approximately $75 compared to using my regular credit card.\n\n### Trail Wallet\nTrack daily spending in multiple currencies to avoid budget blowouts. Simple awareness helped me reduce overspending by 20% on my last three trips.\n\n## The Bottom Line\n\nUsing even five of these apps strategically can easily save $500+ per trip. The key is downloading them before you travel, setting up alerts, and actually comparing prices rather than booking the first option you see.\n\n**Ready to maximize your travel budget?** Download three of these apps today and run a test search for your next trip. You'll likely find immediate savings that'll have you wondering why you didn't start sooner. Your future well-traveled self will thank you.	3	12 Free Travel Apps to Save $500+ in 2026 | Money-Saving Guide	Download these 12 free travel apps to save $500+ on flights, hotels, and activities in 2026. Expert-tested tools for budget travelers who refuse to overpay.	free travel apps, save money traveling, budget travel apps 2026, cheap flights apps, hotel deals apps, travel budget tools, money-saving travel	\N	none	\N	ai	2026-04-20 10:36:11.65	2026-04-20 10:36:11.65	2026-04-20 10:36:11.682	\N	\N	\N	\N	\N
27	mn7xyvzitswwk125sja5k0qt	7 Smart Ways to Beat Airport Crowds in Summer 2026	beat-airport-crowds-summer-2026	Summer 2026 travel is set to break records. Skip the chaos with these proven strategies to breeze through security, avoid peak times, and reclaim your sanity at the airport.	## Why Summer 2026 Will Be Airport Chaos\n\nSummer 2026 is shaping up to be the busiest travel season on record. Airlines are projecting passenger numbers 15% higher than 2025, and airports worldwide are already warning of longer wait times. But you don't have to join the stressed masses. Here's how to outsmart the crowds and start your holiday on a high note.\n\n## 1. Fly on Off-Peak Days and Times\n\nTuesdays, Wednesdays, and Saturdays see significantly fewer travelers than Fridays and Sundays. Early morning flights (before 7 AM) and red-eyes consistently have shorter security lines. Yes, it means setting an alarm, but you'll glide through checkpoints while others are still stuck in hour-long queues.\n\n## 2. Check In Online and Go Carry-On Only\n\nCheck-in opens 24 hours before departure—set a reminder and do it immediately. Download your boarding pass to your phone and enable notifications. Even better, pack light and skip checked baggage entirely. You'll bypass bag-drop lines and won't waste 30 minutes at the carousel on arrival.\n\n## 3. Enroll in TSA PreCheck or Global Entry\n\nThese programs cost around $78-100 for five years and consistently save 20-40 minutes per trip. TSA PreCheck gets you through security faster domestically, while Global Entry includes PreCheck plus expedited customs when returning from abroad. Apply now—processing takes 4-6 weeks, and you want approval before summer hits.\n\n## 4. Use Airport Apps for Real-Time Updates\n\nMost major airports now have apps showing live security wait times by checkpoint. Download your departure airport's app and check it before leaving home. If Terminal B shows a 10-minute wait while Terminal A shows 45 minutes, you've just saved half an hour with a simple detour.\n\n## 5. Book Airport Lounges in Advance\n\nLounges aren't just for business class anymore. Services like Priority Pass or LoungeBuddy let you book access for $30-50. You'll escape the gate-area madness with comfortable seating, free food and drinks, and reliable Wi-Fi. Many credit cards include lounge access—check yours before paying.\n\n## 6. Arrive Early, But Not Too Early\n\nFor domestic flights, aim for 90 minutes before departure during summer peak. International? Make it 3 hours. Arriving 4+ hours early just means more time battling crowds. Most airports don't open security checkpoints until 4-5 hours before the first flight anyway.\n\n## 7. Monitor Your Flight Like a Hawk\n\nGate changes and delays spike during summer. Enable push notifications from your airline's app and check your flight status every few hours starting the night before. Being first to know about changes means you can rebook on earlier flights or snag better seats while everyone else is still in the dark.\n\n## Your Sanity Is Worth Planning Ahead\n\nSummer 2026 doesn't have to mean airport stress. These seven strategies take minimal effort but deliver maximum calm. Book smart, prepare early, and you'll be sipping cocktails at your destination while others are still queuing at security. Safe travels!	4	Beat Airport Crowds: 7 Smart Tips for Summer 2026 Travel	Skip the summer airport chaos with these 7 proven strategies. Learn the best times to fly, security shortcuts, and insider tips for stress-free travel in 2026.	airport crowds summer 2026, beat airport lines, TSA PreCheck tips, best time to fly summer, avoid airport crowds, airport travel hacks, summer travel tips 2026	\N	none	\N	ai	2026-04-20 10:43:17.522	2026-04-20 10:43:17.522	\N	\N	\N	\N	\N	\N
28	mn7xyvzitswwk125sja5k0qt	7 Smart Ways to Beat Airport Crowds in Summer 2026	beat-airport-crowds-summer-2026	Summer 2026 travel is set to break records. Skip the chaos with these proven strategies to breeze through security, avoid peak times, and reclaim your sanity at the airport.	## Why Summer 2026 Will Be Airport Chaos\n\nSummer 2026 is shaping up to be the busiest travel season on record. Airlines are projecting passenger numbers 15% higher than 2025, and airports worldwide are already warning of longer wait times. But you don't have to join the stressed masses. Here's how to outsmart the crowds and start your holiday on a high note.\n\n## 1. Fly on Off-Peak Days and Times\n\nTuesdays, Wednesdays, and Saturdays see significantly fewer travelers than Fridays and Sundays. Early morning flights (before 7 AM) and red-eyes consistently have shorter security lines. Yes, it means setting an alarm, but you'll glide through checkpoints while others are still stuck in hour-long queues.\n\n## 2. Check In Online and Go Carry-On Only\n\nCheck-in opens 24 hours before departure—set a reminder and do it immediately. Download your boarding pass to your phone and enable notifications. Even better, pack light and skip checked baggage entirely. You'll bypass bag-drop lines and won't waste 30 minutes at the carousel on arrival.\n\n## 3. Enroll in TSA PreCheck or Global Entry\n\nThese programs cost around $78-100 for five years and consistently save 20-40 minutes per trip. TSA PreCheck gets you through security faster domestically, while Global Entry includes PreCheck plus expedited customs when returning from abroad. Apply now—processing takes 4-6 weeks, and you want approval before summer hits.\n\n## 4. Use Airport Apps for Real-Time Updates\n\nMost major airports now have apps showing live security wait times by checkpoint. Download your departure airport's app and check it before leaving home. If Terminal B shows a 10-minute wait while Terminal A shows 45 minutes, you've just saved half an hour with a simple detour.\n\n## 5. Book Airport Lounges in Advance\n\nLounges aren't just for business class anymore. Services like Priority Pass or LoungeBuddy let you book access for $30-50. You'll escape the gate-area madness with comfortable seating, free food and drinks, and reliable Wi-Fi. Many credit cards include lounge access—check yours before paying.\n\n## 6. Arrive Early, But Not Too Early\n\nFor domestic flights, aim for 90 minutes before departure during summer peak. International? Make it 3 hours. Arriving 4+ hours early just means more time battling crowds. Most airports don't open security checkpoints until 4-5 hours before the first flight anyway.\n\n## 7. Monitor Your Flight Like a Hawk\n\nGate changes and delays spike during summer. Enable push notifications from your airline's app and check your flight status every few hours starting the night before. Being first to know about changes means you can rebook on earlier flights or snag better seats while everyone else is still in the dark.\n\n## Your Sanity Is Worth Planning Ahead\n\nSummer 2026 doesn't have to mean airport stress. These seven strategies take minimal effort but deliver maximum calm. Book smart, prepare early, and you'll be sipping cocktails at your destination while others are still queuing at security. Safe travels!	4	Beat Airport Crowds: 7 Smart Tips for Summer 2026 Travel	Skip the summer airport chaos with these 7 proven strategies. Learn the best times to fly, security shortcuts, and insider tips for stress-free travel in 2026.	airport crowds summer 2026, beat airport lines, TSA PreCheck tips, best time to fly summer, avoid airport crowds, airport travel hacks, summer travel tips 2026	\N	none	\N	ai	2026-04-20 10:43:17.522	2026-04-20 10:43:17.522	2026-04-20 10:43:17.579	\N	\N	\N	\N	\N
29	pdqekos06oqnffn39vrltrza	10 Luxury Eco-Hotels Worth the Splurge This Year	luxury-eco-hotels-worth-the-splurge	Sustainability meets indulgence at these stunning eco-hotels where you can enjoy five-star amenities while minimizing your carbon footprint. Discover properties redefining luxury travel.	# 10 Luxury Eco-Hotels Worth the Splurge This Year\n\nGone are the days when eco-friendly travel meant sacrificing comfort. Today's luxury eco-hotels prove you can pamper yourself while protecting the planet. Here are ten exceptional properties where sustainability and sophistication go hand in hand.\n\n## Europe's Green Gems\n\n### Whitepod, Switzerland\nNestled in the Swiss Alps, these geodesic domes run on renewable energy and feature pellet stoves for heating. Despite the minimalist footprint, expect plush beds, gourmet dining, and breathtaking mountain views.\n\n### Soneva Fushi, Maldives\nThis barefoot luxury resort pioneered the "no news, no shoes" philosophy. With solar power, waste-to-wealth programs, and an on-site glass-blowing studio creating art from recycled bottles, it's sustainability perfection.\n\n### Fogo Island Inn, Canada\nThis architectural marvel in Newfoundland sources 90% of its food locally, employs community members, and reinvests profits into the island's preservation. Floor-to-ceiling windows frame the dramatic North Atlantic coastline.\n\n## Tropical Escapes With Purpose\n\n### Lapa Rios Lodge, Costa Rica\nOwning a private rainforest reserve, this lodge protects 1,000 acres of biodiversity. Seventeen bungalows blend into the canopy, offering wildlife viewing and ocean panoramas without compromising the ecosystem.\n\n### Pikaia Lodge, Galápagos\nBuilt with endemic materials and powered by renewable energy, this LEED-certified property offers yacht excursions to explore Darwin's living laboratory while maintaining strict conservation protocols.\n\n### Misool, Indonesia\nThis private island resort created a 300,000-acre marine reserve, transforming former shark-finning grounds into a thriving reef ecosystem. Over-water villas provide direct access to world-class diving.\n\n## Desert and Mountain Sanctuaries\n\n### Longitude 131°, Australia\nFacing Uluru, these luxury tents operate on solar power and practice strict waste management while offering champagne at sunset and indigenous cultural experiences.\n\n### Explora Patagonia, Chile\nCarbon-neutral operations, hydroelectric power, and organic gardens supply this contemporary lodge. Daily excursions into Torres del Paine National Park include expert naturalist guides.\n\n### Campi ya Kanzi, Kenya\nThis Maasai-owned wilderness camp protects 400 square miles of wildlife habitat. Profits fund education, healthcare, and conservation initiatives for six local communities.\n\n### Lefay Resort, Italy\nOverlooking Lake Garda, this wellness retreat achieved LEED Gold certification through geothermal heating, rainwater harvesting, and organic spa treatments using local herbs.\n\n## Why These Hotels Matter\n\nThese properties demonstrate that luxury travel can drive positive change. They create local employment, protect endangered ecosystems, and prove sustainable practices enhance rather than diminish guest experiences.\n\n**Ready to book your guilt-free escape?** Each hotel offers unique seasonal packages. Research their sustainability certifications, compare carbon offset programs, and remember: your tourism dollars vote for the kind of world you want to see. Which eco-luxury destination will you choose?\n\n*Travel tip: Many of these properties offer multi-night packages with better rates and deeper immersion into their conservation programs.*	3	10 Best Luxury Eco-Hotels for Sustainable Travel in 2024	Discover 10 exceptional luxury eco-hotels combining five-star comfort with sustainability. From Swiss Alps to Maldives, splurge responsibly this year.	luxury eco hotels, sustainable travel, green hotels, eco resorts, sustainable luxury travel, eco-friendly hotels, carbon neutral resorts, responsible tourism, luxury sustainable hotels	\N	none	\N	ai	2026-04-20 09:50:39.058	2026-04-20 11:40:21.321	2026-04-20 11:40:21.092	\N	1	\N	generating	\N
25	g2scmbc2sm8dvrsk69i2l9wj	7 Smart Ways to Skip Airport Security Lines in 2026	skip-airport-security-lines-2026	Tired of endless airport queues? Discover seven proven strategies to breeze through security checkpoints in 2026, from trusted traveler programs to cutting-edge biometric tech.	# 7 Smart Ways to Skip Airport Security Lines in 2026\n\nWe've all been there—standing in a winding security line, watching precious minutes tick away before your flight. The good news? 2026 brings more options than ever to bypass those crowds and reclaim your time. Here are seven strategies that actually work.\n\n## 1. Enroll in TSA PreCheck or Global Entry\n\nThis remains the gold standard for U.S. travelers. **TSA PreCheck** ($78 for five years) gets you through dedicated lanes in under 10 minutes at 200+ airports. Keep your shoes, belt, and laptop packed. **Global Entry** ($100 for five years) includes PreCheck benefits plus expedited customs when returning internationally.\n\nApplication takes 2-4 weeks, so don't wait until your next trip.\n\n## 2. Try CLEAR for Biometric Speed\n\n**CLEAR** uses fingerprint and iris scanning to verify your identity in seconds. You'll skip the ID check line entirely and head straight to physical screening. At $189 annually (often discounted through credit cards), it's pricier but pairs perfectly with PreCheck for maximum efficiency.\n\nAvailable at 50+ U.S. airports and growing rapidly in 2026.\n\n## 3. Book Early Morning Flights\n\nSecurity lines are typically shortest between 5:00-6:30 AM and after 8:00 PM. Business travelers create midday rushes (7:00-9:00 AM, 4:00-7:00 PM). Adjust your schedule by even an hour to avoid peak chaos.\n\n## 4. Use Mobile Boarding Passes and Digital IDs\n\nPaper boarding passes slow you down. Several states now offer **digital driver's licenses** accepted at TSA checkpoints. Combined with mobile boarding passes, you'll breeze through with just your phone—no fumbling for documents.\n\nCurrently accepted in Arizona, Colorado, Maryland, and expanding throughout 2026.\n\n## 5. Pack Like a Pro\n\nSecurity delays often stem from unprepared travelers. Follow the **3-1-1 rule** religiously: liquids in 3.4oz containers, one quart-sized bag, one bag per passenger. Organize electronics in easy-access pockets. Wear slip-on shoes and minimal jewelry.\n\nThe 30 seconds you invest packing smart saves 10 minutes at screening.\n\n## 6. Check Alternative Security Checkpoints\n\nLarge airports have multiple screening areas. The checkpoint closest to ticketing is usually most crowded. Research your airport's layout beforehand—terminals B or C might have 5-minute waits while Terminal A has 30-minute lines.\n\nApps like **MyTSA** show real-time wait estimates.\n\n## 7. Leverage Airline and Credit Card Perks\n\nPremium credit cards increasingly offer complimentary CLEAR or PreCheck enrollment. First-class and business-class tickets on many airlines include priority security access. Check your benefits—you might already have fast-track privileges you're not using.\n\n## Make Your Move Now\n\nAirport security doesn't have to be the worst part of travel. Whether you invest in trusted traveler programs, optimize your timing, or simply pack smarter, these strategies compound to save hours over a year of travel.\n\n**Start with TSA PreCheck enrollment this week.** Your future self, calmly sipping coffee at the gate while others wait in line, will thank you. What's your favorite time-saving airport hack? Share it with fellow travelers in the comments below.\n\nSafe travels!	3	7 Ways to Skip Airport Security Lines in 2026 | Fast Track Tips	Breeze through airport security in 2026 with these 7 proven strategies. From TSA PreCheck to biometric tech, discover how to save hours on every trip.	airport security tips, skip security lines, TSA PreCheck, CLEAR, Global Entry, fast track airport, airport hacks 2026, travel tips	\N	none	\N	ai	2026-04-20 10:37:37.903	2026-04-20 11:41:27.9	\N	\N	1	\N	generating	\N
30	g2scmbc2sm8dvrsk69i2l9wj	7 Smart Ways to Skip Airport Security Lines in 2026	skip-airport-security-lines-2026	Tired of endless airport queues? Discover seven proven strategies to breeze through security checkpoints in 2026, from trusted traveler programs to cutting-edge biometric tech.	# 7 Smart Ways to Skip Airport Security Lines in 2026\n\nWe've all been there—standing in a winding security line, watching precious minutes tick away before your flight. The good news? 2026 brings more options than ever to bypass those crowds and reclaim your time. Here are seven strategies that actually work.\n\n## 1. Enroll in TSA PreCheck or Global Entry\n\nThis remains the gold standard for U.S. travelers. **TSA PreCheck** ($78 for five years) gets you through dedicated lanes in under 10 minutes at 200+ airports. Keep your shoes, belt, and laptop packed. **Global Entry** ($100 for five years) includes PreCheck benefits plus expedited customs when returning internationally.\n\nApplication takes 2-4 weeks, so don't wait until your next trip.\n\n## 2. Try CLEAR for Biometric Speed\n\n**CLEAR** uses fingerprint and iris scanning to verify your identity in seconds. You'll skip the ID check line entirely and head straight to physical screening. At $189 annually (often discounted through credit cards), it's pricier but pairs perfectly with PreCheck for maximum efficiency.\n\nAvailable at 50+ U.S. airports and growing rapidly in 2026.\n\n## 3. Book Early Morning Flights\n\nSecurity lines are typically shortest between 5:00-6:30 AM and after 8:00 PM. Business travelers create midday rushes (7:00-9:00 AM, 4:00-7:00 PM). Adjust your schedule by even an hour to avoid peak chaos.\n\n## 4. Use Mobile Boarding Passes and Digital IDs\n\nPaper boarding passes slow you down. Several states now offer **digital driver's licenses** accepted at TSA checkpoints. Combined with mobile boarding passes, you'll breeze through with just your phone—no fumbling for documents.\n\nCurrently accepted in Arizona, Colorado, Maryland, and expanding throughout 2026.\n\n## 5. Pack Like a Pro\n\nSecurity delays often stem from unprepared travelers. Follow the **3-1-1 rule** religiously: liquids in 3.4oz containers, one quart-sized bag, one bag per passenger. Organize electronics in easy-access pockets. Wear slip-on shoes and minimal jewelry.\n\nThe 30 seconds you invest packing smart saves 10 minutes at screening.\n\n## 6. Check Alternative Security Checkpoints\n\nLarge airports have multiple screening areas. The checkpoint closest to ticketing is usually most crowded. Research your airport's layout beforehand—terminals B or C might have 5-minute waits while Terminal A has 30-minute lines.\n\nApps like **MyTSA** show real-time wait estimates.\n\n## 7. Leverage Airline and Credit Card Perks\n\nPremium credit cards increasingly offer complimentary CLEAR or PreCheck enrollment. First-class and business-class tickets on many airlines include priority security access. Check your benefits—you might already have fast-track privileges you're not using.\n\n## Make Your Move Now\n\nAirport security doesn't have to be the worst part of travel. Whether you invest in trusted traveler programs, optimize your timing, or simply pack smarter, these strategies compound to save hours over a year of travel.\n\n**Start with TSA PreCheck enrollment this week.** Your future self, calmly sipping coffee at the gate while others wait in line, will thank you. What's your favorite time-saving airport hack? Share it with fellow travelers in the comments below.\n\nSafe travels!	3	7 Ways to Skip Airport Security Lines in 2026 | Fast Track Tips	Breeze through airport security in 2026 with these 7 proven strategies. From TSA PreCheck to biometric tech, discover how to save hours on every trip.	airport security tips, skip security lines, TSA PreCheck, CLEAR, Global Entry, fast track airport, airport hacks 2026, travel tips	\N	none	\N	ai	2026-04-20 10:37:37.903	2026-04-20 11:41:28.03	2026-04-20 11:41:27.945	\N	1	\N	generating	\N
32	i56fsh5dk25vbx13p9ocpvoi	Best Pet-Friendly Hotels in Europe: Your 2026 Travel Guide	best-pet-friendly-hotels-europe-2026-travel-guide	Discover Europe's top pet-friendly hotels where your furry companion gets the VIP treatment. From luxury retreats to budget-friendly stays, we've found the perfect spots for 2026.	## Why Leave Your Best Friend Behind?\n\nTravelling across Europe with your pet has never been easier—or more luxurious. Gone are the days when finding quality pet-friendly accommodation meant settling for basic options. In 2026, Europe's hospitality scene has fully embraced four-legged guests, offering everything from dedicated pet concierge services to gourmet pet menus.\n\n## Top Pet-Friendly Hotels Across Europe\n\n### Luxury Options That Pamper Your Pet\n\n**The Egerton House Hotel, London**\nThis boutique gem in Knightsbridge treats pets like royalty. Your dog receives a personalised welcome pack with treats, toys, and a comfortable bed. The hotel's proximity to Hyde Park means excellent walking routes are just minutes away.\n\n**Hotel Sacher, Vienna**\nFamous for its chocolate cake, Hotel Sacher extends its five-star service to pets with custom bedding, food bowls, and even a pet-sitting service. The concierge team can arrange veterinary visits if needed.\n\n**Château de la Resle, Burgundy**\nThis French countryside château welcomes pets into its elegantly restored rooms. Dogs can roam the extensive gardens, and the staff happily provides recommendations for pet-friendly vineyards in the region.\n\n### Budget-Friendly Favourites\n\n**Motel One, Multiple Locations**\nWith properties across Germany, Austria, and beyond, Motel One offers consistent quality without pet fees. Their central locations make city exploration with your companion straightforward.\n\n**Citizenm Hotels, Various Cities**\nModern, affordable, and genuinely welcoming to pets, Citizenm properties feature compact rooms perfect for travellers who prioritise location over space.\n\n## Essential Tips for Hotel Stays with Pets\n\n### Before You Book\n\n- **Confirm pet policies directly**: Weight limits, breed restrictions, and additional fees vary significantly\n- **Request ground-floor rooms**: Easier access for bathroom breaks and emergencies\n- **Ask about nearby amenities**: Parks, veterinary clinics, and pet supply shops\n\n### During Your Stay\n\n- Bring familiar items from home (blankets, favourite toys) to help your pet settle\n- Maintain your pet's regular feeding and walking schedule\n- Use "do not disturb" signs when leaving your pet alone briefly\n- Always clean up after your pet, both indoors and outdoors\n\n### Etiquette Matters\n\n- Keep pets leashed in common areas\n- Notify housekeeping if your pet sheds significantly\n- Report any accidents immediately\n- Tip staff who go above and beyond for your pet\n\n## Planning Your 2026 European Pet Adventure\n\nThe key to stress-free travel with pets lies in preparation. Book accommodations well in advance, especially during peak summer months when pet-friendly rooms fill quickly. Consider travel insurance that covers pet-related incidents, and ensure your pet's vaccinations and microchip details meet EU requirements.\n\n**Ready to explore Europe with your furry friend?** Start researching pet policies at your dream destinations today. The memories you'll create travelling together far outweigh the extra planning required. Whether you're strolling Parisian boulevards or hiking Alpine trails, these pet-friendly hotels ensure both you and your companion enjoy every moment of your European adventure.	4	Best Pet-Friendly Hotels in Europe 2026 | Complete Travel Guide	Planning a European trip with your pet? Discover the best pet-friendly hotels in Europe for 2026, from luxury stays to budget options. Expert tips included.	pet-friendly hotels Europe, travel with pets Europe 2026, dog-friendly hotels, cat-friendly accommodation, pet travel guide Europe, best hotels for pets	\N	none	\N	ai	2026-04-20 09:50:14.779	2026-04-20 11:48:35.195	2026-04-20 11:48:34.99	\N	1	\N	generating	\N
16	q4tnohdjnppgxsc5umeqji7p	10 Boutique Hotels Opening in 2026 You Can Book Right Now	boutique-hotels-opening-2026-book-now	Get ahead of the curve with these stunning boutique properties launching in 2026. From urban sanctuaries to coastal hideaways, here's where design-savvy travelers should book next.	## Be First Through the Door: 2026's Most Anticipated Boutique Openings\n\nSmart travelers know the secret: booking brand-new boutique hotels before they're everywhere on Instagram means better rates, eager-to-please staff, and that special energy only a grand opening can deliver. We've scoured opening schedules worldwide to bring you ten exceptional properties accepting reservations right now for 2026.\n\n## Urban Escapes Worth Clearing Your Calendar For\n\n**The Marlowe, Nashville** (Opens March 2026)\nThis 42-room gem in the Gulch district brings Brooklyn-meets-Nashville vibes with a rooftop bar showcasing live music seven nights weekly. Rooms start at $285, with early-bird bookings earning 15% off.\n\n**Hotel Kinfolk, Portland** (Opens May 2026)\nThink Japanese minimalism meets Pacific Northwest warmth. The 38 rooms feature soaking tubs, locally-made textiles, and a lobby tea bar sourcing from Oregon farms. Already 40% booked for opening month.\n\n**Casa Moderna, Mexico City** (Opens February 2026)\nA restored 1960s apartment complex transformed into 24 individually designed suites. The ground-floor cantina is helmed by a chef with two Michelin stars. Book the penthouse while you still can.\n\n## Coastal Retreats That Redefine Beachside Luxury\n\n**The Sandpiper, Comporta, Portugal** (Opens June 2026)\nPortugal's hottest coastal destination gets its first design-forward property: 31 rooms with private terraces, a farm-to-table restaurant, and direct beach access. Opening rates from €220.\n\n**Saltwater House, Byron Bay** (Opens April 2026)\nAustralia's answer to Big Sur modernism. Fifteen bungalows with floor-to-ceiling glass, outdoor showers, and a zero-waste restaurant. Adults-only policy ensures tranquility.\n\n**Dune & Sea, Outer Banks** (Opens July 2026)\nThis North Carolina newcomer offers 28 rooms with private boardwalk access, a seafood smokehouse, and surprisingly affordable rates starting at $195.\n\n## Mountain and Countryside Sanctuaries\n\n**Alpine House, Dolomites** (Opens January 2026)\nA reimagined 19th-century lodge with 22 rooms, a Tyrolean spa, and ski-in/ski-out access. Winter bookings are moving fast—summer availability is better.\n\n**The Farmstead, Cotswolds** (Opens May 2026)\nEngland's countryside gets a 16-room working farm hotel with foraging experiences, cooking classes, and rooms overlooking lavender fields. Dog-friendly, naturally.\n\n**Horizon Lodge, Banff** (Opens September 2026)\nCanada's Rockies welcome this 35-room property featuring Indigenous art, a whiskey library, and helicopter tours. Book now before peak fall foliage season fills up.\n\n**Desert Moon, Scottsdale** (Opens October 2026)\nArizona modernism at its finest: 40 casita-style rooms, three pools, and a wellness program centered on desert hiking and sound healing.\n\n## Why Book Boutique Hotels Before They Open\n\nEarly reservations often come with perks: room upgrades, dining credits, or complimentary experiences. Plus, you'll avoid the post-launch price increases that typically hit 20-30% higher.\n\n**Ready to be among the first guests?** Visit each property's website directly for the best early-booking rates, and consider travel insurance—opening dates occasionally shift. Your 2026 travel calendar just got a whole lot more exciting.	3	10 Boutique Hotels Opening in 2026 You Can Book Right Now	Discover 10 stunning boutique hotels opening in 2026 with reservations available now. From Nashville to Portugal, get early-bird rates before they sell out.	boutique hotels 2026, new hotel openings, luxury boutique hotels, book hotels early, design hotels, boutique hotel reservations, new hotels to book	\N	none	\N	ai	2026-04-20 10:07:48.997	2026-04-20 11:49:07.305	\N	\N	1	\N	generating	\N
33	q4tnohdjnppgxsc5umeqji7p	10 Boutique Hotels Opening in 2026 You Can Book Right Now	boutique-hotels-opening-2026-book-now	Get ahead of the curve with these stunning boutique properties launching in 2026. From urban sanctuaries to coastal hideaways, here's where design-savvy travelers should book next.	## Be First Through the Door: 2026's Most Anticipated Boutique Openings\n\nSmart travelers know the secret: booking brand-new boutique hotels before they're everywhere on Instagram means better rates, eager-to-please staff, and that special energy only a grand opening can deliver. We've scoured opening schedules worldwide to bring you ten exceptional properties accepting reservations right now for 2026.\n\n## Urban Escapes Worth Clearing Your Calendar For\n\n**The Marlowe, Nashville** (Opens March 2026)\nThis 42-room gem in the Gulch district brings Brooklyn-meets-Nashville vibes with a rooftop bar showcasing live music seven nights weekly. Rooms start at $285, with early-bird bookings earning 15% off.\n\n**Hotel Kinfolk, Portland** (Opens May 2026)\nThink Japanese minimalism meets Pacific Northwest warmth. The 38 rooms feature soaking tubs, locally-made textiles, and a lobby tea bar sourcing from Oregon farms. Already 40% booked for opening month.\n\n**Casa Moderna, Mexico City** (Opens February 2026)\nA restored 1960s apartment complex transformed into 24 individually designed suites. The ground-floor cantina is helmed by a chef with two Michelin stars. Book the penthouse while you still can.\n\n## Coastal Retreats That Redefine Beachside Luxury\n\n**The Sandpiper, Comporta, Portugal** (Opens June 2026)\nPortugal's hottest coastal destination gets its first design-forward property: 31 rooms with private terraces, a farm-to-table restaurant, and direct beach access. Opening rates from €220.\n\n**Saltwater House, Byron Bay** (Opens April 2026)\nAustralia's answer to Big Sur modernism. Fifteen bungalows with floor-to-ceiling glass, outdoor showers, and a zero-waste restaurant. Adults-only policy ensures tranquility.\n\n**Dune & Sea, Outer Banks** (Opens July 2026)\nThis North Carolina newcomer offers 28 rooms with private boardwalk access, a seafood smokehouse, and surprisingly affordable rates starting at $195.\n\n## Mountain and Countryside Sanctuaries\n\n**Alpine House, Dolomites** (Opens January 2026)\nA reimagined 19th-century lodge with 22 rooms, a Tyrolean spa, and ski-in/ski-out access. Winter bookings are moving fast—summer availability is better.\n\n**The Farmstead, Cotswolds** (Opens May 2026)\nEngland's countryside gets a 16-room working farm hotel with foraging experiences, cooking classes, and rooms overlooking lavender fields. Dog-friendly, naturally.\n\n**Horizon Lodge, Banff** (Opens September 2026)\nCanada's Rockies welcome this 35-room property featuring Indigenous art, a whiskey library, and helicopter tours. Book now before peak fall foliage season fills up.\n\n**Desert Moon, Scottsdale** (Opens October 2026)\nArizona modernism at its finest: 40 casita-style rooms, three pools, and a wellness program centered on desert hiking and sound healing.\n\n## Why Book Boutique Hotels Before They Open\n\nEarly reservations often come with perks: room upgrades, dining credits, or complimentary experiences. Plus, you'll avoid the post-launch price increases that typically hit 20-30% higher.\n\n**Ready to be among the first guests?** Visit each property's website directly for the best early-booking rates, and consider travel insurance—opening dates occasionally shift. Your 2026 travel calendar just got a whole lot more exciting.	3	10 Boutique Hotels Opening in 2026 You Can Book Right Now	Discover 10 stunning boutique hotels opening in 2026 with reservations available now. From Nashville to Portugal, get early-bird rates before they sell out.	boutique hotels 2026, new hotel openings, luxury boutique hotels, book hotels early, design hotels, boutique hotel reservations, new hotels to book	\N	none	\N	ai	2026-04-20 10:07:48.997	2026-04-20 11:49:07.413	2026-04-20 11:49:07.346	\N	1	\N	generating	\N
\.


--
-- Data for Name: articles_author_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.articles_author_lnk (id, article_id, author_id, article_ord) FROM stdin;
\.


--
-- Data for Name: articles_blog_destinations_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.articles_blog_destinations_lnk (id, article_id, blog_destination_id, blog_destination_ord, article_ord) FROM stdin;
\.


--
-- Data for Name: articles_category_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.articles_category_lnk (id, article_id, category_id, article_ord) FROM stdin;
1	3	3	1
2	5	3	2
15	10	1	1
16	18	1	2
17	12	1	3
18	19	1	4
19	20	1	5
20	21	1	5
5	8	4	2
11	14	4	4
12	15	4	5
13	16	4	6
21	6	4	8
23	23	12	1
24	24	12	1
25	25	5	1
27	27	5	2
28	28	5	2
29	29	4	3
30	30	5	1
32	32	4	1
33	33	4	7
\.


--
-- Data for Name: articles_destinations_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.articles_destinations_lnk (id, article_id, destination_id, destination_ord, article_ord) FROM stdin;
\.


--
-- Data for Name: articles_tags_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.articles_tags_lnk (id, article_id, tag_id, tag_ord, article_ord) FROM stdin;
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.authors (id, document_id, name, slug, email, bio, twitter, website, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: blog_destinations; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.blog_destinations (id, document_id, name, slug, base_url, webhook_url, webhook_secret, auth_header, active, auto_post_on_publish, schedule, topic_filter, last_post_at, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.categories (id, document_id, name, slug, description, icon, color, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, "order", site) FROM stdin;
1	ge3z75jhtga0v1rb1u60wc7l	Destinations	destinations	\N	\N	\N	2026-04-20 07:53:13.902	2026-04-20 07:54:17.234	2026-04-20 07:54:17.179	1	1	\N	\N	\N
5	u029bqrqt0ovn1ft731qjzty	Travel Tips	travel-tips	\N	\N	\N	2026-04-20 08:40:37.89	2026-04-20 08:40:37.89	2026-04-20 08:40:37.882	1	1	\N	\N	\N
6	jufwaw56eek0p038sa87tzat	South East Asia	south-east-asia	\N	\N	\N	2026-04-20 08:59:59.197	2026-04-20 08:59:59.197	2026-04-20 08:59:59.169	1	1	\N	0	all
7	rgtbem5frcuc5zmd19cpp4rp	Thailand	thailand	\N	\N	\N	2026-04-20 09:00:44.861	2026-04-20 09:00:44.861	2026-04-20 09:00:44.845	1	1	\N	0	all
8	i20goail37c605vaymrmm336	Oceanic	oceanic	\N	\N	\N	2026-04-20 09:01:23.86	2026-04-20 09:01:23.86	2026-04-20 09:01:23.849	1	1	\N	0	all
9	deckvnk7j1i64po3vx6bfj38	Australia	australia	\N	\N	\N	2026-04-20 09:01:39.408	2026-04-20 09:01:39.408	2026-04-20 09:01:39.39	1	1	\N	0	all
10	y7pzlfx4wl6ersh2ds5rsjc8	Melbourne	melbourne	\N	\N	\N	2026-04-20 09:02:02.291	2026-04-20 09:02:02.291	2026-04-20 09:02:02.273	1	1	\N	0	all
11	t3hky7c4fpooy2xhbkq8b7jq	Sydney	sydney	\N	\N	\N	2026-04-20 09:02:10.887	2026-04-20 09:02:10.887	2026-04-20 09:02:10.869	1	1	\N	0	all
12	doxprkr3jdtqz0ib80t1jfaq	Travel Resources	travel-resources	\N	\N	\N	2026-04-20 09:03:05.605	2026-04-20 09:03:05.605	2026-04-20 09:03:05.585	1	1	\N	0	all
13	dl9v4qkg6utv4ftrsgq1ijad	Car Rentals	car-rentals	\N	\N	\N	2026-04-20 09:07:15.817	2026-04-20 09:07:15.817	2026-04-20 09:07:15.801	1	1	\N	0	all
3	pn9xzcb5lu0alfqndvno0y5j	Flights	flights	\N	\N	\N	2026-04-20 08:40:00.73	2026-04-20 10:36:25.836	2026-04-20 10:36:25.754	1	1	\N	\N	\N
4	ligdgn73xvos1j3bfpk1zed7	Hotels	hotels	\N	\N	\N	2026-04-20 08:40:15.3	2026-04-20 10:36:37.599	2026-04-20 10:36:37.553	1	1	\N	\N	\N
\.


--
-- Data for Name: categories_parent_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.categories_parent_lnk (id, category_id, inv_category_id, category_ord) FROM stdin;
1	6	1	1
2	7	6	1
3	8	1	2
4	9	8	1
5	10	9	1
6	11	9	2
\.


--
-- Data for Name: destinations; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.destinations (id, document_id, name, slug, type, country_code, description, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.files (id, document_id, name, alternative_text, caption, focal_point, width, height, formats, hash, ext, mime, size, url, preview_url, provider, provider_metadata, folder_path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	m8cw5s45u0se9i7kgw0myck4	7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-2.jpg	\N	\N	\N	1024	768	{"large": {"ext": ".jpg", "url": "/uploads/large_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed.jpg", "hash": "large_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed", "mime": "image/jpeg", "name": "large_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-2.jpg", "path": null, "size": 90.87, "width": 1000, "height": 750, "sizeInBytes": 90870}, "small": {"ext": ".jpg", "url": "/uploads/small_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed.jpg", "hash": "small_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed", "mime": "image/jpeg", "name": "small_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-2.jpg", "path": null, "size": 30.01, "width": 500, "height": 375, "sizeInBytes": 30006}, "medium": {"ext": ".jpg", "url": "/uploads/medium_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed.jpg", "hash": "medium_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed", "mime": "image/jpeg", "name": "medium_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-2.jpg", "path": null, "size": 57.45, "width": 750, "height": 563, "sizeInBytes": 57453}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed.jpg", "hash": "thumbnail_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed", "mime": "image/jpeg", "name": "thumbnail_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-2.jpg", "path": null, "size": 7.25, "width": 208, "height": 156, "sizeInBytes": 7246}}	7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed	.jpg	image/jpeg	94.27	/uploads/7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_2_828ec5e1ed.jpg	\N	local	\N	/1	2026-04-20 10:43:17.364	2026-04-20 10:43:17.364	2026-04-20 10:43:17.364	\N	\N	\N
2	cftytgjneqwsbwumv2qj4825	7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-1.jpg	\N	\N	\N	1024	768	{"large": {"ext": ".jpg", "url": "/uploads/large_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7.jpg", "hash": "large_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7", "mime": "image/jpeg", "name": "large_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-1.jpg", "path": null, "size": 69.48, "width": 1000, "height": 750, "sizeInBytes": 69483}, "small": {"ext": ".jpg", "url": "/uploads/small_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7.jpg", "hash": "small_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7", "mime": "image/jpeg", "name": "small_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-1.jpg", "path": null, "size": 26.46, "width": 500, "height": 375, "sizeInBytes": 26457}, "medium": {"ext": ".jpg", "url": "/uploads/medium_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7.jpg", "hash": "medium_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7", "mime": "image/jpeg", "name": "medium_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-1.jpg", "path": null, "size": 46.55, "width": 750, "height": 563, "sizeInBytes": 46549}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7.jpg", "hash": "thumbnail_7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7", "mime": "image/jpeg", "name": "thumbnail_7-smart-ways-to-beat-airport-crowds-in-summer-2026-gallery-1.jpg", "path": null, "size": 7.71, "width": 208, "height": 156, "sizeInBytes": 7706}}	7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7	.jpg	image/jpeg	70.56	/uploads/7_smart_ways_to_beat_airport_crowds_in_summer_2026_gallery_1_fb417419b7.jpg	\N	local	\N	/1	2026-04-20 10:43:17.399	2026-04-20 10:43:17.399	2026-04-20 10:43:17.399	\N	\N	\N
3	n8mmikwjtietp3508oz88m8x	7-smart-ways-to-beat-airport-crowds-in-summer-2026-cover.jpg	\N	\N	\N	1024	576	{"large": {"ext": ".jpg", "url": "/uploads/large_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5.jpg", "hash": "large_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5", "mime": "image/jpeg", "name": "large_7-smart-ways-to-beat-airport-crowds-in-summer-2026-cover.jpg", "path": null, "size": 114.4, "width": 1000, "height": 563, "sizeInBytes": 114397}, "small": {"ext": ".jpg", "url": "/uploads/small_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5.jpg", "hash": "small_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5", "mime": "image/jpeg", "name": "small_7-smart-ways-to-beat-airport-crowds-in-summer-2026-cover.jpg", "path": null, "size": 33.15, "width": 500, "height": 281, "sizeInBytes": 33147}, "medium": {"ext": ".jpg", "url": "/uploads/medium_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5.jpg", "hash": "medium_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5", "mime": "image/jpeg", "name": "medium_7-smart-ways-to-beat-airport-crowds-in-summer-2026-cover.jpg", "path": null, "size": 68.01, "width": 750, "height": 422, "sizeInBytes": 68014}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5.jpg", "hash": "thumbnail_7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5", "mime": "image/jpeg", "name": "thumbnail_7-smart-ways-to-beat-airport-crowds-in-summer-2026-cover.jpg", "path": null, "size": 9.73, "width": 245, "height": 138, "sizeInBytes": 9732}}	7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5	.jpg	image/jpeg	120.92	/uploads/7_smart_ways_to_beat_airport_crowds_in_summer_2026_cover_6bb11484a5.jpg	\N	local	\N	/1	2026-04-20 10:43:17.452	2026-04-20 10:43:17.452	2026-04-20 10:43:17.453	\N	\N	\N
\.


--
-- Data for Name: files_folder_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.files_folder_lnk (id, file_id, folder_id, file_ord) FROM stdin;
1	1	1	1
2	2	1	2
3	3	1	3
\.


--
-- Data for Name: files_related_mph; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.files_related_mph (id, file_id, related_id, related_type, field, "order") FROM stdin;
1	3	27	api::article.article	coverImage	1
2	2	27	api::article.article	gallery	1
3	1	27	api::article.article	gallery	2
4	3	28	api::article.article	coverImage	1
5	2	28	api::article.article	gallery	1
6	1	28	api::article.article	gallery	2
\.


--
-- Data for Name: i18n_locale; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.i18n_locale (id, document_id, name, code, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	qfrl68oexc6wdscp581m6mqq	English (en)	en	2026-04-20 01:52:39.905	2026-04-20 01:52:39.905	2026-04-20 01:52:39.907	\N	\N	\N
\.


--
-- Data for Name: strapi_ai_localization_jobs; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_ai_localization_jobs (id, content_type, related_document_id, source_locale, target_locales, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: strapi_ai_metadata_jobs; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_ai_metadata_jobs (id, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_api_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_api_token_permissions_token_lnk (id, api_token_permission_id, api_token_id, api_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_api_tokens; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_api_tokens (id, document_id, name, description, type, access_key, encrypted_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	odgffppb2z3o40udw2w8djl5	Read Only	A default API token with read-only permissions, only used for accessing resources	read-only	daaf643429da464ed90b2db566cebb54717d67b3825afb5292ea4f47783f5b1668e02ae8ecf6d2739b16f1ceeef1ce724f0526b7ec9d9a8ef66296d1a849047c	v1:c9ee14f6fd6ae6e484dbe1e1b67fa973:3bdcf06b68a47cdedb5ca5c67abb978deadfbaaafbe540028ddf0099b168f9e356adc6e138c5c74f91277f4722e40f589509fd6ad8edaf4df80bb145fbc1025322013c50098bd22c56127839aa4b7533aaf764f22340356d2614070a43d71a96e5bc5508d70ed42c5e85e2dbbcc39fb6ae92280175acebc4d9f01303ddf9d6b7f5e79561e79bb90b72ec719017d7acce3167d6b2809b1a6d78f6ceb1812f55e5e8329f7436a41895d17581372af247c6a62014357b581f5ecda5016127433d2e2a6dc47586c2af1fab636ac6d036259f3f7a40c4fba6fa65713366ab3166f58c9ef6132af10988a615c5de6317c1e78e0dee1beba51f13705039fdc7b05a1a27:ae6c0e31a01218527a205c9f833e4e87	\N	\N	\N	2026-04-20 01:52:41.496	2026-04-20 01:52:41.496	2026-04-20 01:52:41.496	\N	\N	\N
2	c367gtm0yamwizyd3laq5qt5	Full Access	A default API token with full access permissions, used for accessing or modifying resources	full-access	3263e6bb4d9272c26baa3ee7a589173b90f0f50f5e4156eed5695f199043db625503ec5fe9d2d7e461fc48a395fa4d349b2354d8f12063524c099cbb5aa619b0	v1:09aa3ab188bcc35716ab37c9cd273e90:295ad498c35119787d1c4a1f10c49d379854f11ca4b9cca021f2e12638ee7c25af85ffb363e4015c8a1367bb0e4207bc30e0db7945a5973d3f8434bf18c852e5884b51320e8b41a7cc721dad7306350178eb8b9a3635d8d3a0734157747dcc950edd35aa98c0b680be33a7454eb81e2db0fcdd90428e8bd8e218ffbb3122804d6ac9d16484a0b177a1d9796d9a523c3719e1d60f9c144693abb25fe677b629e49e543ccd16af75ebde7d868cbb5175a11cc3ce0a71a222052bb9d642e2601b235a188115a4dabad9a99d90d1f17eea388a45b5b1e1d5c25f0e4aa061aab3766e5a0181bd2e921da7902f3a759892581fe3703eab8b748a7391483414cd976e4d:ca35918493e104ac4a2bfcbc3698632b	\N	\N	\N	2026-04-20 01:52:41.507	2026-04-20 01:52:41.507	2026-04-20 01:52:41.507	\N	\N	\N
3	hxfa5evsusa2wflq39ylfkt5	autopost-worker		full-access	6fd5b649af72753b1965f6827bc9cbb1c67e6e32046a42660e0ced96479b94088dbb15f15a5fc2bae52194af893773b1e6f2df7a1204977bfaea362341296c74	v1:e8de191ac20a2cac27589443186a1f42:8485e353fe26f1b85c1c5a584f689f6a4535856da8acd378301558ee7243c8a0504aeb0db96e5fcf58a52c86813612ae704dabae692061f290139d16e0279ed49108ddeb7a4355a216fd7adc93e649266d9d12099dc129526673c3ce3378448935edc6ad570cb1f8c473f35d5f3a0d6460e4af1710df7b04235caae2b778b25fdad5262078ea795f606a9b5dc6f0bdd7a463992e85adc443595ecef34b24d139bee0406b3e7035dde07d04ba34dd40648745000ce711c8c87e16a6c87c213834270c8be03e0f0c64eca4b7e72a31a7a882104182c4d63efd3ad2811a3e8518a9b60ebf6f5178daca0c2580c75b6d1e56f6c4248a2bad9f1cc3afa85b7fce8c8b:d0c3857fd9c078401cd3b77e25859b9a	2026-04-22 13:18:08.875	\N	\N	2026-04-20 04:45:23.398	2026-04-22 13:18:08.875	2026-04-20 04:45:23.398	\N	\N	\N
4	ie8u5f02nwgio7t2rnxhkhzj	ai-writer-cli		full-access	9b22670fe4a743827e5af81d2257e2c942294732958dedb752a7664c7d713c2ebaa97d44aeb55fb73aa790dd756c7b2801d3148ce1a1d3ef28089eaed950636f	v1:4eebf94be5de544b41c04720469c6f61:1cfcfe1a35cb9543f7f3d9c535eca8b85ed672a8e45a40b6071b1d9c8e9b7ce0c483420a04ab7ba3d3b63ae62c2c2e87922c9037eba99e9e730f9c5fab53a1d50d7f55f74a73971a3d93b82427acf9dc9eb675d2441f905a32f2814574138248bb85e97ec5b10fa754b30306ce5bbb2ae13beb05129d8f7d845cf2587c5754711f1af76a11903f735379d674769b9f63ac452cd19f93cd1d23dd3989e801efced5f2dea6b7fb5b06fd37ed18ea84895a5fc5bc3c19773fccfc8c1c32f6027b3204488e35998df5b16baee68d4b5726836a5b19b8dfc91cb82f79f5eef37088ef7fdf6395d5b6d300ca3005411d77a16c47f43175efb59066853de0b37bfa1f8f:8f104c8e6b658e7377314e1df64c037c	2026-04-22 13:01:42.09	\N	\N	2026-04-20 05:07:37.583	2026-04-22 13:01:42.09	2026-04-20 05:07:37.584	\N	\N	\N
\.


--
-- Data for Name: strapi_core_store_settings; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_core_store_settings (id, key, value, type, environment, tag) FROM stdin;
1	strapi_unidirectional-join-table-repair-ran	true	boolean	\N	\N
3	plugin_content_manager_configuration_content_types::plugin::i18n.locale	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]},"uid":"plugin::i18n.locale"}	object	\N	\N
4	plugin_content_manager_configuration_content_types::plugin::upload.file	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"focalPoint":{"edit":{"label":"focalPoint","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"focalPoint","searchable":false,"sortable":false}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6}],[{"name":"focalPoint","size":12}],[{"name":"width","size":4},{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]},"uid":"plugin::upload.file"}	object	\N	\N
5	plugin_content_manager_configuration_content_types::plugin::content-releases.release	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"releasedAt":{"edit":{"label":"releasedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"releasedAt","searchable":true,"sortable":true}},"scheduledAt":{"edit":{"label":"scheduledAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledAt","searchable":true,"sortable":true}},"timezone":{"edit":{"label":"timezone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"timezone","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"actions":{"edit":{"label":"actions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"contentType"},"list":{"label":"actions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","releasedAt","scheduledAt"],"edit":[[{"name":"name","size":6},{"name":"releasedAt","size":6}],[{"name":"scheduledAt","size":6},{"name":"timezone","size":6}],[{"name":"status","size":6},{"name":"actions","size":6}]]},"uid":"plugin::content-releases.release"}	object	\N	\N
6	plugin_content_manager_configuration_content_types::plugin::content-releases.release-action	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"contentType","defaultSortBy":"contentType","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"contentType":{"edit":{"label":"contentType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentType","searchable":true,"sortable":true}},"entryDocumentId":{"edit":{"label":"entryDocumentId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"entryDocumentId","searchable":true,"sortable":true}},"release":{"edit":{"label":"release","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"release","searchable":true,"sortable":true}},"isEntryValid":{"edit":{"label":"isEntryValid","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isEntryValid","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","type","contentType","entryDocumentId"],"edit":[[{"name":"type","size":6},{"name":"contentType","size":6}],[{"name":"entryDocumentId","size":6},{"name":"release","size":6}],[{"name":"isEntryValid","size":4}]]},"uid":"plugin::content-releases.release-action"}	object	\N	\N
7	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"stages":{"edit":{"label":"stages","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stages","searchable":false,"sortable":false}},"stageRequiredToPublish":{"edit":{"label":"stageRequiredToPublish","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stageRequiredToPublish","searchable":true,"sortable":true}},"contentTypes":{"edit":{"label":"contentTypes","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentTypes","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","stages","stageRequiredToPublish"],"edit":[[{"name":"name","size":6},{"name":"stages","size":6}],[{"name":"stageRequiredToPublish","size":6}],[{"name":"contentTypes","size":12}]]},"uid":"plugin::review-workflows.workflow"}	object	\N	\N
8	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow-stage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"color":{"edit":{"label":"color","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"color","searchable":true,"sortable":true}},"workflow":{"edit":{"label":"workflow","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"workflow","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","color","workflow"],"edit":[[{"name":"name","size":6},{"name":"color","size":6}],[{"name":"workflow","size":6},{"name":"permissions","size":6}]]},"uid":"plugin::review-workflows.workflow-stage"}	object	\N	\N
9	plugin_content_manager_configuration_content_types::plugin::upload.folder	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]},"uid":"plugin::upload.folder"}	object	\N	\N
10	plugin_content_manager_configuration_content_types::plugin::users-permissions.permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.permission"}	object	\N	\N
11	plugin_content_manager_configuration_content_types::plugin::users-permissions.role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]},"uid":"plugin::users-permissions.role"}	object	\N	\N
15	plugin_content_manager_configuration_content_types::api::author.author	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"bio":{"edit":{"label":"bio","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"bio","searchable":true,"sortable":true}},"avatar":{"edit":{"label":"avatar","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"avatar","searchable":false,"sortable":false}},"twitter":{"edit":{"label":"twitter","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"twitter","searchable":true,"sortable":true}},"website":{"edit":{"label":"website","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"website","searchable":true,"sortable":true}},"articles":{"edit":{"label":"articles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"articles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","slug","email"],"edit":[[{"name":"name","size":6},{"name":"slug","size":6}],[{"name":"email","size":6},{"name":"bio","size":6}],[{"name":"avatar","size":6},{"name":"twitter","size":6}],[{"name":"website","size":6},{"name":"articles","size":6}]]},"uid":"api::author.author"}	object	\N	\N
17	plugin_content_manager_configuration_content_types::api::destination.destination	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"countryCode":{"edit":{"label":"countryCode","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"countryCode","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"heroImage":{"edit":{"label":"heroImage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroImage","searchable":false,"sortable":false}},"articles":{"edit":{"label":"articles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"articles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","slug","type"],"edit":[[{"name":"name","size":6},{"name":"slug","size":6}],[{"name":"type","size":6},{"name":"countryCode","size":6}],[{"name":"description","size":6},{"name":"heroImage","size":6}],[{"name":"articles","size":6}]]},"uid":"api::destination.destination"}	object	\N	\N
19	plugin_content_manager_configuration_content_types::api::tag.tag	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"articles":{"edit":{"label":"articles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"articles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","slug","articles"],"edit":[[{"name":"name","size":6},{"name":"slug","size":6}],[{"name":"articles","size":6}]]},"uid":"api::tag.tag"}	object	\N	\N
21	plugin_content_manager_configuration_content_types::admin::role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]},"uid":"admin::role"}	object	\N	\N
23	plugin_content_manager_configuration_content_types::admin::transfer-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","accessKey"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"accessKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::transfer-token"}	object	\N	\N
13	plugin_content_manager_configuration_content_types::api::article.article	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"excerpt":{"edit":{"label":"excerpt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"excerpt","searchable":true,"sortable":true}},"content":{"edit":{"label":"content","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"content","searchable":false,"sortable":false}},"coverImage":{"edit":{"label":"coverImage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"coverImage","searchable":false,"sortable":false}},"gallery":{"edit":{"label":"gallery","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"gallery","searchable":false,"sortable":false}},"readingTimeMinutes":{"edit":{"label":"readingTimeMinutes","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"readingTimeMinutes","searchable":true,"sortable":true}},"seoTitle":{"edit":{"label":"seoTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"seoTitle","searchable":true,"sortable":true}},"seoDescription":{"edit":{"label":"seoDescription","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"seoDescription","searchable":true,"sortable":true}},"seoKeywords":{"edit":{"label":"seoKeywords","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"seoKeywords","searchable":true,"sortable":true}},"ogImage":{"edit":{"label":"ogImage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ogImage","searchable":false,"sortable":false}},"scheduledFor":{"edit":{"label":"scheduledFor","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledFor","searchable":true,"sortable":true}},"autopostStatus":{"edit":{"label":"autopostStatus","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"autopostStatus","searchable":true,"sortable":true}},"autopostLog":{"edit":{"label":"autopostLog","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"autopostLog","searchable":false,"sortable":false}},"source":{"edit":{"label":"source","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"source","searchable":true,"sortable":true}},"aiImageStatus":{"edit":{"label":"aiImageStatus","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"aiImageStatus","searchable":true,"sortable":true}},"aiImageStatusMessage":{"edit":{"label":"aiImageStatusMessage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"aiImageStatusMessage","searchable":true,"sortable":true}},"category":{"edit":{"label":"category","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"category","searchable":true,"sortable":true}},"tags":{"edit":{"label":"tags","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"tags","searchable":false,"sortable":false}},"author":{"edit":{"label":"author","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"author","searchable":true,"sortable":true}},"destinations":{"edit":{"label":"destinations","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"destinations","searchable":false,"sortable":false}},"blogDestinations":{"edit":{"label":"blogDestinations","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"blogDestinations","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","slug","excerpt"],"edit":[[{"name":"title","size":6},{"name":"slug","size":6}],[{"name":"excerpt","size":6}],[{"name":"content","size":12}],[{"name":"coverImage","size":6},{"name":"gallery","size":6}],[{"name":"readingTimeMinutes","size":4},{"name":"seoTitle","size":6}],[{"name":"seoDescription","size":6},{"name":"seoKeywords","size":6}],[{"name":"ogImage","size":6},{"name":"scheduledFor","size":6}],[{"name":"autopostStatus","size":6}],[{"name":"autopostLog","size":12}],[{"name":"source","size":6},{"name":"category","size":6}],[{"name":"tags","size":6},{"name":"author","size":6}],[{"name":"destinations","size":6},{"name":"blogDestinations","size":6}],[{"name":"aiImageStatus","size":6},{"name":"aiImageStatusMessage","size":6}]]},"uid":"api::article.article"}	object	\N	\N
12	plugin_content_manager_configuration_content_types::plugin::users-permissions.user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.user"}	object	\N	\N
14	plugin_content_manager_configuration_content_types::api::blog-destination.blog-destination	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"baseUrl":{"edit":{"label":"baseUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"baseUrl","searchable":true,"sortable":true}},"webhookUrl":{"edit":{"label":"webhookUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"webhookUrl","searchable":true,"sortable":true}},"webhookSecret":{"edit":{"label":"webhookSecret","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"webhookSecret","searchable":true,"sortable":true}},"authHeader":{"edit":{"label":"authHeader","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"authHeader","searchable":true,"sortable":true}},"active":{"edit":{"label":"active","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"active","searchable":true,"sortable":true}},"autoPostOnPublish":{"edit":{"label":"autoPostOnPublish","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"autoPostOnPublish","searchable":true,"sortable":true}},"schedule":{"edit":{"label":"schedule","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"schedule","searchable":true,"sortable":true}},"topicFilter":{"edit":{"label":"topicFilter","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"topicFilter","searchable":false,"sortable":false}},"lastPostAt":{"edit":{"label":"lastPostAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastPostAt","searchable":true,"sortable":true}},"articles":{"edit":{"label":"articles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"articles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","slug","baseUrl"],"edit":[[{"name":"name","size":6},{"name":"slug","size":6}],[{"name":"baseUrl","size":6},{"name":"webhookUrl","size":6}],[{"name":"webhookSecret","size":6},{"name":"authHeader","size":6}],[{"name":"active","size":4},{"name":"autoPostOnPublish","size":4}],[{"name":"schedule","size":6}],[{"name":"topicFilter","size":12}],[{"name":"lastPostAt","size":6},{"name":"articles","size":6}]]},"uid":"api::blog-destination.blog-destination"}	object	\N	\N
18	plugin_content_manager_configuration_content_types::admin::permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"actionParameters":{"edit":{"label":"actionParameters","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"actionParameters","searchable":false,"sortable":false}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6}],[{"name":"actionParameters","size":12}],[{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]},"uid":"admin::permission"}	object	\N	\N
20	plugin_content_manager_configuration_content_types::admin::user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]},"uid":"admin::user"}	object	\N	\N
22	plugin_content_manager_configuration_content_types::admin::api-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"encryptedKey":{"edit":{"label":"encryptedKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"encryptedKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"encryptedKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::api-token"}	object	\N	\N
24	plugin_content_manager_configuration_content_types::admin::api-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::api-token-permission"}	object	\N	\N
26	plugin_content_manager_configuration_content_types::admin::session	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"userId","defaultSortBy":"userId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"userId":{"edit":{"label":"userId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userId","searchable":true,"sortable":true}},"sessionId":{"edit":{"label":"sessionId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"sessionId","searchable":true,"sortable":true}},"childId":{"edit":{"label":"childId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"childId","searchable":true,"sortable":true}},"deviceId":{"edit":{"label":"deviceId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"deviceId","searchable":true,"sortable":true}},"origin":{"edit":{"label":"origin","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"origin","searchable":true,"sortable":true}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"absoluteExpiresAt":{"edit":{"label":"absoluteExpiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"absoluteExpiresAt","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","userId","sessionId","childId"],"edit":[[{"name":"userId","size":6},{"name":"sessionId","size":6}],[{"name":"childId","size":6},{"name":"deviceId","size":6}],[{"name":"origin","size":6},{"name":"expiresAt","size":6}],[{"name":"absoluteExpiresAt","size":6},{"name":"status","size":6}],[{"name":"type","size":6}]]},"uid":"admin::session"}	object	\N	\N
16	plugin_content_manager_configuration_content_types::api::category.category	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"color":{"edit":{"label":"color","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"color","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"site":{"edit":{"label":"site","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"site","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"articles":{"edit":{"label":"articles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"articles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","slug","description"],"edit":[[{"name":"name","size":6},{"name":"slug","size":6}],[{"name":"description","size":6},{"name":"icon","size":6}],[{"name":"color","size":6},{"name":"articles","size":6}],[{"name":"order","size":4},{"name":"site","size":6}],[{"name":"parent","size":6},{"name":"children","size":6}]]},"uid":"api::category.category"}	object	\N	\N
25	plugin_content_manager_configuration_content_types::admin::transfer-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"relationOpenMode":"modal","mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::transfer-token-permission"}	object	\N	\N
27	plugin_upload_settings	{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false,"aiMetadata":true}	object	\N	\N
28	plugin_upload_view_configuration	{"pageSize":10,"sort":"createdAt:DESC"}	object	\N	\N
30	plugin_i18n_default_locale	"en"	string	\N	\N
31	plugin_users-permissions_grant	{"email":{"icon":"envelope","enabled":true},"discord":{"icon":"discord","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/discord/callback","scope":["identify","email"]},"facebook":{"icon":"facebook-square","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/facebook/callback","scope":["email"]},"google":{"icon":"google","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/google/callback","scope":["email"]},"github":{"icon":"github","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/github/callback","scope":["user","user:email"]},"microsoft":{"icon":"windows","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/microsoft/callback","scope":["user.read"]},"twitter":{"icon":"twitter","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/twitter/callback"},"instagram":{"icon":"instagram","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/instagram/callback","scope":["user_profile"]},"vk":{"icon":"vk","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/vk/callback","scope":["email"]},"twitch":{"icon":"twitch","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"icon":"linkedin","enabled":false,"key":"","secret":"","callbackUrl":"https://cms.fxnstudio.com/api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"icon":"aws","enabled":false,"key":"","secret":"","subdomain":"my.subdomain.com","callback":"https://cms.fxnstudio.com/api/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"icon":"reddit","enabled":false,"key":"","secret":"","callback":"https://cms.fxnstudio.com/api/auth/reddit/callback","scope":["identity"]},"auth0":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"my-tenant.eu","callback":"https://cms.fxnstudio.com/api/auth/auth0/callback","scope":["openid","email","profile"]},"cas":{"icon":"book","enabled":false,"key":"","secret":"","callback":"https://cms.fxnstudio.com/api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas"},"patreon":{"icon":"","enabled":false,"key":"","secret":"","callback":"https://cms.fxnstudio.com/api/auth/patreon/callback","scope":["identity","identity[email]"]},"keycloak":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"myKeycloakProvider.com/realms/myrealm","callback":"https://cms.fxnstudio.com/api/auth/keycloak/callback","scope":["openid","email","profile"]}}	object	\N	\N
32	plugin_users-permissions_email	{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\\n\\n<p>But don’t worry! You can use the following link to reset your password:</p>\\n<p><%= URL %>?code=<%= TOKEN %></p>\\n\\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\\n\\n<p>You have to confirm your email address. Please click on the link below.</p>\\n\\n<p><%= URL %>?confirmation=<%= CODE %></p>\\n\\n<p>Thanks.</p>"}}}	object	\N	\N
33	plugin_users-permissions_advanced	{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}	object	\N	\N
29	plugin_upload_metrics	{"weeklySchedule":"54 52 1 * * 1","lastWeeklyUpdate":1776649974027}	object	\N	\N
2	strapi_content_types_schema	{"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"text","configurable":false},"caption":{"type":"text","configurable":false},"focalPoint":{"type":"json","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"text","configurable":false,"required":true},"previewUrl":{"type":"text","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"files"}}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"plugin":"upload","globalId":"UploadFile","uid":"plugin::upload.file","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"text","configurable":false},"caption":{"type":"text","configurable":false},"focalPoint":{"type":"json","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"text","configurable":false,"required":true},"previewUrl":{"type":"text","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"file"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"upload_folders"}}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"plugin":"upload","globalId":"UploadFolder","uid":"plugin::upload.folder","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true}},"kind":"collectionType"},"modelName":"folder"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::i18n.locale","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"i18n_locale"}}},"plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale","uid":"plugin::i18n.locale","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"i18n_locale","info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelName":"locale"},"plugin::content-releases.release":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_releases"}}},"plugin":"content-releases","globalId":"ContentReleasesRelease","uid":"plugin::content-releases.release","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"}},"kind":"collectionType"},"modelName":"release"},"plugin::content-releases.release-action":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_release_actions"}}},"plugin":"content-releases","globalId":"ContentReleasesReleaseAction","uid":"plugin::content-releases.release-action","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"}},"kind":"collectionType"},"modelName":"release-action"},"plugin::review-workflows.workflow":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflow","uid":"plugin::review-workflows.workflow","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"}},"kind":"collectionType"},"modelName":"workflow"},"plugin::review-workflows.workflow-stage":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0","draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow-stage","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows_stages"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflowStage","uid":"plugin::review-workflows.workflow-stage","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false}},"kind":"collectionType"},"modelName":"workflow-stage"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_permissions"}}},"plugin":"users-permissions","globalId":"UsersPermissionsPermission","uid":"plugin::users-permissions.permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelName":"permission","options":{"draftAndPublish":false}},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_roles"}}},"plugin":"users-permissions","globalId":"UsersPermissionsRole","uid":"plugin::users-permissions.role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelName":"role","options":{"draftAndPublish":false}},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"timestamps":true,"draftAndPublish":false},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"plugin":"users-permissions","globalId":"UsersPermissionsUser","uid":"plugin::users-permissions.user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false}},"kind":"collectionType"},"modelName":"user"},"api::article.article":{"kind":"collectionType","collectionName":"articles","info":{"singularName":"article","pluralName":"articles","displayName":"Article","description":"Travel articles, guides, and blog posts"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true,"maxLength":255},"slug":{"type":"uid","targetField":"title","required":true},"excerpt":{"type":"text","maxLength":500},"content":{"type":"richtext","required":true},"coverImage":{"type":"media","multiple":false,"required":false,"allowedTypes":["images"]},"gallery":{"type":"media","multiple":true,"required":false,"allowedTypes":["images"]},"readingTimeMinutes":{"type":"integer","default":5,"min":1},"seoTitle":{"type":"string","maxLength":70},"seoDescription":{"type":"text","maxLength":160},"seoKeywords":{"type":"string"},"ogImage":{"type":"media","multiple":false,"allowedTypes":["images"]},"scheduledFor":{"type":"datetime"},"autopostStatus":{"type":"enumeration","enum":["none","pending","posted","failed"],"default":"none"},"autopostLog":{"type":"json"},"source":{"type":"enumeration","enum":["manual","ai","markdown-import","csv-import"],"default":"manual"},"aiImageStatus":{"type":"enumeration","enum":["idle","requested","generating","done","failed"],"default":"idle"},"aiImageStatusMessage":{"type":"text"},"category":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"articles"},"tags":{"type":"relation","relation":"manyToMany","target":"api::tag.tag","inversedBy":"articles"},"author":{"type":"relation","relation":"manyToOne","target":"api::author.author","inversedBy":"articles"},"destinations":{"type":"relation","relation":"manyToMany","target":"api::destination.destination","inversedBy":"articles"},"blogDestinations":{"type":"relation","relation":"manyToMany","target":"api::blog-destination.blog-destination","inversedBy":"articles"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::article.article","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"articles"}}},"apiName":"article","globalId":"Article","uid":"api::article.article","modelType":"contentType","__schema__":{"collectionName":"articles","info":{"singularName":"article","pluralName":"articles","displayName":"Article","description":"Travel articles, guides, and blog posts"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true,"maxLength":255},"slug":{"type":"uid","targetField":"title","required":true},"excerpt":{"type":"text","maxLength":500},"content":{"type":"richtext","required":true},"coverImage":{"type":"media","multiple":false,"required":false,"allowedTypes":["images"]},"gallery":{"type":"media","multiple":true,"required":false,"allowedTypes":["images"]},"readingTimeMinutes":{"type":"integer","default":5,"min":1},"seoTitle":{"type":"string","maxLength":70},"seoDescription":{"type":"text","maxLength":160},"seoKeywords":{"type":"string"},"ogImage":{"type":"media","multiple":false,"allowedTypes":["images"]},"scheduledFor":{"type":"datetime"},"autopostStatus":{"type":"enumeration","enum":["none","pending","posted","failed"],"default":"none"},"autopostLog":{"type":"json"},"source":{"type":"enumeration","enum":["manual","ai","markdown-import","csv-import"],"default":"manual"},"aiImageStatus":{"type":"enumeration","enum":["idle","requested","generating","done","failed"],"default":"idle"},"aiImageStatusMessage":{"type":"text"},"category":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"articles"},"tags":{"type":"relation","relation":"manyToMany","target":"api::tag.tag","inversedBy":"articles"},"author":{"type":"relation","relation":"manyToOne","target":"api::author.author","inversedBy":"articles"},"destinations":{"type":"relation","relation":"manyToMany","target":"api::destination.destination","inversedBy":"articles"},"blogDestinations":{"type":"relation","relation":"manyToMany","target":"api::blog-destination.blog-destination","inversedBy":"articles"}},"kind":"collectionType"},"modelName":"article","actions":{},"lifecycles":{}},"api::author.author":{"kind":"collectionType","collectionName":"authors","info":{"singularName":"author","pluralName":"authors","displayName":"Author"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":120},"slug":{"type":"uid","targetField":"name","required":true},"email":{"type":"email"},"bio":{"type":"text"},"avatar":{"type":"media","multiple":false,"allowedTypes":["images"]},"twitter":{"type":"string"},"website":{"type":"string"},"articles":{"type":"relation","relation":"oneToMany","target":"api::article.article","mappedBy":"author"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::author.author","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"authors"}}},"apiName":"author","globalId":"Author","uid":"api::author.author","modelType":"contentType","__schema__":{"collectionName":"authors","info":{"singularName":"author","pluralName":"authors","displayName":"Author"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":120},"slug":{"type":"uid","targetField":"name","required":true},"email":{"type":"email"},"bio":{"type":"text"},"avatar":{"type":"media","multiple":false,"allowedTypes":["images"]},"twitter":{"type":"string"},"website":{"type":"string"},"articles":{"type":"relation","relation":"oneToMany","target":"api::article.article","mappedBy":"author"}},"kind":"collectionType"},"modelName":"author","actions":{},"lifecycles":{}},"api::blog-destination.blog-destination":{"kind":"collectionType","collectionName":"blog_destinations","info":{"singularName":"blog-destination","pluralName":"blog-destinations","displayName":"Blog Destination","description":"External blog/site where articles are syndicated (webhook + schedule)"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":120},"slug":{"type":"uid","targetField":"name","required":true},"baseUrl":{"type":"string","required":true},"webhookUrl":{"type":"string","required":true},"webhookSecret":{"type":"password"},"authHeader":{"type":"string"},"active":{"type":"boolean","default":true},"autoPostOnPublish":{"type":"boolean","default":true},"schedule":{"type":"enumeration","enum":["immediate","hourly","daily-0900","daily-1800","manual"],"default":"immediate"},"topicFilter":{"type":"json"},"lastPostAt":{"type":"datetime"},"articles":{"type":"relation","relation":"manyToMany","target":"api::article.article","mappedBy":"blogDestinations"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::blog-destination.blog-destination","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"blog_destinations"}}},"apiName":"blog-destination","globalId":"BlogDestination","uid":"api::blog-destination.blog-destination","modelType":"contentType","__schema__":{"collectionName":"blog_destinations","info":{"singularName":"blog-destination","pluralName":"blog-destinations","displayName":"Blog Destination","description":"External blog/site where articles are syndicated (webhook + schedule)"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":120},"slug":{"type":"uid","targetField":"name","required":true},"baseUrl":{"type":"string","required":true},"webhookUrl":{"type":"string","required":true},"webhookSecret":{"type":"password"},"authHeader":{"type":"string"},"active":{"type":"boolean","default":true},"autoPostOnPublish":{"type":"boolean","default":true},"schedule":{"type":"enumeration","enum":["immediate","hourly","daily-0900","daily-1800","manual"],"default":"immediate"},"topicFilter":{"type":"json"},"lastPostAt":{"type":"datetime"},"articles":{"type":"relation","relation":"manyToMany","target":"api::article.article","mappedBy":"blogDestinations"}},"kind":"collectionType"},"modelName":"blog-destination","actions":{},"lifecycles":{}},"api::category.category":{"kind":"collectionType","collectionName":"categories","info":{"singularName":"category","pluralName":"categories","displayName":"Category","description":"Top-level content categories (e.g. Flights, Hotels, Destinations, Travel Tips) with unlimited sub-category depth"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":80},"slug":{"type":"uid","targetField":"name","required":true},"description":{"type":"text"},"icon":{"type":"string","maxLength":40},"color":{"type":"string","maxLength":20},"order":{"type":"integer","default":0},"site":{"type":"enumeration","enum":["all","travel","future-1","future-2","future-3"],"default":"all","description":"Restrict this category to a specific blog site (leave 'all' for shared)"},"parent":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"api::category.category","mappedBy":"parent"},"articles":{"type":"relation","relation":"oneToMany","target":"api::article.article","mappedBy":"category"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::category.category","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"categories"}}},"apiName":"category","globalId":"Category","uid":"api::category.category","modelType":"contentType","__schema__":{"collectionName":"categories","info":{"singularName":"category","pluralName":"categories","displayName":"Category","description":"Top-level content categories (e.g. Flights, Hotels, Destinations, Travel Tips) with unlimited sub-category depth"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":80},"slug":{"type":"uid","targetField":"name","required":true},"description":{"type":"text"},"icon":{"type":"string","maxLength":40},"color":{"type":"string","maxLength":20},"order":{"type":"integer","default":0},"site":{"type":"enumeration","enum":["all","travel","future-1","future-2","future-3"],"default":"all","description":"Restrict this category to a specific blog site (leave 'all' for shared)"},"parent":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"api::category.category","mappedBy":"parent"},"articles":{"type":"relation","relation":"oneToMany","target":"api::article.article","mappedBy":"category"}},"kind":"collectionType"},"modelName":"category","actions":{},"lifecycles":{}},"api::destination.destination":{"kind":"collectionType","collectionName":"destinations","info":{"singularName":"destination","pluralName":"destinations","displayName":"Destination","description":"Geographic destinations (country / city / region)"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":120},"slug":{"type":"uid","targetField":"name","required":true},"type":{"type":"enumeration","enum":["country","region","city"],"default":"city"},"countryCode":{"type":"string","maxLength":3},"description":{"type":"text"},"heroImage":{"type":"media","multiple":false,"allowedTypes":["images"]},"articles":{"type":"relation","relation":"manyToMany","target":"api::article.article","mappedBy":"destinations"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::destination.destination","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"destinations"}}},"apiName":"destination","globalId":"Destination","uid":"api::destination.destination","modelType":"contentType","__schema__":{"collectionName":"destinations","info":{"singularName":"destination","pluralName":"destinations","displayName":"Destination","description":"Geographic destinations (country / city / region)"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"maxLength":120},"slug":{"type":"uid","targetField":"name","required":true},"type":{"type":"enumeration","enum":["country","region","city"],"default":"city"},"countryCode":{"type":"string","maxLength":3},"description":{"type":"text"},"heroImage":{"type":"media","multiple":false,"allowedTypes":["images"]},"articles":{"type":"relation","relation":"manyToMany","target":"api::article.article","mappedBy":"destinations"}},"kind":"collectionType"},"modelName":"destination","actions":{},"lifecycles":{}},"api::tag.tag":{"kind":"collectionType","collectionName":"tags","info":{"singularName":"tag","pluralName":"tags","displayName":"Tag"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"unique":true,"maxLength":60},"slug":{"type":"uid","targetField":"name","required":true},"articles":{"type":"relation","relation":"manyToMany","target":"api::article.article","mappedBy":"tags"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::tag.tag","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"tags"}}},"apiName":"tag","globalId":"Tag","uid":"api::tag.tag","modelType":"contentType","__schema__":{"collectionName":"tags","info":{"singularName":"tag","pluralName":"tags","displayName":"Tag"},"options":{"draftAndPublish":false},"attributes":{"name":{"type":"string","required":true,"unique":true,"maxLength":60},"slug":{"type":"uid","targetField":"name","required":true},"articles":{"type":"relation","relation":"manyToMany","target":"api::article.article","mappedBy":"tags"}},"kind":"collectionType"},"modelName":"tag","actions":{},"lifecycles":{}},"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_permissions"}}},"plugin":"admin","globalId":"AdminPermission","uid":"admin::permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelName":"permission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"registrationToken":{"hidden":true}}},"plugin":"admin","globalId":"AdminUser","uid":"admin::user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false}},"kind":"collectionType"},"modelName":"user","options":{"draftAndPublish":false}},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_roles"}}},"plugin":"admin","globalId":"AdminRole","uid":"admin::role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelName":"role"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_tokens"}}},"plugin":"admin","globalId":"AdminApiToken","uid":"admin::api-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"api-token"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_token_permissions"}}},"plugin":"admin","globalId":"AdminApiTokenPermission","uid":"admin::api-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelName":"api-token-permission"},"admin::transfer-token":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_tokens"}}},"plugin":"admin","globalId":"AdminTransferToken","uid":"admin::transfer-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"transfer-token"},"admin::transfer-token-permission":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_token_permissions"}}},"plugin":"admin","globalId":"AdminTransferTokenPermission","uid":"admin::transfer-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"}},"kind":"collectionType"},"modelName":"transfer-token-permission"},"admin::session":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::session","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_sessions"}}},"plugin":"admin","globalId":"AdminSession","uid":"admin::session","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"session"}}	object	\N	\N
34	core_admin_auth	{"providers":{"autoRegister":false,"defaultRole":null,"ssoLockedRoles":null}}	object	\N	\N
35	plugin_upload_api-folder	{"id":1}	object	\N	\N
\.


--
-- Data for Name: strapi_database_schema; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_database_schema (id, schema, "time", hash) FROM stdin;
3	{"tables":[{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_documents_idx","columns":["document_id","locale","published_at"]},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"focal_point","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_documents_idx","columns":["document_id","locale","published_at"]},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_documents_idx","columns":["document_id","locale","published_at"]},{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_releases","indexes":[{"name":"strapi_releases_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"released_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"timezone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_release_actions","indexes":[{"name":"strapi_release_actions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"entry_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_entry_valid","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows","indexes":[{"name":"strapi_workflows_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_types","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_workflows_stages","indexes":[{"name":"strapi_workflows_stages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"color","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_roles","indexes":[{"name":"up_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_users","indexes":[{"name":"up_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"articles","indexes":[{"name":"articles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"articles_created_by_id_fk","columns":["created_by_id"]},{"name":"articles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"articles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"articles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"excerpt","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reading_time_minutes","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"seo_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"seo_description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"seo_keywords","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_for","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"autopost_status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"autopost_log","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"source","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ai_image_status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ai_image_status_message","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"authors","indexes":[{"name":"authors_documents_idx","columns":["document_id","locale","published_at"]},{"name":"authors_created_by_id_fk","columns":["created_by_id"]},{"name":"authors_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"authors_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"authors_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"bio","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"twitter","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"website","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"blog_destinations","indexes":[{"name":"blog_destinations_documents_idx","columns":["document_id","locale","published_at"]},{"name":"blog_destinations_created_by_id_fk","columns":["created_by_id"]},{"name":"blog_destinations_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"blog_destinations_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"blog_destinations_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"base_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"webhook_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"webhook_secret","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"auth_header","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"auto_post_on_publish","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"schedule","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"topic_filter","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_post_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"categories","indexes":[{"name":"categories_documents_idx","columns":["document_id","locale","published_at"]},{"name":"categories_created_by_id_fk","columns":["created_by_id"]},{"name":"categories_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"categories_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"categories_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"color","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"site","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"destinations","indexes":[{"name":"destinations_documents_idx","columns":["document_id","locale","published_at"]},{"name":"destinations_created_by_id_fk","columns":["created_by_id"]},{"name":"destinations_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"destinations_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"destinations_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"country_code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"tags","indexes":[{"name":"tags_documents_idx","columns":["document_id","locale","published_at"]},{"name":"tags_created_by_id_fk","columns":["created_by_id"]},{"name":"tags_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"tags_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"tags_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action_parameters","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_users","indexes":[{"name":"admin_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"encrypted_key","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_tokens","indexes":[{"name":"strapi_transfer_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_token_permissions","indexes":[{"name":"strapi_transfer_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_sessions","indexes":[{"name":"strapi_sessions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"user_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"session_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"child_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"device_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"origin","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"absolute_expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_history_versions","indexes":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"]}],"foreignKeys":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"data","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"schema","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_ai_metadata_jobs","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"completed_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_ai_localization_jobs","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"source_locale","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"target_locales","type":"jsonb","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"files_related_mph","indexes":[{"name":"files_related_mph_fk","columns":["file_id"]},{"name":"files_related_mph_oidx","columns":["order"]},{"name":"files_related_mph_idix","columns":["related_id"]}],"foreignKeys":[{"name":"files_related_mph_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_lnk","indexes":[{"name":"files_folder_lnk_fk","columns":["file_id"]},{"name":"files_folder_lnk_ifk","columns":["folder_id"]},{"name":"files_folder_lnk_uq","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_lnk_oifk","columns":["file_ord"]}],"foreignKeys":[{"name":"files_folder_lnk_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_lnk_ifk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_lnk","indexes":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"]},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_lnk_uq","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_lnk_oifk","columns":["folder_ord"]}],"foreignKeys":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions_release_lnk","indexes":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"]},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"]},{"name":"strapi_release_actions_release_lnk_uq","columns":["release_action_id","release_id"],"type":"unique"},{"name":"strapi_release_actions_release_lnk_oifk","columns":["release_action_ord"]}],"foreignKeys":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"],"referencedColumns":["id"],"referencedTable":"strapi_release_actions","onDelete":"CASCADE"},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"],"referencedColumns":["id"],"referencedTable":"strapi_releases","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"release_action_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_action_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stage_required_to_publish_lnk","indexes":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_uq","columns":["workflow_id","workflow_stage_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_workflow_lnk","indexes":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"]},{"name":"strapi_workflows_stages_workflow_lnk_uq","columns":["workflow_stage_id","workflow_id"],"type":"unique"},{"name":"strapi_workflows_stages_workflow_lnk_oifk","columns":["workflow_stage_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_permissions_lnk","indexes":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"]},{"name":"strapi_workflows_stages_permissions_lnk_uq","columns":["workflow_stage_id","permission_id"],"type":"unique"},{"name":"strapi_workflows_stages_permissions_lnk_ofk","columns":["permission_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_lnk","indexes":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"up_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_lnk","indexes":[{"name":"up_users_role_lnk_fk","columns":["user_id"]},{"name":"up_users_role_lnk_ifk","columns":["role_id"]},{"name":"up_users_role_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"up_users_role_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"articles_category_lnk","indexes":[{"name":"articles_category_lnk_fk","columns":["article_id"]},{"name":"articles_category_lnk_ifk","columns":["category_id"]},{"name":"articles_category_lnk_uq","columns":["article_id","category_id"],"type":"unique"},{"name":"articles_category_lnk_oifk","columns":["article_ord"]}],"foreignKeys":[{"name":"articles_category_lnk_fk","columns":["article_id"],"referencedColumns":["id"],"referencedTable":"articles","onDelete":"CASCADE"},{"name":"articles_category_lnk_ifk","columns":["category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"article_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"article_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"articles_tags_lnk","indexes":[{"name":"articles_tags_lnk_fk","columns":["article_id"]},{"name":"articles_tags_lnk_ifk","columns":["tag_id"]},{"name":"articles_tags_lnk_uq","columns":["article_id","tag_id"],"type":"unique"},{"name":"articles_tags_lnk_ofk","columns":["tag_ord"]},{"name":"articles_tags_lnk_oifk","columns":["article_ord"]}],"foreignKeys":[{"name":"articles_tags_lnk_fk","columns":["article_id"],"referencedColumns":["id"],"referencedTable":"articles","onDelete":"CASCADE"},{"name":"articles_tags_lnk_ifk","columns":["tag_id"],"referencedColumns":["id"],"referencedTable":"tags","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"article_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"tag_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"tag_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"article_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"articles_author_lnk","indexes":[{"name":"articles_author_lnk_fk","columns":["article_id"]},{"name":"articles_author_lnk_ifk","columns":["author_id"]},{"name":"articles_author_lnk_uq","columns":["article_id","author_id"],"type":"unique"},{"name":"articles_author_lnk_oifk","columns":["article_ord"]}],"foreignKeys":[{"name":"articles_author_lnk_fk","columns":["article_id"],"referencedColumns":["id"],"referencedTable":"articles","onDelete":"CASCADE"},{"name":"articles_author_lnk_ifk","columns":["author_id"],"referencedColumns":["id"],"referencedTable":"authors","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"article_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"author_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"article_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"articles_destinations_lnk","indexes":[{"name":"articles_destinations_lnk_fk","columns":["article_id"]},{"name":"articles_destinations_lnk_ifk","columns":["destination_id"]},{"name":"articles_destinations_lnk_uq","columns":["article_id","destination_id"],"type":"unique"},{"name":"articles_destinations_lnk_ofk","columns":["destination_ord"]},{"name":"articles_destinations_lnk_oifk","columns":["article_ord"]}],"foreignKeys":[{"name":"articles_destinations_lnk_fk","columns":["article_id"],"referencedColumns":["id"],"referencedTable":"articles","onDelete":"CASCADE"},{"name":"articles_destinations_lnk_ifk","columns":["destination_id"],"referencedColumns":["id"],"referencedTable":"destinations","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"article_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"destination_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"destination_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"article_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"articles_blog_destinations_lnk","indexes":[{"name":"articles_blog_destinations_lnk_fk","columns":["article_id"]},{"name":"articles_blog_destinations_lnk_ifk","columns":["blog_destination_id"]},{"name":"articles_blog_destinations_lnk_uq","columns":["article_id","blog_destination_id"],"type":"unique"},{"name":"articles_blog_destinations_lnk_ofk","columns":["blog_destination_ord"]},{"name":"articles_blog_destinations_lnk_oifk","columns":["article_ord"]}],"foreignKeys":[{"name":"articles_blog_destinations_lnk_fk","columns":["article_id"],"referencedColumns":["id"],"referencedTable":"articles","onDelete":"CASCADE"},{"name":"articles_blog_destinations_lnk_ifk","columns":["blog_destination_id"],"referencedColumns":["id"],"referencedTable":"blog_destinations","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"article_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"blog_destination_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"blog_destination_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"article_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"categories_parent_lnk","indexes":[{"name":"categories_parent_lnk_fk","columns":["category_id"]},{"name":"categories_parent_lnk_ifk","columns":["inv_category_id"]},{"name":"categories_parent_lnk_uq","columns":["category_id","inv_category_id"],"type":"unique"},{"name":"categories_parent_lnk_oifk","columns":["category_ord"]}],"foreignKeys":[{"name":"categories_parent_lnk_fk","columns":["category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"},{"name":"categories_parent_lnk_ifk","columns":["inv_category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"category_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_permissions_role_lnk","indexes":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"admin_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_lnk","indexes":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"]},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"]},{"name":"admin_users_roles_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_lnk_ofk","columns":["role_ord"]},{"name":"admin_users_roles_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_lnk","indexes":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_lnk_uq","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_lnk_oifk","columns":["api_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions_token_lnk","indexes":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_uq","columns":["transfer_token_permission_id","transfer_token_id"],"type":"unique"},{"name":"strapi_transfer_token_permissions_token_lnk_oifk","columns":["transfer_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_token_permissions","onDelete":"CASCADE"},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"transfer_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}	2026-04-20 11:39:27.23	ee6879e207865a3e87c44c8142cbb1c7ea9f89e9f17d7a664125f05e5074e956
\.


--
-- Data for Name: strapi_history_versions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_history_versions (id, content_type, related_document_id, locale, status, data, schema, created_at, created_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_migrations; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_migrations (id, name, "time") FROM stdin;
\.


--
-- Data for Name: strapi_migrations_internal; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_migrations_internal (id, name, "time") FROM stdin;
1	5.0.0-rename-identifiers-longer-than-max-length	2026-04-20 01:52:37.179
2	5.0.0-02-created-document-id	2026-04-20 01:52:37.282
3	5.0.0-03-created-locale	2026-04-20 01:52:37.368
4	5.0.0-04-created-published-at	2026-04-20 01:52:37.459
5	5.0.0-05-drop-slug-fields-index	2026-04-20 01:52:37.551
6	5.0.0-06-add-document-id-indexes	2026-04-20 01:52:37.633
7	core::5.0.0-discard-drafts	2026-04-20 01:52:37.728
\.


--
-- Data for Name: strapi_release_actions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_release_actions (id, document_id, type, content_type, entry_document_id, locale, is_entry_valid, created_at, updated_at, published_at, created_by_id, updated_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_release_actions_release_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_release_actions_release_lnk (id, release_action_id, release_id, release_action_ord) FROM stdin;
\.


--
-- Data for Name: strapi_releases; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_releases (id, document_id, name, released_at, scheduled_at, timezone, status, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_sessions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_sessions (id, document_id, user_id, session_id, child_id, device_id, origin, expires_at, absolute_expires_at, status, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	tn483y5pp3rgsntpq9sx24yt	1	dee4bd1f834da39faa75b9c4805ee3e7	93c43283744ddf1bf4f02e39c262af7d	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 03:53:12.938	2026-05-20 01:53:12.938	rotated	session	2026-04-20 01:53:12.938	2026-04-20 02:23:29.194	2026-04-20 01:53:12.938	\N	\N	\N
2	oshntw72eeqc6ws4vr4rj0ar	1	93c43283744ddf1bf4f02e39c262af7d	4dc77b34695a6d504b40dfe26ae3d96f	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 04:23:29.173	2026-05-20 01:53:12.938	rotated	session	2026-04-20 02:23:29.173	2026-04-20 02:53:56.6	2026-04-20 02:23:29.175	\N	\N	\N
4	drztenk18igesa16ggzuecun	1	6e6950fc1ee5bf52fd6db86aa2d24f4c	\N	fa74adb1-50dd-42c1-bc76-e47cd063704e	admin	2026-04-20 05:00:32.257	2026-05-20 03:00:32.257	active	session	2026-04-20 03:00:32.257	2026-04-20 03:00:32.257	2026-04-20 03:00:32.259	\N	\N	\N
5	zgap9bem3m4nhuh1nr44y8md	1	e0a2d897d772f9ffec4549514b7a094f	\N	3eac5f41-5d55-4502-957b-aa7a8bc63574	admin	2026-05-04 03:11:18.249	2026-05-20 03:11:18.249	active	refresh	2026-04-20 03:11:18.249	2026-04-20 03:11:18.249	2026-04-20 03:11:18.25	\N	\N	\N
3	v9k6aodqpm9h8oj5jmv0kesj	1	4dc77b34695a6d504b40dfe26ae3d96f	af8daf98afb12f6d8363d64b5d2d63fd	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 04:53:56.568	2026-05-20 01:53:12.938	rotated	session	2026-04-20 02:53:56.569	2026-04-20 03:42:34.904	2026-04-20 02:53:56.574	\N	\N	\N
6	if6mawurae22qs14styfaawe	1	af8daf98afb12f6d8363d64b5d2d63fd	498bb71531b4d310dd44a1bdd45eee86	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 05:42:34.876	2026-05-20 01:53:12.938	rotated	session	2026-04-20 03:42:34.877	2026-04-20 04:44:50.388	2026-04-20 03:42:34.88	\N	\N	\N
8	lvwdau2gaaz0armtv94b129o	1	d738f33b955c95215a4dda2bd3efc465	\N	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 07:18:56.317	2026-05-20 01:53:12.938	active	session	2026-04-20 05:18:56.318	2026-04-20 05:18:56.318	2026-04-20 05:18:56.319	\N	\N	\N
7	og39f4mrrzylgi2grqti3585	1	498bb71531b4d310dd44a1bdd45eee86	d738f33b955c95215a4dda2bd3efc465	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 06:44:50.37	2026-05-20 01:53:12.938	rotated	session	2026-04-20 04:44:50.371	2026-04-20 05:18:56.33	2026-04-20 04:44:50.372	\N	\N	\N
9	iob5n58svprdz3o3wrsp3hjv	1	10a6cef0b747c22ba34a351f454da65d	eb85f30dd600b967e37e6bc605e9ef86	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 09:33:45.801	2026-05-20 07:33:45.801	rotated	session	2026-04-20 07:33:45.801	2026-04-20 08:24:37.463	2026-04-20 07:33:45.802	\N	\N	\N
10	ou52446lszqef836pis793j7	1	eb85f30dd600b967e37e6bc605e9ef86	a0701ac0f8063ce000802fe2ce1cf5c7	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 10:24:37.441	2026-05-20 07:33:45.801	rotated	session	2026-04-20 08:24:37.442	2026-04-20 08:56:49.945	2026-04-20 08:24:37.445	\N	\N	\N
11	dh451w2g1eu963o98sdkw6q0	1	a0701ac0f8063ce000802fe2ce1cf5c7	9fbf460e65ec033168ee09dc36bfcd9f	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 10:56:49.92	2026-05-20 07:33:45.801	rotated	session	2026-04-20 08:56:49.921	2026-04-20 09:33:34.066	2026-04-20 08:56:49.925	\N	\N	\N
12	iap6gqajuegl6zfaohm6hzgn	1	9fbf460e65ec033168ee09dc36bfcd9f	5571e5799d0b1e3e2b2792fb478ad50b	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 11:33:34.053	2026-05-20 07:33:45.801	rotated	session	2026-04-20 09:33:34.053	2026-04-20 10:07:24.363	2026-04-20 09:33:34.054	\N	\N	\N
13	mvw4gvgpm1ozbskbn7xwyalt	1	5571e5799d0b1e3e2b2792fb478ad50b	2b7276ffa08f9c11611e7345f03ef19a	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 12:07:24.352	2026-05-20 07:33:45.801	rotated	session	2026-04-20 10:07:24.352	2026-04-20 10:42:44.681	2026-04-20 10:07:24.353	\N	\N	\N
14	ke29zli15po9tjf6929jo30v	1	2b7276ffa08f9c11611e7345f03ef19a	baf311f6771419f734cb1f9b45d8bcf5	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 12:42:44.664	2026-05-20 07:33:45.801	rotated	session	2026-04-20 10:42:44.664	2026-04-20 11:18:17.956	2026-04-20 10:42:44.665	\N	\N	\N
16	v8wfi3z53igl3n76kwxyjnvq	1	d0718fe1424f05781cee950fe12117ed	\N	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 13:48:21.083	2026-05-20 07:33:45.801	active	session	2026-04-20 11:48:21.084	2026-04-20 11:48:21.084	2026-04-20 11:48:21.087	\N	\N	\N
15	g9p4p2rmmcs451mr913h66o5	1	baf311f6771419f734cb1f9b45d8bcf5	d0718fe1424f05781cee950fe12117ed	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 13:18:17.942	2026-05-20 07:33:45.801	rotated	session	2026-04-20 11:18:17.942	2026-04-20 11:48:21.109	2026-04-20 11:18:17.943	\N	\N	\N
17	wqiusaufdu9bz2aj51rb7a3p	1	5348dc460569de727f3afcb71d3aab47	\N	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-20 16:54:27.317	2026-05-20 14:54:27.317	active	session	2026-04-20 14:54:27.317	2026-04-20 14:54:27.317	2026-04-20 14:54:27.319	\N	\N	\N
18	rqd5c6qb7m3v3vb6kizf7e2j	1	42ee5a658c5da2019e9c7eb6757f2777	\N	c78696d9-3f18-4771-ac46-1c10d736a40c	admin	2026-04-21 14:49:56.135	2026-05-21 12:49:56.135	active	session	2026-04-21 12:49:56.135	2026-04-21 12:49:56.135	2026-04-21 12:49:56.137	\N	\N	\N
\.


--
-- Data for Name: strapi_transfer_token_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_transfer_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_transfer_token_permissions_token_lnk (id, transfer_token_permission_id, transfer_token_id, transfer_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_tokens; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_transfer_tokens (id, document_id, name, description, access_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_webhooks; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_webhooks (id, name, url, headers, events, enabled) FROM stdin;
\.


--
-- Data for Name: strapi_workflows; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows (id, document_id, name, content_types, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stage_required_to_publish_lnk (id, workflow_id, workflow_stage_id) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stages (id, document_id, name, color, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_permissions_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stages_permissions_lnk (id, workflow_stage_id, permission_id, permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_workflow_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stages_workflow_lnk (id, workflow_stage_id, workflow_id, workflow_stage_ord) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.tags (id, document_id, name, slug, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: up_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	jtuo0chanatkcjll8en64aaw	plugin::users-permissions.auth.logout	2026-04-20 01:52:39.992	2026-04-20 01:52:39.992	2026-04-20 01:52:39.992	\N	\N	\N
2	zl5jl0pnu51y11gvh3e5uj75	plugin::users-permissions.auth.changePassword	2026-04-20 01:52:39.992	2026-04-20 01:52:39.992	2026-04-20 01:52:39.993	\N	\N	\N
3	akxmh3i7vuqhx84muasuaey3	plugin::users-permissions.user.me	2026-04-20 01:52:39.992	2026-04-20 01:52:39.992	2026-04-20 01:52:39.992	\N	\N	\N
4	d0at8dezw2h6einia6gm8lu7	plugin::users-permissions.auth.callback	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.022	\N	\N	\N
5	kjhavou8yohz67pig12v36uh	plugin::users-permissions.auth.connect	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.022	\N	\N	\N
6	n0l292gaexal7pfxepsi9b28	plugin::users-permissions.auth.forgotPassword	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.023	\N	\N	\N
7	icz13ixufmq61yl651jd2t6b	plugin::users-permissions.auth.resetPassword	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.023	\N	\N	\N
8	rx7da1oe2zl44gkd0hfjj51a	plugin::users-permissions.auth.emailConfirmation	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.024	\N	\N	\N
11	g9b33o6wjuvz9otd6b5m54y7	plugin::users-permissions.auth.refresh	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.024	\N	\N	\N
10	teb2qnp70yod6208mms8sjk0	plugin::users-permissions.auth.sendEmailConfirmation	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.024	\N	\N	\N
9	l8kcqdqhlpz5qg1u2g4aur8k	plugin::users-permissions.auth.register	2026-04-20 01:52:40.021	2026-04-20 01:52:40.021	2026-04-20 01:52:40.023	\N	\N	\N
12	k7bv54h4zt4rwggih0a9wctd	api::article.article.find	2026-04-20 02:21:24.114	2026-04-20 02:21:24.114	2026-04-20 02:21:24.116	\N	\N	\N
13	fk925sigys152axhdjhovs60	api::article.article.findOne	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.117	\N	\N	\N
14	gn2hv6jft2zxv13n79tfeta5	api::author.author.find	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.119	\N	\N	\N
15	eozp87cnta394dgi5uvcxqrx	api::author.author.findOne	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.119	\N	\N	\N
16	hxuz5r1sj8evh1njlo800muw	api::category.category.find	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.12	\N	\N	\N
17	fkxi05pjih1a6csenzjhmfxj	api::category.category.findOne	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.121	\N	\N	\N
18	jfg2so0yc1vtdyw4c1zmjy0q	api::destination.destination.find	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.122	\N	\N	\N
19	jf4xebu8mnd07iqo84gdxcbt	api::destination.destination.findOne	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.122	\N	\N	\N
20	ds46imxkld37q9qdjb3ku541	api::tag.tag.find	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.123	\N	\N	\N
21	uzlqrgri4eo1z0u6oiqgkm8w	api::tag.tag.findOne	2026-04-20 02:21:24.115	2026-04-20 02:21:24.115	2026-04-20 02:21:24.124	\N	\N	\N
\.


--
-- Data for Name: up_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	1	1
2	2	1	1
3	3	1	1
4	4	2	1
5	6	2	1
6	5	2	2
7	8	2	2
8	7	2	2
9	11	2	2
10	10	2	2
11	9	2	2
12	12	2	3
13	13	2	3
14	15	2	4
15	14	2	4
16	16	2	5
17	17	2	5
18	18	2	6
19	19	2	6
20	20	2	7
21	21	2	8
\.


--
-- Data for Name: up_roles; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_roles (id, document_id, name, description, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	rr1bqofm1gostno62zzofile	Authenticated	Default role given to authenticated user.	authenticated	2026-04-20 01:52:39.973	2026-04-20 01:52:39.973	2026-04-20 01:52:39.973	\N	\N	\N
2	c3s7h7wywjvur1kkuvo9exov	Public	Default role given to unauthenticated user.	public	2026-04-20 01:52:39.98	2026-04-20 02:21:24.106	2026-04-20 01:52:39.98	\N	\N	\N
\.


--
-- Data for Name: up_users; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_users (id, document_id, username, email, provider, password, reset_password_token, confirmation_token, confirmed, blocked, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: up_users_role_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_users_role_lnk (id, user_id, role_id, user_ord) FROM stdin;
\.


--
-- Data for Name: upload_folders; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.upload_folders (id, document_id, name, path_id, path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	a6dyv4h7kujgybjwqmv6705c	API Uploads	1	/1	2026-04-20 10:43:17.016	2026-04-20 10:43:17.016	2026-04-20 10:43:17.017	\N	\N	\N
\.


--
-- Data for Name: upload_folders_parent_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.upload_folders_parent_lnk (id, folder_id, inv_folder_id, folder_ord) FROM stdin;
\.


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_permissions_id_seq', 160, true);


--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_permissions_role_lnk_id_seq', 160, true);


--
-- Name: admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_roles_id_seq', 3, true);


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_users_roles_lnk_id_seq', 1, true);


--
-- Name: articles_author_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.articles_author_lnk_id_seq', 1, false);


--
-- Name: articles_blog_destinations_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.articles_blog_destinations_lnk_id_seq', 1, false);


--
-- Name: articles_category_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.articles_category_lnk_id_seq', 33, true);


--
-- Name: articles_destinations_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.articles_destinations_lnk_id_seq', 1, false);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.articles_id_seq', 33, true);


--
-- Name: articles_tags_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.articles_tags_lnk_id_seq', 1, false);


--
-- Name: authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.authors_id_seq', 1, false);


--
-- Name: blog_destinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.blog_destinations_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.categories_id_seq', 13, true);


--
-- Name: categories_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.categories_parent_lnk_id_seq', 6, true);


--
-- Name: destinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.destinations_id_seq', 1, false);


--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.files_folder_lnk_id_seq', 3, true);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.files_id_seq', 3, true);


--
-- Name: files_related_mph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.files_related_mph_id_seq', 6, true);


--
-- Name: i18n_locale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.i18n_locale_id_seq', 1, true);


--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_ai_localization_jobs_id_seq', 1, false);


--
-- Name: strapi_ai_metadata_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_ai_metadata_jobs_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_api_tokens_id_seq', 4, true);


--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_core_store_settings_id_seq', 35, true);


--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_database_schema_id_seq', 3, true);


--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_history_versions_id_seq', 1, false);


--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_migrations_id_seq', 1, false);


--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_migrations_internal_id_seq', 7, true);


--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_release_actions_id_seq', 1, false);


--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_release_actions_release_lnk_id_seq', 1, false);


--
-- Name: strapi_releases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_releases_id_seq', 1, false);


--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_sessions_id_seq', 18, true);


--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_id_seq', 1, false);


--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_transfer_tokens_id_seq', 1, false);


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_webhooks_id_seq', 1, false);


--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_id_seq', 1, false);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_permissions_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_workflow_lnk_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: up_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_permissions_id_seq', 21, true);


--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_permissions_role_lnk_id_seq', 21, true);


--
-- Name: up_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_roles_id_seq', 2, true);


--
-- Name: up_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_users_id_seq', 1, false);


--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_users_role_lnk_id_seq', 1, false);


--
-- Name: upload_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.upload_folders_id_seq', 1, true);


--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.upload_folders_parent_lnk_id_seq', 1, false);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: articles_author_lnk articles_author_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_author_lnk
    ADD CONSTRAINT articles_author_lnk_pkey PRIMARY KEY (id);


--
-- Name: articles_author_lnk articles_author_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_author_lnk
    ADD CONSTRAINT articles_author_lnk_uq UNIQUE (article_id, author_id);


--
-- Name: articles_blog_destinations_lnk articles_blog_destinations_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_blog_destinations_lnk
    ADD CONSTRAINT articles_blog_destinations_lnk_pkey PRIMARY KEY (id);


--
-- Name: articles_blog_destinations_lnk articles_blog_destinations_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_blog_destinations_lnk
    ADD CONSTRAINT articles_blog_destinations_lnk_uq UNIQUE (article_id, blog_destination_id);


--
-- Name: articles_category_lnk articles_category_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_category_lnk
    ADD CONSTRAINT articles_category_lnk_pkey PRIMARY KEY (id);


--
-- Name: articles_category_lnk articles_category_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_category_lnk
    ADD CONSTRAINT articles_category_lnk_uq UNIQUE (article_id, category_id);


--
-- Name: articles_destinations_lnk articles_destinations_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_destinations_lnk
    ADD CONSTRAINT articles_destinations_lnk_pkey PRIMARY KEY (id);


--
-- Name: articles_destinations_lnk articles_destinations_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_destinations_lnk
    ADD CONSTRAINT articles_destinations_lnk_uq UNIQUE (article_id, destination_id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles_tags_lnk articles_tags_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_tags_lnk
    ADD CONSTRAINT articles_tags_lnk_pkey PRIMARY KEY (id);


--
-- Name: articles_tags_lnk articles_tags_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_tags_lnk
    ADD CONSTRAINT articles_tags_lnk_uq UNIQUE (article_id, tag_id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: blog_destinations blog_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.blog_destinations
    ADD CONSTRAINT blog_destinations_pkey PRIMARY KEY (id);


--
-- Name: categories_parent_lnk categories_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: categories_parent_lnk categories_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_uq UNIQUE (category_id, inv_category_id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: destinations destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.destinations
    ADD CONSTRAINT destinations_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_uq UNIQUE (file_id, folder_id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: files_related_mph files_related_mph_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_pkey PRIMARY KEY (id);


--
-- Name: i18n_locale i18n_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_localization_jobs strapi_ai_localization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs
    ADD CONSTRAINT strapi_ai_localization_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_metadata_jobs strapi_ai_metadata_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_ai_metadata_jobs
    ADD CONSTRAINT strapi_ai_metadata_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_uq UNIQUE (api_token_permission_id, api_token_id);


--
-- Name: strapi_api_tokens strapi_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_core_store_settings strapi_core_store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_core_store_settings
    ADD CONSTRAINT strapi_core_store_settings_pkey PRIMARY KEY (id);


--
-- Name: strapi_database_schema strapi_database_schema_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_database_schema
    ADD CONSTRAINT strapi_database_schema_pkey PRIMARY KEY (id);


--
-- Name: strapi_history_versions strapi_history_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations_internal strapi_migrations_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations_internal
    ADD CONSTRAINT strapi_migrations_internal_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations strapi_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations
    ADD CONSTRAINT strapi_migrations_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions strapi_release_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_uq UNIQUE (release_action_id, release_id);


--
-- Name: strapi_releases strapi_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_pkey PRIMARY KEY (id);


--
-- Name: strapi_sessions strapi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_uq UNIQUE (transfer_token_permission_id, transfer_token_id);


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows strapi_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_uq UNIQUE (workflow_id, workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_uq UNIQUE (workflow_stage_id, permission_id);


--
-- Name: strapi_workflows_stages strapi_workflows_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_uq UNIQUE (workflow_stage_id, workflow_id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: up_permissions up_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: up_roles up_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_pkey PRIMARY KEY (id);


--
-- Name: up_users up_users_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_uq UNIQUE (folder_id, inv_folder_id);


--
-- Name: upload_folders upload_folders_path_id_index; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_id_index UNIQUE (path_id);


--
-- Name: upload_folders upload_folders_path_index; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_index UNIQUE (path);


--
-- Name: upload_folders upload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);


--
-- Name: admin_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_documents_idx ON public.admin_permissions USING btree (document_id, locale, published_at);


--
-- Name: admin_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_role_lnk_fk ON public.admin_permissions_role_lnk USING btree (permission_id);


--
-- Name: admin_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_role_lnk_ifk ON public.admin_permissions_role_lnk USING btree (role_id);


--
-- Name: admin_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_role_lnk_oifk ON public.admin_permissions_role_lnk USING btree (permission_ord);


--
-- Name: admin_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);


--
-- Name: admin_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);


--
-- Name: admin_roles_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_roles_documents_idx ON public.admin_roles USING btree (document_id, locale, published_at);


--
-- Name: admin_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);


--
-- Name: admin_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);


--
-- Name: admin_users_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_documents_idx ON public.admin_users USING btree (document_id, locale, published_at);


--
-- Name: admin_users_roles_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_fk ON public.admin_users_roles_lnk USING btree (user_id);


--
-- Name: admin_users_roles_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_ifk ON public.admin_users_roles_lnk USING btree (role_id);


--
-- Name: admin_users_roles_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_ofk ON public.admin_users_roles_lnk USING btree (role_ord);


--
-- Name: admin_users_roles_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_oifk ON public.admin_users_roles_lnk USING btree (user_ord);


--
-- Name: admin_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);


--
-- Name: articles_author_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_author_lnk_fk ON public.articles_author_lnk USING btree (article_id);


--
-- Name: articles_author_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_author_lnk_ifk ON public.articles_author_lnk USING btree (author_id);


--
-- Name: articles_author_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_author_lnk_oifk ON public.articles_author_lnk USING btree (article_ord);


--
-- Name: articles_blog_destinations_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_blog_destinations_lnk_fk ON public.articles_blog_destinations_lnk USING btree (article_id);


--
-- Name: articles_blog_destinations_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_blog_destinations_lnk_ifk ON public.articles_blog_destinations_lnk USING btree (blog_destination_id);


--
-- Name: articles_blog_destinations_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_blog_destinations_lnk_ofk ON public.articles_blog_destinations_lnk USING btree (blog_destination_ord);


--
-- Name: articles_blog_destinations_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_blog_destinations_lnk_oifk ON public.articles_blog_destinations_lnk USING btree (article_ord);


--
-- Name: articles_category_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_category_lnk_fk ON public.articles_category_lnk USING btree (article_id);


--
-- Name: articles_category_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_category_lnk_ifk ON public.articles_category_lnk USING btree (category_id);


--
-- Name: articles_category_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_category_lnk_oifk ON public.articles_category_lnk USING btree (article_ord);


--
-- Name: articles_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_created_by_id_fk ON public.articles USING btree (created_by_id);


--
-- Name: articles_destinations_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_destinations_lnk_fk ON public.articles_destinations_lnk USING btree (article_id);


--
-- Name: articles_destinations_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_destinations_lnk_ifk ON public.articles_destinations_lnk USING btree (destination_id);


--
-- Name: articles_destinations_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_destinations_lnk_ofk ON public.articles_destinations_lnk USING btree (destination_ord);


--
-- Name: articles_destinations_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_destinations_lnk_oifk ON public.articles_destinations_lnk USING btree (article_ord);


--
-- Name: articles_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_documents_idx ON public.articles USING btree (document_id, locale, published_at);


--
-- Name: articles_tags_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_tags_lnk_fk ON public.articles_tags_lnk USING btree (article_id);


--
-- Name: articles_tags_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_tags_lnk_ifk ON public.articles_tags_lnk USING btree (tag_id);


--
-- Name: articles_tags_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_tags_lnk_ofk ON public.articles_tags_lnk USING btree (tag_ord);


--
-- Name: articles_tags_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_tags_lnk_oifk ON public.articles_tags_lnk USING btree (article_ord);


--
-- Name: articles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX articles_updated_by_id_fk ON public.articles USING btree (updated_by_id);


--
-- Name: authors_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX authors_created_by_id_fk ON public.authors USING btree (created_by_id);


--
-- Name: authors_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX authors_documents_idx ON public.authors USING btree (document_id, locale, published_at);


--
-- Name: authors_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX authors_updated_by_id_fk ON public.authors USING btree (updated_by_id);


--
-- Name: blog_destinations_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX blog_destinations_created_by_id_fk ON public.blog_destinations USING btree (created_by_id);


--
-- Name: blog_destinations_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX blog_destinations_documents_idx ON public.blog_destinations USING btree (document_id, locale, published_at);


--
-- Name: blog_destinations_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX blog_destinations_updated_by_id_fk ON public.blog_destinations USING btree (updated_by_id);


--
-- Name: categories_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX categories_created_by_id_fk ON public.categories USING btree (created_by_id);


--
-- Name: categories_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX categories_documents_idx ON public.categories USING btree (document_id, locale, published_at);


--
-- Name: categories_parent_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX categories_parent_lnk_fk ON public.categories_parent_lnk USING btree (category_id);


--
-- Name: categories_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX categories_parent_lnk_ifk ON public.categories_parent_lnk USING btree (inv_category_id);


--
-- Name: categories_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX categories_parent_lnk_oifk ON public.categories_parent_lnk USING btree (category_ord);


--
-- Name: categories_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX categories_updated_by_id_fk ON public.categories USING btree (updated_by_id);


--
-- Name: destinations_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX destinations_created_by_id_fk ON public.destinations USING btree (created_by_id);


--
-- Name: destinations_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX destinations_documents_idx ON public.destinations USING btree (document_id, locale, published_at);


--
-- Name: destinations_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX destinations_updated_by_id_fk ON public.destinations USING btree (updated_by_id);


--
-- Name: files_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);


--
-- Name: files_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_documents_idx ON public.files USING btree (document_id, locale, published_at);


--
-- Name: files_folder_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_folder_lnk_fk ON public.files_folder_lnk USING btree (file_id);


--
-- Name: files_folder_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_folder_lnk_ifk ON public.files_folder_lnk USING btree (folder_id);


--
-- Name: files_folder_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_folder_lnk_oifk ON public.files_folder_lnk USING btree (file_ord);


--
-- Name: files_related_mph_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_related_mph_fk ON public.files_related_mph USING btree (file_id);


--
-- Name: files_related_mph_idix; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_related_mph_idix ON public.files_related_mph USING btree (related_id);


--
-- Name: files_related_mph_oidx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_related_mph_oidx ON public.files_related_mph USING btree ("order");


--
-- Name: files_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);


--
-- Name: i18n_locale_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);


--
-- Name: i18n_locale_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX i18n_locale_documents_idx ON public.i18n_locale USING btree (document_id, locale, published_at);


--
-- Name: i18n_locale_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);


--
-- Name: strapi_api_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);


--
-- Name: strapi_api_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_documents_idx ON public.strapi_api_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_token_lnk_fk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_id);


--
-- Name: strapi_api_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_token_lnk_ifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_id);


--
-- Name: strapi_api_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_token_lnk_oifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_ord);


--
-- Name: strapi_api_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_api_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);


--
-- Name: strapi_api_tokens_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_tokens_documents_idx ON public.strapi_api_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);


--
-- Name: strapi_history_versions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_history_versions_created_by_id_fk ON public.strapi_history_versions USING btree (created_by_id);


--
-- Name: strapi_release_actions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);


--
-- Name: strapi_release_actions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_documents_idx ON public.strapi_release_actions USING btree (document_id, locale, published_at);


--
-- Name: strapi_release_actions_release_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_release_lnk_fk ON public.strapi_release_actions_release_lnk USING btree (release_action_id);


--
-- Name: strapi_release_actions_release_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_release_lnk_ifk ON public.strapi_release_actions_release_lnk USING btree (release_id);


--
-- Name: strapi_release_actions_release_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_release_lnk_oifk ON public.strapi_release_actions_release_lnk USING btree (release_action_ord);


--
-- Name: strapi_release_actions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);


--
-- Name: strapi_releases_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);


--
-- Name: strapi_releases_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_releases_documents_idx ON public.strapi_releases USING btree (document_id, locale, published_at);


--
-- Name: strapi_releases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);


--
-- Name: strapi_sessions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_sessions_created_by_id_fk ON public.strapi_sessions USING btree (created_by_id);


--
-- Name: strapi_sessions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_sessions_documents_idx ON public.strapi_sessions USING btree (document_id, locale, published_at);


--
-- Name: strapi_sessions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_sessions_updated_by_id_fk ON public.strapi_sessions USING btree (updated_by_id);


--
-- Name: strapi_transfer_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);


--
-- Name: strapi_transfer_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_documents_idx ON public.strapi_transfer_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_fk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_ifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_oifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_ord);


--
-- Name: strapi_transfer_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_transfer_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);


--
-- Name: strapi_transfer_tokens_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_tokens_documents_idx ON public.strapi_transfer_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);


--
-- Name: strapi_workflows_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_created_by_id_fk ON public.strapi_workflows USING btree (created_by_id);


--
-- Name: strapi_workflows_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_documents_idx ON public.strapi_workflows USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_fk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_ifk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_created_by_id_fk ON public.strapi_workflows_stages USING btree (created_by_id);


--
-- Name: strapi_workflows_stages_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_documents_idx ON public.strapi_workflows_stages USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stages_permissions_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_fk ON public.strapi_workflows_stages_permissions_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ifk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ofk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_ord);


--
-- Name: strapi_workflows_stages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_updated_by_id_fk ON public.strapi_workflows_stages USING btree (updated_by_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_fk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_ifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_oifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_ord);


--
-- Name: strapi_workflows_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_updated_by_id_fk ON public.strapi_workflows USING btree (updated_by_id);


--
-- Name: tags_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX tags_created_by_id_fk ON public.tags USING btree (created_by_id);


--
-- Name: tags_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX tags_documents_idx ON public.tags USING btree (document_id, locale, published_at);


--
-- Name: tags_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX tags_updated_by_id_fk ON public.tags USING btree (updated_by_id);


--
-- Name: up_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);


--
-- Name: up_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_documents_idx ON public.up_permissions USING btree (document_id, locale, published_at);


--
-- Name: up_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_role_lnk_fk ON public.up_permissions_role_lnk USING btree (permission_id);


--
-- Name: up_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_role_lnk_ifk ON public.up_permissions_role_lnk USING btree (role_id);


--
-- Name: up_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_role_lnk_oifk ON public.up_permissions_role_lnk USING btree (permission_ord);


--
-- Name: up_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);


--
-- Name: up_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);


--
-- Name: up_roles_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_roles_documents_idx ON public.up_roles USING btree (document_id, locale, published_at);


--
-- Name: up_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);


--
-- Name: up_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);


--
-- Name: up_users_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_documents_idx ON public.up_users USING btree (document_id, locale, published_at);


--
-- Name: up_users_role_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_role_lnk_fk ON public.up_users_role_lnk USING btree (user_id);


--
-- Name: up_users_role_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_role_lnk_ifk ON public.up_users_role_lnk USING btree (role_id);


--
-- Name: up_users_role_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_role_lnk_oifk ON public.up_users_role_lnk USING btree (user_ord);


--
-- Name: up_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);


--
-- Name: upload_files_created_at_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);


--
-- Name: upload_files_ext_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);


--
-- Name: upload_files_folder_path_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);


--
-- Name: upload_files_name_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_name_index ON public.files USING btree (name);


--
-- Name: upload_files_size_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_size_index ON public.files USING btree (size);


--
-- Name: upload_files_updated_at_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);


--
-- Name: upload_folders_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);


--
-- Name: upload_folders_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_documents_idx ON public.upload_folders USING btree (document_id, locale, published_at);


--
-- Name: upload_folders_parent_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_parent_lnk_fk ON public.upload_folders_parent_lnk USING btree (folder_id);


--
-- Name: upload_folders_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_parent_lnk_ifk ON public.upload_folders_parent_lnk USING btree (inv_folder_id);


--
-- Name: upload_folders_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_parent_lnk_oifk ON public.upload_folders_parent_lnk USING btree (folder_ord);


--
-- Name: upload_folders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);


--
-- Name: admin_permissions admin_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_permissions admin_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users admin_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_users admin_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: articles_author_lnk articles_author_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_author_lnk
    ADD CONSTRAINT articles_author_lnk_fk FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles_author_lnk articles_author_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_author_lnk
    ADD CONSTRAINT articles_author_lnk_ifk FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE CASCADE;


--
-- Name: articles_blog_destinations_lnk articles_blog_destinations_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_blog_destinations_lnk
    ADD CONSTRAINT articles_blog_destinations_lnk_fk FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles_blog_destinations_lnk articles_blog_destinations_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_blog_destinations_lnk
    ADD CONSTRAINT articles_blog_destinations_lnk_ifk FOREIGN KEY (blog_destination_id) REFERENCES public.blog_destinations(id) ON DELETE CASCADE;


--
-- Name: articles_category_lnk articles_category_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_category_lnk
    ADD CONSTRAINT articles_category_lnk_fk FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles_category_lnk articles_category_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_category_lnk
    ADD CONSTRAINT articles_category_lnk_ifk FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: articles articles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: articles_destinations_lnk articles_destinations_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_destinations_lnk
    ADD CONSTRAINT articles_destinations_lnk_fk FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles_destinations_lnk articles_destinations_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_destinations_lnk
    ADD CONSTRAINT articles_destinations_lnk_ifk FOREIGN KEY (destination_id) REFERENCES public.destinations(id) ON DELETE CASCADE;


--
-- Name: articles_tags_lnk articles_tags_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_tags_lnk
    ADD CONSTRAINT articles_tags_lnk_fk FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles_tags_lnk articles_tags_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles_tags_lnk
    ADD CONSTRAINT articles_tags_lnk_ifk FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: articles articles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: authors authors_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: authors authors_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: blog_destinations blog_destinations_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.blog_destinations
    ADD CONSTRAINT blog_destinations_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: blog_destinations blog_destinations_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.blog_destinations
    ADD CONSTRAINT blog_destinations_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: categories categories_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: categories_parent_lnk categories_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_fk FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: categories_parent_lnk categories_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_ifk FOREIGN KEY (inv_category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: categories categories_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: destinations destinations_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.destinations
    ADD CONSTRAINT destinations_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: destinations destinations_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.destinations
    ADD CONSTRAINT destinations_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files files_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files_folder_lnk files_folder_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files_folder_lnk files_folder_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_ifk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: files_related_mph files_related_mph_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files files_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_fk FOREIGN KEY (api_token_permission_id) REFERENCES public.strapi_api_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_history_versions strapi_history_versions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions strapi_release_actions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_fk FOREIGN KEY (release_action_id) REFERENCES public.strapi_release_actions(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_ifk FOREIGN KEY (release_id) REFERENCES public.strapi_releases(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions strapi_release_actions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_fk FOREIGN KEY (transfer_token_permission_id) REFERENCES public.strapi_transfer_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_ifk FOREIGN KEY (transfer_token_id) REFERENCES public.strapi_transfer_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows strapi_workflows_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_fk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_ifk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_ifk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_ifk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows strapi_workflows_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: tags tags_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: tags tags_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions up_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.up_permissions(id) ON DELETE CASCADE;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_permissions up_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users up_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users_role_lnk up_users_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_users up_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders upload_folders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_fk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_ifk FOREIGN KEY (inv_folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders upload_folders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict HGWtHHHvOBj4Td6wpTtU8bsesPx3aj1eSoloZ3KxVBbUblBuBTv1Sj6F4lZnfpQ

