--
-- PostgreSQL database dump
--

\restrict exKU0wb6jPInJFt3aWzTjNQbHppc6C5H7jXNg1pXrqICaGJRxw3zKEwsn9LfW5D

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: strapi
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'pending',
    'confirmed',
    'failed',
    'cancelled'
);


ALTER TYPE public."BookingStatus" OWNER TO strapi;

--
-- Name: BookingType; Type: TYPE; Schema: public; Owner: strapi
--

CREATE TYPE public."BookingType" AS ENUM (
    'flight',
    'stay'
);


ALTER TYPE public."BookingType" OWNER TO strapi;

--
-- Name: SearchType; Type: TYPE; Schema: public; Owner: strapi
--

CREATE TYPE public."SearchType" AS ENUM (
    'flight',
    'stay'
);


ALTER TYPE public."SearchType" OWNER TO strapi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Airline; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public."Airline" (
    id text NOT NULL,
    "iataCode" text,
    "icaoCode" text,
    name text NOT NULL,
    "legalName" text,
    alliance text,
    "countryCode" text,
    "countryName" text,
    callsign text,
    "websiteUrl" text,
    "supportPhone" text,
    "logoUrl" text,
    "logoLocalPath" text,
    "isActive" boolean DEFAULT true NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Airline" OWNER TO strapi;

--
-- Name: Booking; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public."Booking" (
    id text NOT NULL,
    "userId" text,
    "searchRecordId" text,
    type public."BookingType" NOT NULL,
    status public."BookingStatus" DEFAULT 'pending'::public."BookingStatus" NOT NULL,
    "duffelOrderId" text,
    "bookingReference" text,
    currency text,
    "totalAmount" numeric(10,2),
    "offerId" text,
    "providerName" text,
    metadata jsonb,
    "bookedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Booking" OWNER TO strapi;

--
-- Name: BookingPassenger; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public."BookingPassenger" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "duffelPassengerId" text,
    type text,
    title text,
    gender text,
    "givenName" text NOT NULL,
    "familyName" text NOT NULL,
    "bornOn" timestamp(3) without time zone,
    email text,
    "phoneNumber" text,
    "loyaltyAirlineCode" text,
    "loyaltyAccountNumber" text,
    "identityDocumentType" text,
    "identityDocumentNumber" text,
    "issuingCountryCode" text,
    "expiresOn" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BookingPassenger" OWNER TO strapi;

--
-- Name: SearchRecord; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public."SearchRecord" (
    id text NOT NULL,
    "userId" text,
    type public."SearchType" NOT NULL,
    "originCode" text,
    "destinationCode" text,
    "destinationQuery" text,
    "departureDate" timestamp(3) without time zone,
    "returnDate" timestamp(3) without time zone,
    "checkInDate" timestamp(3) without time zone,
    "checkOutDate" timestamp(3) without time zone,
    "cabinClass" text,
    adults integer,
    rooms integer,
    guests integer,
    "offerRequestId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SearchRecord" OWNER TO strapi;

--
-- Name: TravellerProfile; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public."TravellerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "fullName" text NOT NULL,
    email text,
    "phoneNumber" text,
    "dateOfBirth" timestamp(3) without time zone,
    title text,
    gender text,
    "loyaltyAirlineCode" text,
    "loyaltyAccountNumber" text,
    "passportNumber" text,
    "passportCountryCode" text,
    "passportExpiresOn" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TravellerProfile" OWNER TO strapi;

--
-- Name: User; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "fullName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO strapi;

--
-- Data for Name: Airline; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public."Airline" (id, "iataCode", "icaoCode", name, "legalName", alliance, "countryCode", "countryName", callsign, "websiteUrl", "supportPhone", "logoUrl", "logoLocalPath", "isActive", metadata, "createdAt", "updatedAt") FROM stdin;
cmoqctm7800005xpq4e9bsq5f	BA	BAW	British Airways	British Airways Plc	oneworld	GB	United Kingdom	SPEEDBIRD	https://www.britishairways.com	\N	https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg	\N	t	\N	2026-05-03 22:40:43.94	2026-05-03 22:40:43.94
cmoqctm7n00015xpqgt3h6qrv	JQ	JST	Jetstar Airways	Jetstar Airways Pty Ltd	\N	AU	Australia	JETSTAR	https://www.jetstar.com	\N	https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/JQ.svg	\N	t	\N	2026-05-03 22:40:43.955	2026-05-03 22:40:43.955
cmoqctm7s00025xpqn9arodwe	QF	QFA	Qantas	Qantas Airways Limited	oneworld	AU	Australia	QANTAS	https://www.qantas.com	\N	https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/QF.svg	\N	t	\N	2026-05-03 22:40:43.96	2026-05-03 22:40:43.96
cmoqctm7y00035xpqn6b9y2ci	VA	VOZ	Virgin Australia	Virgin Australia Airlines Pty Ltd	\N	AU	Australia	VIRGIN	https://www.virginaustralia.com	\N	https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/VA.svg	\N	t	\N	2026-05-03 22:40:43.966	2026-05-03 22:40:43.966
cmoqctm8300045xpqqsc2z5tg	SQ	SIA	Singapore Airlines	Singapore Airlines Limited	Star Alliance	SG	Singapore	SINGAPORE	https://www.singaporeair.com	\N	https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/SQ.svg	\N	t	\N	2026-05-03 22:40:43.971	2026-05-03 22:40:43.971
\.


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public."Booking" (id, "userId", "searchRecordId", type, status, "duffelOrderId", "bookingReference", currency, "totalAmount", "offerId", "providerName", metadata, "bookedAt", "createdAt", "updatedAt") FROM stdin;
cmp22zldi00000irwao9ayxgg	\N	\N	flight	confirmed	ord_0000B6CyN88TBD1fJhWjHU	QVG22I	GBP	404.51	off_0000B6CyFgPrqEQjJs76GH	duffel	{"orderType": "hold", "duffelOrder": {"id": "ord_0000B6CyN88TBD1fJhWjHU", "type": "hold", "owner": {"id": "arl_00009VME7DBKeMags5CliQ", "name": "British Airways", "iata_code": "BA", "logo_lockup_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-lockup/BA.svg", "logo_symbol_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg", "conditions_of_carriage_url": "https://www.britishairways.com/en-gb/information/legal/british-airways/general-conditions-of-carriage"}, "users": [], "slices": [{"id": "sli_0000B6CyFgPVrY99IlwoiG", "origin": {"id": "arp_lhr_gb", "city": {"id": "cit_lon_gb", "name": "London", "type": "city", "latitude": null, "city_name": null, "iata_code": "LON", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "LON", "iata_country_code": "GB"}, "name": "Heathrow Airport", "type": "airport", "latitude": 51.470311, "city_name": "London", "iata_code": "LHR", "icao_code": "EGLL", "longitude": -0.458118, "time_zone": "Europe/London", "iata_city_code": "LON", "iata_country_code": "GB"}, "duration": "PT7H58M", "segments": [{"id": "seg_0000B6CyFgPVrY99IlwoiC", "stops": [], "origin": {"id": "arp_lhr_gb", "city": {"id": "cit_lon_gb", "name": "London", "type": "city", "latitude": null, "city_name": null, "iata_code": "LON", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "LON", "iata_country_code": "GB"}, "name": "Heathrow Airport", "type": "airport", "latitude": 51.470311, "city_name": "London", "iata_code": "LHR", "icao_code": "EGLL", "longitude": -0.458118, "time_zone": "Europe/London", "iata_city_code": "LON", "iata_country_code": "GB"}, "aircraft": {"id": "arc_00009Y7sdMgecbtm6IHItE", "name": "Boeing 787-9", "iata_code": "789"}, "distance": "5539.8359982030115", "duration": "PT7H58M", "passengers": [{"seat": null, "baggages": [{"type": "checked", "quantity": 1}, {"type": "carry_on", "quantity": 1}], "cabin_class": "economy", "passenger_id": "pas_0000B6CyFgBY3u2JdImD1H", "cabin_class_marketing_name": "Economy"}], "arriving_at": "2026-06-11T10:42:00", "destination": {"id": "arp_jfk_us", "city": {"id": "cit_nyc_us", "name": "New York", "type": "city", "latitude": null, "city_name": null, "iata_code": "NYC", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "NYC", "iata_country_code": "US"}, "name": "John F. Kennedy International Airport", "type": "airport", "latitude": 40.640556, "city_name": "New York", "iata_code": "JFK", "icao_code": "KJFK", "longitude": -73.778519, "time_zone": "America/New_York", "iata_city_code": "NYC", "iata_country_code": "US"}, "departing_at": "2026-06-11T07:44:00", "origin_terminal": "2", "marketing_carrier": {"id": "arl_00009VME7DBKeMags5CliQ", "name": "British Airways", "iata_code": "BA", "logo_lockup_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-lockup/BA.svg", "logo_symbol_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg", "conditions_of_carriage_url": "https://www.britishairways.com/en-gb/information/legal/british-airways/general-conditions-of-carriage"}, "operating_carrier": {"id": "arl_00009VME7DBKeMags5CliQ", "name": "British Airways", "iata_code": "BA", "logo_lockup_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-lockup/BA.svg", "logo_symbol_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg", "conditions_of_carriage_url": "https://www.britishairways.com/en-gb/information/legal/british-airways/general-conditions-of-carriage"}, "destination_terminal": "1", "marketing_carrier_flight_number": "1516", "operating_carrier_flight_number": "1516"}], "conditions": {"change_before_departure": {"allowed": true, "penalty_amount": "70.00", "penalty_currency": "GBP"}}, "destination": {"id": "arp_jfk_us", "city": {"id": "cit_nyc_us", "name": "New York", "type": "city", "latitude": null, "city_name": null, "iata_code": "NYC", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "NYC", "iata_country_code": "US"}, "name": "John F. Kennedy International Airport", "type": "airport", "latitude": 40.640556, "city_name": "New York", "iata_code": "JFK", "icao_code": "KJFK", "longitude": -73.778519, "time_zone": "America/New_York", "iata_city_code": "NYC", "iata_country_code": "US"}, "origin_type": "airport", "fare_brand_name": "Basic", "destination_type": "airport"}, {"id": "sli_0000B6CyFgPrqEQjJs76G5", "origin": {"id": "arp_jfk_us", "city": {"id": "cit_nyc_us", "name": "New York", "type": "city", "latitude": null, "city_name": null, "iata_code": "NYC", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "NYC", "iata_country_code": "US"}, "name": "John F. Kennedy International Airport", "type": "airport", "latitude": 40.640556, "city_name": "New York", "iata_code": "JFK", "icao_code": "KJFK", "longitude": -73.778519, "time_zone": "America/New_York", "iata_city_code": "NYC", "iata_country_code": "US"}, "duration": "PT7H58M", "segments": [{"id": "seg_0000B6CyFgPVrY99IlwoiW", "stops": [], "origin": {"id": "arp_jfk_us", "city": {"id": "cit_nyc_us", "name": "New York", "type": "city", "latitude": null, "city_name": null, "iata_code": "NYC", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "NYC", "iata_country_code": "US"}, "name": "John F. Kennedy International Airport", "type": "airport", "latitude": 40.640556, "city_name": "New York", "iata_code": "JFK", "icao_code": "KJFK", "longitude": -73.778519, "time_zone": "America/New_York", "iata_city_code": "NYC", "iata_country_code": "US"}, "aircraft": {"id": "arc_00009Y7sdMgecbtm6IHItE", "name": "Boeing 787-9", "iata_code": "789"}, "distance": "5539.8359982030115", "duration": "PT7H58M", "passengers": [{"seat": null, "baggages": [{"type": "checked", "quantity": 1}, {"type": "carry_on", "quantity": 1}], "cabin_class": "economy", "passenger_id": "pas_0000B6CyFgBY3u2JdImD1H", "cabin_class_marketing_name": "Economy"}], "arriving_at": "2026-06-19T02:07:00", "destination": {"id": "arp_lhr_gb", "city": {"id": "cit_lon_gb", "name": "London", "type": "city", "latitude": null, "city_name": null, "iata_code": "LON", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "LON", "iata_country_code": "GB"}, "name": "Heathrow Airport", "type": "airport", "latitude": 51.470311, "city_name": "London", "iata_code": "LHR", "icao_code": "EGLL", "longitude": -0.458118, "time_zone": "Europe/London", "iata_city_code": "LON", "iata_country_code": "GB"}, "departing_at": "2026-06-18T13:09:00", "origin_terminal": "2", "marketing_carrier": {"id": "arl_00009VME7DBKeMags5CliQ", "name": "British Airways", "iata_code": "BA", "logo_lockup_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-lockup/BA.svg", "logo_symbol_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg", "conditions_of_carriage_url": "https://www.britishairways.com/en-gb/information/legal/british-airways/general-conditions-of-carriage"}, "operating_carrier": {"id": "arl_00009VME7DBKeMags5CliQ", "name": "British Airways", "iata_code": "BA", "logo_lockup_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-lockup/BA.svg", "logo_symbol_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg", "conditions_of_carriage_url": "https://www.britishairways.com/en-gb/information/legal/british-airways/general-conditions-of-carriage"}, "destination_terminal": "1", "marketing_carrier_flight_number": "1516", "operating_carrier_flight_number": "1516"}], "conditions": {"change_before_departure": {"allowed": true, "penalty_amount": "70.00", "penalty_currency": "GBP"}}, "destination": {"id": "arp_lhr_gb", "city": {"id": "cit_lon_gb", "name": "London", "type": "city", "latitude": null, "city_name": null, "iata_code": "LON", "icao_code": null, "longitude": null, "time_zone": null, "iata_city_code": "LON", "iata_country_code": "GB"}, "name": "Heathrow Airport", "type": "airport", "latitude": 51.470311, "city_name": "London", "iata_code": "LHR", "icao_code": "EGLL", "longitude": -0.458118, "time_zone": "Europe/London", "iata_city_code": "LON", "iata_country_code": "GB"}, "origin_type": "airport", "fare_brand_name": "Basic", "destination_type": "airport"}], "changes": [], "content": "managed", "metadata": {"source": "duffel-ancillaries@3.16.0"}, "offer_id": "off_0000B6CyFgPrqEQjJs76GH", "services": [], "documents": [], "live_mode": false, "synced_at": "2026-05-12T03:38:40Z", "conditions": {"change_before_departure": {"allowed": true, "penalty_amount": "70.00", "penalty_currency": "GBP"}, "refund_before_departure": {"allowed": false, "penalty_amount": null, "penalty_currency": null}}, "created_at": "2026-05-12T03:38:40.597944Z", "passengers": [{"id": "pas_0000B6CyFgBY3u2JdImD1H", "type": "adult", "email": "kritin@fxnholdings.com", "title": "mr", "gender": "m", "born_on": "1979-09-07", "user_id": null, "given_name": "Kritin", "family_name": "Curtis", "phone_number": "+61484122668", "infant_passenger_id": null, "loyalty_programme_accounts": []}], "tax_amount": "61.70", "base_amount": "342.81", "cancellation": null, "cancelled_at": null, "tax_currency": "GBP", "total_amount": "404.51", "base_currency": "GBP", "payment_status": {"paid_at": null, "awaiting_payment": true, "payment_required_by": "2026-05-15T03:37:19Z", "price_guarantee_expires_at": "2026-05-14T03:37:19Z"}, "total_currency": "GBP", "available_actions": ["cancel", "update"], "booking_reference": "QVG22I", "booking_references": [{"carrier": {"id": "arl_00009VME7DBKeMags5CliQ", "name": "British Airways", "iata_code": "BA", "logo_lockup_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-lockup/BA.svg", "logo_symbol_url": "https://assets.duffel.com/img/airlines/for-light-background/full-color-logo/BA.svg", "conditions_of_carriage_url": "https://www.britishairways.com/en-gb/information/legal/british-airways/general-conditions-of-carriage"}, "booking_reference": "QVG22I"}], "void_window_ends_at": null, "intended_payment_methods": [], "airline_initiated_changes": []}, "submittedPayload": {"passengers": [{"id": "pas_0000B6CyFgBY3u2JdImD1H", "type": "adult", "email": "kritin@fxnholdings.com", "title": "mr", "gender": "m", "born_on": "1979-09-07", "given_name": "Kritin", "family_name": "Curtis", "phone_number": "+61484122668", "identity_documents": [{"type": "passport", "expires_on": "2030-02-08", "unique_identifier": "RA854852563", "issuing_country_code": "AU"}]}], "selected_offers": ["off_0000B6CyFgPrqEQjJs76GH"]}}	2026-05-12 03:38:40.715	2026-05-12 03:38:40.758	2026-05-12 03:38:40.758
\.


--
-- Data for Name: BookingPassenger; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public."BookingPassenger" (id, "bookingId", "duffelPassengerId", type, title, gender, "givenName", "familyName", "bornOn", email, "phoneNumber", "loyaltyAirlineCode", "loyaltyAccountNumber", "identityDocumentType", "identityDocumentNumber", "issuingCountryCode", "expiresOn", "createdAt", "updatedAt") FROM stdin;
cmp22zldu00010irw0btb1jtt	cmp22zldi00000irwao9ayxgg	pas_0000B6CyFgBY3u2JdImD1H	adult	mr	m	Kritin	Curtis	1979-09-07 00:00:00	kritin@fxnholdings.com	+61484122668	\N	\N	passport	RA854852563	AU	2030-02-08 00:00:00	2026-05-12 03:38:40.758	2026-05-12 03:38:40.758
\.


--
-- Data for Name: SearchRecord; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public."SearchRecord" (id, "userId", type, "originCode", "destinationCode", "destinationQuery", "departureDate", "returnDate", "checkInDate", "checkOutDate", "cabinClass", adults, rooms, guests, "offerRequestId", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TravellerProfile; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public."TravellerProfile" (id, "userId", "fullName", email, "phoneNumber", "dateOfBirth", title, gender, "loyaltyAirlineCode", "loyaltyAccountNumber", "passportNumber", "passportCountryCode", "passportExpiresOn", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public."User" (id, email, "fullName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: Airline Airline_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."Airline"
    ADD CONSTRAINT "Airline_pkey" PRIMARY KEY (id);


--
-- Name: BookingPassenger BookingPassenger_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."BookingPassenger"
    ADD CONSTRAINT "BookingPassenger_pkey" PRIMARY KEY (id);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: SearchRecord SearchRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."SearchRecord"
    ADD CONSTRAINT "SearchRecord_pkey" PRIMARY KEY (id);


--
-- Name: TravellerProfile TravellerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."TravellerProfile"
    ADD CONSTRAINT "TravellerProfile_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Airline_countryCode_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "Airline_countryCode_idx" ON public."Airline" USING btree ("countryCode");


--
-- Name: Airline_iataCode_key; Type: INDEX; Schema: public; Owner: strapi
--

CREATE UNIQUE INDEX "Airline_iataCode_key" ON public."Airline" USING btree ("iataCode");


--
-- Name: Airline_icaoCode_key; Type: INDEX; Schema: public; Owner: strapi
--

CREATE UNIQUE INDEX "Airline_icaoCode_key" ON public."Airline" USING btree ("icaoCode");


--
-- Name: Airline_name_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "Airline_name_idx" ON public."Airline" USING btree (name);


--
-- Name: BookingPassenger_bookingId_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "BookingPassenger_bookingId_idx" ON public."BookingPassenger" USING btree ("bookingId");


--
-- Name: BookingPassenger_duffelPassengerId_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "BookingPassenger_duffelPassengerId_idx" ON public."BookingPassenger" USING btree ("duffelPassengerId");


--
-- Name: Booking_duffelOrderId_key; Type: INDEX; Schema: public; Owner: strapi
--

CREATE UNIQUE INDEX "Booking_duffelOrderId_key" ON public."Booking" USING btree ("duffelOrderId");


--
-- Name: Booking_offerId_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "Booking_offerId_idx" ON public."Booking" USING btree ("offerId");


--
-- Name: Booking_searchRecordId_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "Booking_searchRecordId_idx" ON public."Booking" USING btree ("searchRecordId");


--
-- Name: Booking_userId_type_status_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "Booking_userId_type_status_idx" ON public."Booking" USING btree ("userId", type, status);


--
-- Name: SearchRecord_offerRequestId_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "SearchRecord_offerRequestId_idx" ON public."SearchRecord" USING btree ("offerRequestId");


--
-- Name: SearchRecord_userId_type_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "SearchRecord_userId_type_idx" ON public."SearchRecord" USING btree ("userId", type);


--
-- Name: TravellerProfile_userId_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX "TravellerProfile_userId_idx" ON public."TravellerProfile" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: strapi
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: BookingPassenger BookingPassenger_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."BookingPassenger"
    ADD CONSTRAINT "BookingPassenger_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Booking Booking_searchRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_searchRecordId_fkey" FOREIGN KEY ("searchRecordId") REFERENCES public."SearchRecord"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Booking Booking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SearchRecord SearchRecord_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."SearchRecord"
    ADD CONSTRAINT "SearchRecord_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TravellerProfile TravellerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public."TravellerProfile"
    ADD CONSTRAINT "TravellerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict exKU0wb6jPInJFt3aWzTjNQbHppc6C5H7jXNg1pXrqICaGJRxw3zKEwsn9LfW5D

